import { CalendarDays, MapPin, Scale } from 'lucide-react'
import type { Listing } from '@/types'
import { productById, placeById } from '@/data/seed'
import { dateShort, kg, perKg } from '@/lib/format'
import { roadKm } from '@/lib/geo'
import { sellerName, sellerVerified } from '@/services'
import { Badge, VerifiedBadge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'

export function ListingCard({
  listing, viewerPlaceId, onView, actionLabel = 'View details',
}: { listing: Listing; viewerPlaceId?: string; onView?: (listing: Listing) => void; actionLabel?: string }) {
  const product = productById(listing.productId)
  const distance = viewerPlaceId ? roadKm(listing.farmPlaceId, viewerPlaceId) : null

  return (
    <article className="flex h-full flex-col rounded-2xl border border-forest-100 bg-white p-4 shadow-card transition hover:border-forest-300 hover:shadow-lift">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span aria-hidden className="grid h-11 w-11 place-items-center rounded-xl bg-forest-50 text-xl">{product.emoji}</span>
          <div>
            <h3 className="font-display text-lg font-semibold leading-tight">{product.name}</h3>
            <p className="text-sm text-ink-mute">
              {sellerName(listing.sellerId)}
              {listing.sellerRole === 'fpo' && ' · FPO'}
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="tnum font-display text-xl font-semibold text-forest-700">{perKg(listing.pricePerKg)}</p>
          <p className="text-xs text-ink-mute">Farmer's asking price</p>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        <VerifiedBadge verified={sellerVerified(listing.sellerId)} />
        <Badge tone="clay">Grade {listing.grade}</Badge>
        {distance !== null && <Badge tone="neutral">{distance} km away</Badge>}
      </div>

      <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1.5 text-sm text-ink-soft">
        <div className="flex items-center gap-1.5">
          <Scale size={14} className="text-ink-mute" />
          <span className="tnum">{kg(listing.remainingKg)} available</span>
        </div>
        <div className="flex items-center gap-1.5">
          <MapPin size={14} className="text-ink-mute" />
          <span className="truncate">{placeById(listing.farmPlaceId).name}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <CalendarDays size={14} className="text-ink-mute" />
          <span>Harvested {dateShort(listing.harvestDate)}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-ink-mute">Until</span>
          <span>{dateShort(listing.availableUntil)}</span>
        </div>
      </dl>

      {listing.note && <p className="mt-3 rounded-xl bg-canvas px-3 py-2 text-sm text-ink-soft">{listing.note}</p>}

      <div className="mt-auto pt-4">
        <Button variant="secondary" size="sm" className="w-full" onClick={() => onView?.(listing)}>
          {actionLabel}
        </Button>
      </div>
    </article>
  )
}
