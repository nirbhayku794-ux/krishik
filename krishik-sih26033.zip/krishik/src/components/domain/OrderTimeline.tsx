import type { Order } from '@/types'
import { date, titleCase } from '@/lib/format'

const STEPS = ['pending', 'matched', 'feasibility_check', 'awaiting_confirmation', 'confirmed', 'completed'] as const

export function OrderProgress({ status }: { status: Order['status'] }) {
  if (status === 'cancelled') {
    return <p className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-800">This order was cancelled and the quantity returned to the listing.</p>
  }
  const current = STEPS.indexOf(status as (typeof STEPS)[number])
  return (
    <ol className="flex flex-wrap gap-1.5">
      {STEPS.map((step, i) => (
        <li
          key={step}
          className={`rounded-full px-2.5 py-1 text-xs font-medium ${
            i <= current ? 'bg-forest-100 text-forest-700' : 'bg-canvas text-ink-mute'
          }`}
        >
          {titleCase(step)}
        </li>
      ))}
    </ol>
  )
}

export function OrderTimeline({ order }: { order: Order }) {
  return (
    <ol className="relative space-y-3 border-l border-forest-100 pl-5">
      {order.timeline.map((event, i) => (
        <li key={`${event.at}-${i}`} className="relative">
          <span className="absolute -left-[25px] top-1.5 h-2.5 w-2.5 rounded-full bg-forest-400 ring-4 ring-white" />
          <p className="text-sm font-medium">{event.label}</p>
          <p className="text-xs text-ink-mute">
            {date(event.at)} · {event.by === 'system' ? 'Krishik' : titleCase(event.by)}
          </p>
        </li>
      ))}
    </ol>
  )
}
