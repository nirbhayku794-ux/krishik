import { ArrowRight, MoveRight, TrendingDown, TrendingUp } from 'lucide-react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import type { Forecast } from '@/types'
import { kg } from '@/lib/format'
import { Badge } from '@/components/ui/Badge'
import { Meter } from '@/components/ui/Meter'

const TREND = {
  up: { icon: TrendingUp, label: 'Increasing', tone: 'forest' as const },
  stable: { icon: MoveRight, label: 'Stable', tone: 'neutral' as const },
  down: { icon: TrendingDown, label: 'Easing', tone: 'harvest' as const },
}

export function ForecastCard({ forecast, expanded = false }: { forecast: Forecast; expanded?: boolean }) {
  const trend = TREND[forecast.trend]
  const Icon = trend.icon
  const gap = forecast.predictedDemandKg - forecast.currentSupplyKg

  return (
    <article className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span aria-hidden className="grid h-11 w-11 place-items-center rounded-xl bg-forest-50 text-xl">{forecast.emoji}</span>
          <div>
            <h3 className="font-display text-lg font-semibold leading-tight">{forecast.productName}</h3>
            <p className="text-sm text-ink-mute">Next {forecast.horizonDays} days</p>
          </div>
        </div>
        <Badge tone={trend.tone}>
          <Icon size={13} /> {trend.label}
        </Badge>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-3 text-sm">
        <div>
          <p className="text-xs text-ink-mute">Forecast demand</p>
          <p className="tnum font-display text-xl font-semibold text-forest-700">{kg(forecast.predictedDemandKg)}</p>
        </div>
        <div>
          <p className="text-xs text-ink-mute">Open right now</p>
          <p className="tnum font-display text-xl font-semibold">{kg(forecast.currentDemandKg)}</p>
        </div>
        <div>
          <p className="text-xs text-ink-mute">Listed supply</p>
          <p className="tnum font-display text-xl font-semibold">{kg(forecast.currentSupplyKg)}</p>
        </div>
      </div>

      <div className="mt-4 h-28">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={forecast.series} margin={{ top: 4, right: 4, bottom: 0, left: -18 }}>
            <defs>
              <linearGradient id={`fc-${forecast.productId}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2F7658" stopOpacity={0.35} />
                <stop offset="100%" stopColor="#2F7658" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#EDF5F0" vertical={false} />
            <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#6B7C74' }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
            <YAxis tick={{ fontSize: 11, fill: '#6B7C74' }} tickLine={false} axisLine={false} width={44} />
            <Tooltip
              contentStyle={{ borderRadius: 12, border: '1px solid #D6E8DD', fontSize: 12 }}
              formatter={(value: number, name) => [`${value} kg`, name === 'demandKg' ? 'Forecast demand' : 'Expected supply']}
            />
            <Area type="monotone" dataKey="demandKg" stroke="#2F7658" strokeWidth={2} fill={`url(#fc-${forecast.productId})`} />
            <Area type="monotone" dataKey="supplyKg" stroke="#D99B22" strokeWidth={1.5} strokeDasharray="4 4" fill="none" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-3">
        <Meter
          value={Math.min(forecast.currentSupplyKg, forecast.predictedDemandKg)}
          max={Math.max(forecast.predictedDemandKg, 1)}
          tone={gap > 0 ? 'harvest' : 'forest'}
          label={gap > 0 ? `${kg(gap)} of forecast demand is not covered by listed supply` : 'Listed supply covers the forecast'}
        />
      </div>

      <p className="mt-3 text-sm text-ink-soft">{forecast.recommendation}</p>

      {expanded && (
        <div className="mt-4 border-t border-forest-100 pt-3">
          <p className="text-sm font-medium">Why this forecast</p>
          <ul className="mt-2 space-y-2">
            {forecast.factors.map((factor) => (
              <li key={factor.label} className="flex items-start gap-2 text-sm">
                <ArrowRight size={14} className="mt-1 shrink-0 text-forest-500" />
                <span>
                  <span className="font-medium">{factor.label}</span>
                  <span className="text-ink-mute"> ({Math.round(factor.weight * 100)}% weight)</span>
                  <span className="block text-ink-soft">{factor.note}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <p className="mt-3 text-xs text-ink-mute">
        Prototype forecast · deterministic model on seeded data · {forecast.confidence}% confidence band. Not a guarantee.
      </p>
    </article>
  )
}
