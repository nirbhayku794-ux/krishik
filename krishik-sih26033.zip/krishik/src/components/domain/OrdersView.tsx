import { useState } from 'react'
import { ArrowRight } from 'lucide-react'
import type { Order, Role } from '@/types'
import { placeById, productById } from '@/data/seed'
import { date, inr, kg, perKg } from '@/lib/format'
import { useService } from '@/lib/useService'
import { advanceOrder, cancelOrder, findUser, getOrders } from '@/services'
import { useToast } from '@/context/ToastContext'
import { OrderStatusPill } from '@/components/ui/Badge'
import { Button, LinkButton } from '@/components/ui/Button'
import { Modal, ConfirmDialog } from '@/components/ui/Modal'
import { SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState, ErrorState } from '@/components/ui/EmptyState'
import { PricePanel } from './PricePanel'
import { FeasibilityPanel } from './FeasibilityPanel'
import { OrderProgress, OrderTimeline } from './OrderTimeline'

export function OrdersView({ perspective, userId, role }: { perspective: 'seller' | 'buyer'; userId: string; role: Role }) {
  const { notify } = useToast()
  const { data: orders, loading, error, reload } = useService(
    () => getOrders(perspective === 'seller' ? { sellerId: userId } : { buyerId: userId }),
    [perspective, userId],
  )
  const [open, setOpen] = useState<Order | null>(null)
  const [confirmCancel, setConfirmCancel] = useState<Order | null>(null)

  const act = async (order: Order, action: 'accept' | 'reject' | 'confirm' | 'complete') => {
    const updated = await advanceOrder(order.id, action, role === 'admin' ? 'admin' : role)
    if (!updated) return
    setOpen(updated)
    const messages = {
      accept: 'Order accepted',
      reject: 'Order declined',
      confirm: 'Confirmation recorded',
      complete: 'Handover marked complete',
    }
    notify(messages[action], { body: `Order ${order.id.toUpperCase()} · ${productById(order.productId).name}.` })
  }

  const counterpartyOf = (order: Order) =>
    findUser(perspective === 'seller' ? order.buyerId : order.sellerId)

  return (
    <>
      {loading && <SkeletonRows count={5} />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {orders && orders.length === 0 && (
        <EmptyState
          title="No orders yet"
          body={perspective === 'seller'
            ? 'When a buyer commits to a quantity from one of your listings, it lands here for you to accept.'
            : 'Order from a listing or post a requirement, and matched orders will show up here.'}
          action={<LinkButton to={perspective === 'seller' ? '/farmer/listings/new' : '/buyer/marketplace'} size="sm">
            {perspective === 'seller' ? 'Publish a listing' : 'Browse produce'}
          </LinkButton>}
        />
      )}

      {orders && orders.length > 0 && (
        <ul className="space-y-3">
          {orders.map((order) => {
            const product = productById(order.productId)
            const other = counterpartyOf(order)
            return (
              <li key={order.id} className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <span aria-hidden className="grid h-11 w-11 place-items-center rounded-xl bg-forest-50 text-xl">{product.emoji}</span>
                    <div>
                      <h3 className="font-semibold">
                        {product.name} · {kg(order.quantityKg)}
                      </h3>
                      <p className="text-sm text-ink-mute">
                        {perspective === 'seller' ? 'Buyer' : 'Seller'}: {other?.name ?? '—'}
                        {other && ` · ${placeById(other.placeId).name}`}
                      </p>
                      <p className="tnum text-sm text-ink-soft">
                        {perKg(order.pricePerKg)} · {inr(order.pricePerKg * order.quantityKg)} to the farmer · placed {date(order.createdAt)}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <OrderStatusPill status={order.status} />
                    <Button variant="secondary" size="sm" onClick={() => setOpen(order)}>
                      Open <ArrowRight size={14} />
                    </Button>
                  </div>
                </div>

                <div className="mt-3 border-t border-forest-50 pt-3">
                  <OrderProgress status={order.status} />
                </div>

                {perspective === 'seller' && ['pending', 'feasibility_check', 'matched'].includes(order.status) && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" onClick={() => act(order, 'accept')}>Accept order</Button>
                    <Button variant="danger" size="sm" onClick={() => act(order, 'reject')}>Decline</Button>
                  </div>
                )}
                {order.status === 'awaiting_confirmation' && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" onClick={() => act(order, 'confirm')}>Confirm final price</Button>
                    <Button variant="ghost" size="sm" onClick={() => setConfirmCancel(order)}>Cancel order</Button>
                  </div>
                )}
                {order.status === 'confirmed' && (
                  <div className="mt-3">
                    <Button size="sm" onClick={() => act(order, 'complete')}>Mark handover complete</Button>
                  </div>
                )}
              </li>
            )
          })}
        </ul>
      )}

      <Modal
        open={!!open}
        onClose={() => setOpen(null)}
        width="max-w-3xl"
        title={open ? `Order ${open.id.toUpperCase()} · ${productById(open.productId).name}` : ''}
      >
        {open && (
          <div className="space-y-4">
            <OrderProgress status={open.status} />
            {open.pricing && <PricePanel pricing={open.pricing} quantityKg={open.quantityKg} />}
            {open.transport && <FeasibilityPanel analysis={open.transport} showMap={false} />}
            <div className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
              <h3 className="mb-3 font-semibold">Order history</h3>
              <OrderTimeline order={open} />
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!confirmCancel}
        onClose={() => setConfirmCancel(null)}
        onConfirm={async () => {
          if (!confirmCancel) return
          await cancelOrder(confirmCancel.id, role === 'admin' ? 'admin' : role)
          notify('Order cancelled', { body: 'The quantity has been returned to the listing.', tone: 'warning' })
        }}
        title="Cancel this order?"
        body="The reserved quantity goes back to the listing and the other side is notified. This cannot be undone in the prototype."
        confirmLabel="Cancel order"
        tone="danger"
      />
    </>
  )
}
