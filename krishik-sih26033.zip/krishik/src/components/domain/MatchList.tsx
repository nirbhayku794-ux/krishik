import { Check, X } from 'lucide-react'
import type { AggregatedMatch } from '@/types'
import { kg, perKg } from '@/lib/format'
import { placeById, productById } from '@/data/seed'
import { Badge, FeasibilityPill, VerifiedBadge } from '@/components/ui/Badge'
import { Meter } from '@/components/ui/Meter'
import { Button } from '@/components/ui/Button'

export function MatchList({
  result, onAccept, busyId,
}: { result: AggregatedMatch; onAccept?: (listingId: string, quantityKg: number) => void; busyId?: string | null }) {
  const product = productById(result.requirement.productId)
  const target = result.requirement.quantityKg

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-forest-200 bg-forest-50 p-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-sm text-forest-700">Requirement</p>
            <h3 className="font-display text-xl font-semibold">
              {product.emoji} {product.name} · {kg(target)}
            </h3>
            <p className="text-sm text-forest-700">
              Ceiling {perKg(result.requirement.maxPricePerKg)} · pickup at {placeById(result.requirement.pickupPlaceId).name}
            </p>
          </div>
          <div className="text-right">
            <p className="tnum font-display text-2xl font-semibold text-forest-700">{kg(result.matchedKg)}</p>
            <p className="text-sm text-forest-700">matched across {result.matches.length} {result.matches.length === 1 ? 'seller' : 'sellers'}</p>
          </div>
        </div>
        <div className="mt-3">
          <Meter value={result.matchedKg} max={target} label={result.shortfallKg > 0 ? `${kg(result.shortfallKg)} still unmatched` : 'Demand fully matched'} />
        </div>
      </div>

      {result.matches.map((match) => (
        <div key={match.listing.id} className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="font-semibold">{match.sellerName}</h4>
                <VerifiedBadge verified={match.sellerVerified} />
              </div>
              <p className="tnum mt-0.5 text-sm text-ink-soft">
                {kg(match.quantityKg)} · {perKg(match.pricePerKg)} · {match.distanceKm} km from pickup
              </p>
            </div>
            <div className="text-right">
              <p className="tnum font-display text-xl font-semibold text-forest-700">{match.score}%</p>
              <p className="text-xs text-ink-mute">match score (demo metric)</p>
            </div>
          </div>

          <ul className="mt-3 grid gap-1.5 sm:grid-cols-2">
            {match.checks.map((check) => (
              <li key={check.label} className="flex items-center gap-2 text-sm">
                <span className={`rounded-full p-0.5 ${check.ok ? 'bg-forest-100 text-forest-700' : 'bg-red-100 text-red-700'}`}>
                  {check.ok ? <Check size={12} /> : <X size={12} />}
                </span>
                <span className={check.ok ? 'text-ink-soft' : 'text-red-800'}>{check.label}</span>
              </li>
            ))}
          </ul>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-forest-50 pt-3">
            <div className="flex flex-wrap items-center gap-2">
              <FeasibilityPill status={match.transport.status} />
              <Badge tone="neutral">+{match.transport.additionalKm} km · ₹{match.transport.costPerKg}/kg</Badge>
            </div>
            {onAccept && (
              <Button
                size="sm"
                disabled={busyId === match.listing.id}
                onClick={() => onAccept(match.listing.id, match.quantityKg)}
              >
                {busyId === match.listing.id ? 'Placing order…' : `Order ${kg(match.quantityKg)}`}
              </Button>
            )}
          </div>
        </div>
      ))}

      {result.rejected.length > 0 && (
        <div className="rounded-2xl border border-harvest-100 bg-harvest-50/60 p-4">
          <h4 className="font-semibold">Considered but left out</h4>
          <p className="mt-1 text-sm text-ink-soft">
            These sellers have the crop at an acceptable price, but the extra travel to your pickup point cancels the
            saving. Krishik leaves them out rather than completing a sale that costs you more than the local market.
          </p>
          <ul className="mt-3 space-y-2">
            {result.rejected.map((match) => (
              <li key={match.listing.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-white px-3 py-2.5">
                <span className="text-sm">
                  <span className="font-medium">{match.sellerName}</span>
                  <span className="tnum text-ink-mute"> · {perKg(match.pricePerKg)} · {match.distanceKm} km</span>
                </span>
                <span className="flex flex-wrap items-center gap-2">
                  <Badge tone="neutral">+{match.transport.additionalKm} km · ₹{match.transport.costPerKg}/kg</Badge>
                  <FeasibilityPill status={match.transport.status} />
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
