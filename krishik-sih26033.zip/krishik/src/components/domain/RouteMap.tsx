import { placeById } from '@/data/seed'
import { projectPlace } from '@/lib/geo'

export interface MapStop {
  placeId: string
  label: string
  kind: 'farm' | 'market' | 'buyer'
}

const KIND_STYLE = {
  farm: { fill: '#215C44', ring: '#ADD1BC' },
  market: { fill: '#D99B22', ring: '#F9E6C2' },
  buyer: { fill: '#9C6644', ring: '#F3E9E2' },
}

/**
 * A schematic map drawn from the demo coordinates. It needs no tiles, no API
 * key and no network — enough to read a route at a glance, and honest about
 * being a sketch rather than a navigation surface.
 */
export function RouteMap({
  stops, baselineStops, className = '',
}: { stops: MapStop[]; baselineStops?: MapStop[]; className?: string }) {
  const W = 640
  const H = 260
  const pad = 46

  const toXY = (placeId: string) => {
    const { x, y } = projectPlace(placeId)
    return { x: pad + x * (W - pad * 2), y: pad + y * (H - pad * 2) }
  }

  const path = (list: MapStop[]) => list.map((s) => { const p = toXY(s.placeId); return `${p.x},${p.y}` }).join(' ')

  return (
    <div className={`overflow-hidden rounded-2xl border border-forest-100 bg-[linear-gradient(180deg,#F3F7F4,#FFFFFF)] ${className}`}>
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label="Schematic route between farm, buyer and selling point">
        <defs>
          <pattern id="fieldGrid" width="32" height="32" patternUnits="userSpaceOnUse">
            <path d="M32 0H0v32" fill="none" stroke="#DCE9E1" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width={W} height={H} fill="url(#fieldGrid)" />

        {baselineStops && baselineStops.length > 1 && (
          <polyline points={path(baselineStops)} fill="none" stroke="#ADD1BC" strokeWidth="3" strokeDasharray="6 6" strokeLinecap="round" />
        )}

        <polyline points={path(stops)} fill="none" stroke="#2F7658" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />

        {stops.map((stop, i) => {
          const p = toXY(stop.placeId)
          const style = KIND_STYLE[stop.kind]
          const flip = p.x > W * 0.72
          return (
            <g key={`${stop.placeId}-${i}`}>
              <circle cx={p.x} cy={p.y} r="11" fill={style.ring} />
              <circle cx={p.x} cy={p.y} r="6" fill={style.fill} />
              <text
                x={flip ? p.x - 16 : p.x + 16}
                y={p.y - 2}
                textAnchor={flip ? 'end' : 'start'}
                fontSize="12.5"
                fontWeight="600"
                fill="#12211B"
              >
                {placeById(stop.placeId).name}
              </text>
              <text
                x={flip ? p.x - 16 : p.x + 16}
                y={p.y + 13}
                textAnchor={flip ? 'end' : 'start'}
                fontSize="11"
                fill="#6B7C74"
              >
                {stop.label}
              </text>
            </g>
          )
        })}
      </svg>
      <p className="border-t border-forest-100 px-4 py-2 text-xs text-ink-mute">
        Schematic view. Distances are straight-line estimates with a road factor applied, not turn-by-turn routing.
      </p>
    </div>
  )
}
