import { useMemo, useState } from 'react'
import { Search, SlidersHorizontal } from 'lucide-react'
import { Link } from 'react-router-dom'
import { places, productById, products } from '@/data/seed'
import type { Grade, Listing } from '@/types'
import { kg, perKg } from '@/lib/format'
import { useService } from '@/lib/useService'
import {
  calculatePriceBreakdown, calculateTransportFeasibility, createOrder, getListings, sellerName,
} from '@/services'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/context/ToastContext'
import { Button, LinkButton } from '@/components/ui/Button'
import { Field, Input, Select } from '@/components/ui/Field'
import { EmptyState, ErrorState } from '@/components/ui/EmptyState'
import { SkeletonCards } from '@/components/ui/Skeleton'
import { Modal } from '@/components/ui/Modal'
import { ListingCard } from './ListingCard'
import { PricePanel } from './PricePanel'
import { FeasibilityPanel } from './FeasibilityPanel'

export function MarketplaceBrowser({ mode }: { mode: 'public' | 'buyer' }) {
  const { user } = useAuth()
  const { notify } = useToast()
  const [search, setSearch] = useState('')
  const [productId, setProductId] = useState('')
  const [placeId, setPlaceId] = useState('any')
  const [grade, setGrade] = useState<Grade | 'any'>('any')
  const [minQuantity, setMinQuantity] = useState('')
  const [maxPrice, setMaxPrice] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [selected, setSelected] = useState<Listing | null>(null)
  const [orderQty, setOrderQty] = useState(0)
  const [placing, setPlacing] = useState(false)

  const filters = useMemo(
    () => ({
      search: search.trim() || undefined,
      productId: productId || undefined,
      placeId,
      grade,
      minQuantityKg: minQuantity ? Number(minQuantity) : undefined,
      maxPricePerKg: maxPrice ? Number(maxPrice) : undefined,
    }),
    [search, productId, placeId, grade, minQuantity, maxPrice],
  )

  const { data: listings, loading, error, reload } = useService(() => getListings(filters), [JSON.stringify(filters)])

  const viewerPlace = user?.placeId
  const openListing = (listing: Listing) => {
    setSelected(listing)
    setOrderQty(Math.min(listing.remainingKg, 100))
  }

  const analysis = useMemo(() => {
    if (!selected) return null
    const buyerPlaceId = viewerPlace ?? selected.preferredSellingPlaceId
    const product = productById(selected.productId)
    const transport = calculateTransportFeasibility({
      farmPlaceId: selected.farmPlaceId,
      preferredSellingPlaceId: selected.preferredSellingPlaceId,
      buyerPlaceId,
      quantityKg: Math.max(orderQty, 1),
      maxAdditionalKm: selected.maxAdditionalKm,
      farmerPricePerKg: selected.pricePerKg,
      referencePricePerKg: product.referencePricePerKg,
    })
    const pricing = calculatePriceBreakdown({
      farmerPricePerKg: selected.pricePerKg,
      transportPerKg: transport.costPerKg,
      quantityKg: Math.max(orderQty, 1),
      referencePricePerKg: product.referencePricePerKg,
    })
    return { transport, pricing, buyerPlaceId }
  }, [selected, orderQty, viewerPlace])

  const placeOrder = async () => {
    if (!selected || !user) return
    setPlacing(true)
    const order = await createOrder({ listingId: selected.id, buyerId: user.id, quantityKg: orderQty })
    setPlacing(false)
    if (!order) {
      notify('Order could not be placed', { body: 'That quantity is no longer available on this listing.', tone: 'warning' })
      return
    }
    notify('Order placed', { body: `${kg(orderQty)} of ${productById(selected.productId).name} sent to ${sellerName(selected.sellerId)}.` })
    setSelected(null)
  }

  return (
    <div>
      <div className="mb-5 rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[200px] flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-mute" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search crop or seller"
              className="field-input pl-9"
              aria-label="Search listings"
            />
          </div>
          <Button variant="secondary" size="md" onClick={() => setShowFilters((v) => !v)} aria-expanded={showFilters}>
            <SlidersHorizontal size={16} /> Filters
          </Button>
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <button
            onClick={() => setProductId('')}
            className={`rounded-full border px-3 py-1.5 text-sm transition ${productId === '' ? 'border-forest-500 bg-forest-50 text-forest-700' : 'border-forest-100 text-ink-soft hover:border-forest-300'}`}
          >
            All crops
          </button>
          {products.map((p) => (
            <button
              key={p.id}
              onClick={() => setProductId(p.id)}
              className={`rounded-full border px-3 py-1.5 text-sm transition ${productId === p.id ? 'border-forest-500 bg-forest-50 text-forest-700' : 'border-forest-100 text-ink-soft hover:border-forest-300'}`}
            >
              {p.emoji} {p.name}
            </button>
          ))}
        </div>

        {showFilters && (
          <div className="mt-4 grid gap-3 border-t border-forest-100 pt-4 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="Location">
              <Select value={placeId} onChange={(e) => setPlaceId(e.target.value)}>
                <option value="any">Anywhere</option>
                {places.map((place) => <option key={place.id} value={place.id}>{place.name}</option>)}
              </Select>
            </Field>
            <Field label="Minimum quantity (kg)">
              <Input type="number" min={0} value={minQuantity} onChange={(e) => setMinQuantity(e.target.value)} placeholder="Any" />
            </Field>
            <Field label="Maximum price (₹/kg)">
              <Input type="number" min={0} value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} placeholder="Any" />
            </Field>
            <Field label="Grade">
              <Select value={grade} onChange={(e) => setGrade(e.target.value as Grade | 'any')}>
                <option value="any">Any grade</option>
                <option value="A">Grade A</option>
                <option value="B">Grade B</option>
                <option value="C">Grade C</option>
              </Select>
            </Field>
          </div>
        )}
      </div>

      {loading && <SkeletonCards count={6} height="h-64" />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {!loading && !error && listings && listings.length === 0 && (
        <EmptyState
          title="No produce matches these filters"
          body="Widen the price range or clear the crop filter. New listings appear here as soon as a farmer publishes them."
          action={<Button variant="secondary" size="sm" onClick={() => { setSearch(''); setProductId(''); setPlaceId('any'); setGrade('any'); setMinQuantity(''); setMaxPrice('') }}>Clear filters</Button>}
        />
      )}

      {!loading && listings && listings.length > 0 && (
        <>
          <p className="mb-3 text-sm text-ink-mute">{listings.length} listings available</p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {listings.map((listing) => (
              <ListingCard key={listing.id} listing={listing} viewerPlaceId={viewerPlace} onView={openListing} />
            ))}
          </div>
        </>
      )}

      <Modal
        open={!!selected}
        onClose={() => setSelected(null)}
        width="max-w-3xl"
        title={selected ? `${productById(selected.productId).name} from ${sellerName(selected.sellerId)}` : ''}
        footer={
          mode === 'buyer' && user?.role === 'buyer' ? (
            <>
              <Button variant="secondary" size="sm" onClick={() => setSelected(null)}>Keep browsing</Button>
              <Button size="sm" onClick={placeOrder} disabled={placing || orderQty <= 0}>
                {placing ? 'Placing order…' : `Place order for ${kg(orderQty)}`}
              </Button>
            </>
          ) : (
            <>
              <Button variant="secondary" size="sm" onClick={() => setSelected(null)}>Close</Button>
              <LinkButton to={user ? '/buyer/marketplace' : '/login'} size="sm">
                {user ? 'Order from the buyer workspace' : 'Sign in to order'}
              </LinkButton>
            </>
          )
        }
      >
        {selected && analysis && (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-3">
              <Detail label="Available" value={kg(selected.remainingKg)} />
              <Detail label="Asking price" value={perKg(selected.pricePerKg)} />
              <Detail label="Grade" value={`Grade ${selected.grade}`} />
            </div>

            {mode === 'buyer' && user?.role === 'buyer' && (
              <Field label="Quantity to order (kg)" hint={`Up to ${kg(selected.remainingKg)} from this listing. Pricing and route update as you change it.`}>
                <Input
                  type="number"
                  min={1}
                  max={selected.remainingKg}
                  value={orderQty}
                  onChange={(e) => setOrderQty(Math.min(selected.remainingKg, Math.max(0, Number(e.target.value))))}
                />
              </Field>
            )}

            <PricePanel pricing={analysis.pricing} quantityKg={Math.max(orderQty, 1)} />

            <FeasibilityPanel
              analysis={analysis.transport}
              stops={[
                { placeId: selected.farmPlaceId, label: 'Farm', kind: 'farm' },
                { placeId: analysis.buyerPlaceId, label: 'Buyer', kind: 'buyer' },
                { placeId: selected.preferredSellingPlaceId, label: 'Usual selling point', kind: 'market' },
              ]}
              baselineStops={[
                { placeId: selected.farmPlaceId, label: 'Farm', kind: 'farm' },
                { placeId: selected.preferredSellingPlaceId, label: 'Usual selling point', kind: 'market' },
              ]}
            />

            {mode === 'public' && (
              <p className="text-sm text-ink-mute">
                Ordering, pooling and confirmation live in the buyer workspace.{' '}
                <Link to="/login" className="font-medium text-forest-700 underline underline-offset-2">Sign in with a demo account</Link> to try it.
              </p>
            )}
          </div>
        )}
      </Modal>
    </div>
  )
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-forest-100 bg-canvas/50 p-3">
      <p className="text-xs text-ink-mute">{label}</p>
      <p className="tnum mt-0.5 font-display text-lg font-semibold">{value}</p>
    </div>
  )
}
