import { ArrowRight, IndianRupee } from 'lucide-react'
import type { PriceBreakdown } from '@/types'
import { inr, kg, perKg } from '@/lib/format'
import { advantageCopy } from '@/services'
import { Badge } from '@/components/ui/Badge'

const TONE = {
  'buyer-advantage': { tone: 'forest' as const, label: 'Cheaper than reference price' },
  neutral: { tone: 'harvest' as const, label: 'Close to reference price' },
  'no-advantage': { tone: 'danger' as const, label: 'No price advantage today' },
}

export function PricePanel({ pricing, quantityKg, compact = false }: { pricing: PriceBreakdown; quantityKg: number; compact?: boolean }) {
  const rows = [
    { label: 'Farmer asking price', value: perKg(pricing.farmerPricePerKg) },
    { label: 'Estimated additional transport', value: perKg(pricing.transportPerKg) },
    { label: 'Platform cost (2%)', value: perKg(pricing.platformPerKg) },
    { label: 'Handling and grading', value: perKg(pricing.handlingPerKg) },
  ]
  const tone = TONE[pricing.advantage]

  return (
    <div className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 text-base font-semibold">
          <IndianRupee size={16} className="text-forest-600" /> What each side pays
        </h3>
        <Badge tone={tone.tone}>{tone.label}</Badge>
      </div>

      <dl className="mt-4 space-y-2 text-sm">
        {rows.map((row) => (
          <div key={row.label} className="flex items-baseline justify-between gap-4">
            <dt className="text-ink-soft">{row.label}</dt>
            <dd className="tnum font-medium">{row.value}</dd>
          </div>
        ))}
        <div className="flex items-baseline justify-between gap-4 border-t border-forest-100 pt-2.5">
          <dt className="font-semibold">Estimated final buyer price</dt>
          <dd className="tnum font-display text-lg font-semibold">{perKg(pricing.finalBuyerPricePerKg)}</dd>
        </div>
        <div className="flex items-baseline justify-between gap-4">
          <dt className="text-ink-soft">Reference market price (demo)</dt>
          <dd className="tnum text-ink-soft line-through decoration-ink-mute/50">{perKg(pricing.referencePricePerKg)}</dd>
        </div>
      </dl>

      <p className={`mt-3 rounded-xl px-3 py-2 text-sm ${pricing.advantage === 'no-advantage' ? 'bg-red-50 text-red-800' : 'bg-forest-50 text-forest-700'}`}>
        {pricing.differencePerKg > 0
          ? `Buyer saves about ${perKg(pricing.differencePerKg)} against the reference price.`
          : advantageCopy[pricing.advantage]}
      </p>

      {!compact && (
        <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto_1fr]">
          <div className="rounded-xl border border-forest-100 bg-canvas/60 p-3">
            <p className="text-xs text-ink-mute">Farmer receives</p>
            <p className="tnum font-display text-xl font-semibold text-forest-700">{inr(pricing.farmerEarnings)}</p>
            <p className="text-xs text-ink-mute">{perKg(pricing.farmerPricePerKg)} × {kg(quantityKg)}</p>
          </div>
          <div className="hidden items-center justify-center text-ink-mute sm:flex">
            <ArrowRight size={18} />
          </div>
          <div className="rounded-xl border border-forest-100 bg-canvas/60 p-3">
            <p className="text-xs text-ink-mute">Buyer pays</p>
            <p className="tnum font-display text-xl font-semibold">{inr(pricing.buyerTotal)}</p>
            <p className="text-xs text-ink-mute">{perKg(pricing.finalBuyerPricePerKg)} × {kg(quantityKg)}</p>
          </div>
        </div>
      )}

      <p className="mt-3 text-xs text-ink-mute">
        Reference price is demo mandi data used for comparison only. Krishik does not promise a lower price on every transaction.
      </p>
    </div>
  )
}
