import { Check, Route, Truck, X } from 'lucide-react'
import type { TransportAnalysis } from '@/types'
import { inr, round } from '@/lib/format'
import { FeasibilityPill } from '@/components/ui/Badge'
import { RouteMap, type MapStop } from './RouteMap'

export function FeasibilityPanel({
  analysis, stops, baselineStops, showMap = true,
}: { analysis: TransportAnalysis; stops?: MapStop[]; baselineStops?: MapStop[]; showMap?: boolean }) {
  const figures = [
    { label: 'Trip already planned', value: `${analysis.baselineKm} km`, hint: 'Farm to usual selling point' },
    { label: 'Route with this buyer', value: `${analysis.routeKm} km`, hint: 'Farm → buyer → selling point' },
    { label: 'Additional distance', value: `${analysis.additionalKm} km`, hint: 'What this buyer actually adds' },
    { label: 'Additional transport', value: `${inr(analysis.additionalCost)}`, hint: `≈ ₹${round(analysis.costPerKg, 2)}/kg` },
  ]

  return (
    <div className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 text-base font-semibold">
          <Route size={16} className="text-forest-600" /> Transport feasibility
        </h3>
        <FeasibilityPill status={analysis.status} />
      </div>

      <p className="mt-2 text-sm text-ink-soft">{analysis.message}</p>

      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {figures.map((f) => (
          <div key={f.label} className="rounded-xl border border-forest-100 bg-canvas/50 p-3">
            <p className="text-xs text-ink-mute">{f.label}</p>
            <p className="tnum mt-0.5 font-display text-lg font-semibold">{f.value}</p>
            <p className="text-xs text-ink-mute">{f.hint}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl bg-forest-50 px-3 py-2 text-sm text-forest-700">
        <Truck size={15} />
        <span>
          {analysis.vehicle.label} · ₹{analysis.vehicle.costPerKm}/km · up to {analysis.vehicle.capacityKg.toLocaleString('en-IN')} kg
        </span>
      </div>

      <ul className="mt-4 grid gap-2 sm:grid-cols-2">
        {analysis.reasons.map((r) => (
          <li key={r.label} className="flex items-start gap-2 text-sm">
            <span className={`mt-0.5 rounded-full p-0.5 ${r.ok ? 'bg-forest-100 text-forest-700' : 'bg-red-100 text-red-700'}`}>
              {r.ok ? <Check size={12} /> : <X size={12} />}
            </span>
            <span className={r.ok ? 'text-ink-soft' : 'text-red-800'}>{r.label}</span>
          </li>
        ))}
      </ul>

      {showMap && stops && <RouteMap stops={stops} baselineStops={baselineStops} className="mt-4" />}

      <p className="mt-3 text-xs text-ink-mute">
        Krishik runs no vehicles. This is decision support built on the farmer's existing movement, not a booking.
      </p>
    </div>
  )
}
