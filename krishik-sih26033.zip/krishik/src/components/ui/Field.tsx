import type { InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from 'react'

export function Field({ label, hint, error, children, required }: { label: string; hint?: string; error?: string; children: ReactNode; required?: boolean }) {
  return (
    <label className="block">
      <span className="field-label">
        {label}
        {required && <span className="ml-0.5 text-harvest-600">*</span>}
      </span>
      {children}
      {error
        ? <span role="alert" className="mt-1 block text-xs font-medium text-red-700">{error}</span>
        : hint && <span className="mt-1 block text-xs text-ink-mute">{hint}</span>}
    </label>
  )
}

export const Input = (props: InputHTMLAttributes<HTMLInputElement>) => (
  <input {...props} className={`field-input ${props.className ?? ''}`} />
)

export const Textarea = (props: TextareaHTMLAttributes<HTMLTextAreaElement>) => (
  <textarea {...props} className={`field-input ${props.className ?? ''}`} />
)

export const Select = (props: SelectHTMLAttributes<HTMLSelectElement>) => (
  <select {...props} className={`field-input appearance-none bg-[url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%236B7C74" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>')] bg-[length:18px] bg-[right_0.75rem_center] bg-no-repeat pr-10 ${props.className ?? ''}`} />
)
