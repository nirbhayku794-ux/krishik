import type { ReactNode } from 'react'

export function Stat({
  label, value, hint, icon, tone = 'default', estimated,
}: {
  label: string
  value: ReactNode
  hint?: string
  icon?: ReactNode
  tone?: 'default' | 'accent'
  estimated?: boolean
}) {
  return (
    <div className={`rounded-2xl border p-4 ${tone === 'accent' ? 'border-forest-200 bg-forest-50' : 'border-forest-100 bg-white shadow-card'}`}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm text-ink-mute">{label}</p>
        {icon && <span className="text-forest-500">{icon}</span>}
      </div>
      <p className="tnum mt-1.5 font-display text-2xl font-semibold text-ink">{value}</p>
      {(hint || estimated) && (
        <p className="mt-1 text-xs text-ink-mute">
          {estimated && <span className="mr-1 rounded bg-canvas px-1.5 py-0.5 text-[11px] text-ink-soft">estimated</span>}
          {hint}
        </p>
      )}
    </div>
  )
}
