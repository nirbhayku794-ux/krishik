import type { ReactNode } from 'react'
import { Sprout } from 'lucide-react'

export function EmptyState({ title, body, action, icon }: { title: string; body: string; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-forest-200 bg-white/70 px-6 py-12 text-center">
      <span className="mb-3 rounded-full bg-forest-50 p-3 text-forest-600">{icon ?? <Sprout size={20} />}</span>
      <h3 className="text-base font-semibold">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-ink-mute">{body}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-2xl border border-red-200 bg-red-50/60 px-5 py-4 text-sm text-red-800">
      <p className="font-medium">This view could not load.</p>
      <p className="mt-0.5 text-red-700">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="mt-2 rounded-lg border border-red-300 px-3 py-1.5 text-sm font-medium hover:bg-red-100">
          Try again
        </button>
      )}
    </div>
  )
}
