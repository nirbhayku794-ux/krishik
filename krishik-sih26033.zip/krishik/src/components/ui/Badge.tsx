import type { ReactNode } from 'react'
import { BadgeCheck } from 'lucide-react'
import type { FeasibilityStatus, OrderStatus } from '@/types'

type Tone = 'forest' | 'harvest' | 'neutral' | 'danger' | 'clay'

const TONES: Record<Tone, string> = {
  forest: 'bg-forest-50 text-forest-700 border-forest-200',
  harvest: 'bg-harvest-50 text-harvest-600 border-harvest-100',
  neutral: 'bg-canvas text-ink-soft border-forest-100',
  danger: 'bg-red-50 text-red-700 border-red-200',
  clay: 'bg-clay-100 text-clay-500 border-clay-100',
}

export function Badge({ children, tone = 'neutral', className = '' }: { children: ReactNode; tone?: Tone; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium ${TONES[tone]} ${className}`}>
      {children}
    </span>
  )
}

export function VerifiedBadge({ verified }: { verified: boolean }) {
  if (!verified) return <Badge tone="neutral">Not yet verified</Badge>
  return (
    <Badge tone="forest">
      <BadgeCheck size={13} /> Verified
    </Badge>
  )
}

const ORDER_TONES: Record<OrderStatus, Tone> = {
  pending: 'neutral',
  matched: 'forest',
  feasibility_check: 'harvest',
  awaiting_confirmation: 'harvest',
  confirmed: 'forest',
  completed: 'forest',
  cancelled: 'danger',
}

const ORDER_LABELS: Record<OrderStatus, string> = {
  pending: 'Pending',
  matched: 'Matched',
  feasibility_check: 'Feasibility check',
  awaiting_confirmation: 'Awaiting confirmation',
  confirmed: 'Confirmed',
  completed: 'Completed',
  cancelled: 'Cancelled',
}

export const orderStatusLabel = (status: OrderStatus) => ORDER_LABELS[status]

export function OrderStatusPill({ status }: { status: OrderStatus }) {
  return <Badge tone={ORDER_TONES[status]}>{ORDER_LABELS[status]}</Badge>
}

export const FEASIBILITY_LABEL: Record<FeasibilityStatus, string> = {
  feasible: 'Economically feasible',
  'low-advantage': 'Conditionally feasible',
  'not-feasible': 'Not economically feasible',
}

export function FeasibilityPill({ status }: { status: FeasibilityStatus }) {
  const tone: Tone = status === 'feasible' ? 'forest' : status === 'low-advantage' ? 'harvest' : 'danger'
  return <Badge tone={tone}>{FEASIBILITY_LABEL[status]}</Badge>
}
