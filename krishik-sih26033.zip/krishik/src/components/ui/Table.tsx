import type { ReactNode } from 'react'

export function DataTable<T>({
  rows, columns, empty, rowKey,
}: {
  rows: T[]
  columns: { header: string; cell: (row: T) => ReactNode; align?: 'left' | 'right'; hideOnMobile?: boolean }[]
  empty?: ReactNode
  rowKey: (row: T) => string
}) {
  if (rows.length === 0 && empty) return <>{empty}</>
  return (
    <div className="overflow-x-auto rounded-2xl border border-forest-100 bg-white shadow-card">
      <table className="w-full min-w-[520px] text-sm">
        <thead>
          <tr className="border-b border-forest-100 text-left text-xs text-ink-mute">
            {columns.map((col) => (
              <th key={col.header} className={`px-4 py-3 font-medium ${col.align === 'right' ? 'text-right' : ''} ${col.hideOnMobile ? 'hidden md:table-cell' : ''}`}>
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={rowKey(row)} className="border-b border-forest-50 last:border-0 hover:bg-canvas/70">
              {columns.map((col) => (
                <td key={col.header} className={`px-4 py-3 align-middle ${col.align === 'right' ? 'text-right tnum' : ''} ${col.hideOnMobile ? 'hidden md:table-cell' : ''}`}>
                  {col.cell(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
