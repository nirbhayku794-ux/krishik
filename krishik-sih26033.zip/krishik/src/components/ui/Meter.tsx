export function Meter({ value, max, tone = 'forest', label }: { value: number; max: number; tone?: 'forest' | 'harvest'; label?: string }) {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0
  return (
    <div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-forest-50">
        <div
          className={`h-full rounded-full transition-[width] duration-500 ${tone === 'forest' ? 'bg-forest-500' : 'bg-harvest-500'}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      {label && <p className="mt-1 text-xs text-ink-mute">{label}</p>}
    </div>
  )
}

export function DemoNote({ children }: { children: React.ReactNode }) {
  return (
    <p className="rounded-xl border border-harvest-100 bg-harvest-50/70 px-3 py-2 text-xs text-harvest-600">
      {children}
    </p>
  )
}
