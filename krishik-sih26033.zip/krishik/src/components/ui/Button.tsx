import { forwardRef, type ButtonHTMLAttributes } from 'react'
import { Link } from 'react-router-dom'

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'harvest'
type Size = 'sm' | 'md' | 'lg'

const BASE =
  'inline-flex items-center justify-center gap-2 rounded-xl font-medium transition active:translate-y-px disabled:pointer-events-none disabled:opacity-50'

const VARIANTS: Record<Variant, string> = {
  primary: 'bg-forest-600 text-white shadow-card hover:bg-forest-700',
  secondary: 'border border-forest-200 bg-white text-forest-700 hover:border-forest-400 hover:bg-forest-50',
  ghost: 'text-ink-soft hover:bg-forest-50 hover:text-forest-700',
  danger: 'border border-red-200 bg-white text-red-700 hover:bg-red-50',
  harvest: 'bg-harvest-500 text-white shadow-card hover:bg-harvest-600',
}

const SIZES: Record<Size, string> = {
  sm: 'px-3 py-1.5 text-sm',
  md: 'px-4 py-2.5 text-[15px]',
  lg: 'px-5 py-3 text-base',
}

export const buttonClass = (variant: Variant = 'primary', size: Size = 'md', extra = '') =>
  `${BASE} ${VARIANTS[variant]} ${SIZES[size]} ${extra}`

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
}

export const Button = forwardRef<HTMLButtonElement, Props>(function Button(
  { variant = 'primary', size = 'md', className = '', ...rest }, ref,
) {
  return <button ref={ref} className={buttonClass(variant, size, className)} {...rest} />
})

export function LinkButton({
  to, variant = 'primary', size = 'md', className = '', children,
}: { to: string; variant?: Variant; size?: Size; className?: string; children: React.ReactNode }) {
  return (
    <Link to={to} className={buttonClass(variant, size, className)}>
      {children}
    </Link>
  )
}
