import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import type { Role } from '@/types'
import { HOME_FOR } from './nav'

export function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user } = useAuth()
  const location = useLocation()
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />
  return <>{children}</>
}

export function RequireRole({ roles, children }: { roles: Role[]; children: React.ReactNode }) {
  const { user, role } = useAuth()
  const location = useLocation()
  if (!user || !role) return <Navigate to="/login" replace state={{ from: location.pathname }} />
  if (!roles.includes(role)) return <Navigate to={HOME_FOR[role]} replace />
  return <>{children}</>
}
