import {
  BarChart3, Boxes, ClipboardList, Gauge, LayoutDashboard, LineChart, ListChecks,
  MapPin, PackagePlus, ShoppingBasket, Sparkles, Store, TrendingUp, Users, Warehouse,
} from 'lucide-react'
import type { Role } from '@/types'

export interface NavItem { to: string; label: string; icon: typeof Gauge; end?: boolean }

export const NAV: Record<Role, NavItem[]> = {
  farmer: [
    { to: '/farmer/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/farmer/listings', label: 'My listings', icon: Boxes },
    { to: '/farmer/listings/new', label: 'New listing', icon: PackagePlus },
    { to: '/farmer/orders', label: 'Orders', icon: ClipboardList },
    { to: '/farmer/demand', label: 'Demand nearby', icon: TrendingUp },
    { to: '/farmer/forecast', label: 'Forecast', icon: LineChart },
    { to: '/logistics', label: 'Transport check', icon: MapPin },
  ],
  fpo: [
    { to: '/fpo/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/fpo/produce', label: 'Aggregated produce', icon: Warehouse },
    { to: '/farmer/listings/new', label: 'Add produce', icon: PackagePlus },
    { to: '/fpo/requirements', label: 'Bulk requirements', icon: ListChecks },
    { to: '/farmer/orders', label: 'Orders', icon: ClipboardList },
    { to: '/fpo/analytics', label: 'Analytics', icon: BarChart3 },
    { to: '/ai-insights', label: 'Demand forecast', icon: Sparkles },
  ],
  buyer: [
    { to: '/buyer/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/buyer/marketplace', label: 'Browse produce', icon: Store },
    { to: '/buyer/requirements', label: 'My requirements', icon: ShoppingBasket },
    { to: '/buyer/matches', label: 'Supply matches', icon: ListChecks },
    { to: '/buyer/orders', label: 'Orders', icon: ClipboardList },
    { to: '/logistics', label: 'Transport check', icon: MapPin },
    { to: '/ai-insights', label: 'Demand forecast', icon: Sparkles },
  ],
  admin: [
    { to: '/admin/dashboard', label: 'Dashboard', icon: Gauge },
    { to: '/admin/users', label: 'Users', icon: Users },
    { to: '/admin/listings', label: 'Listings', icon: Boxes },
    { to: '/admin/orders', label: 'Orders', icon: ClipboardList },
    { to: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
    { to: '/ai-insights', label: 'Demand forecast', icon: Sparkles },
  ],
}

export const HOME_FOR: Record<Role, string> = {
  farmer: '/farmer/dashboard',
  fpo: '/fpo/dashboard',
  buyer: '/buyer/dashboard',
  admin: '/admin/dashboard',
}
