import { useEffect, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { LogOut, Menu, Repeat, X } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { placeById } from '@/data/seed'
import { initials, titleCase } from '@/lib/format'
import { Button } from '@/components/ui/Button'
import { Logo } from './Logo'
import { HOME_FOR, NAV } from './nav'

export function AppShell() {
  const { user, role, signOut, signInAs } = useAuth()
  const [open, setOpen] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()

  useEffect(() => setOpen(false), [location.pathname])

  if (!user || !role) return null
  const items = NAV[role]

  const sidebar = (
    <div className="flex h-full flex-col gap-1 p-3">
      <Link to="/" className="mb-3 px-2 py-1">
        <Logo />
      </Link>
      <nav className="flex flex-1 flex-col gap-0.5">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/farmer/listings'}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                isActive ? 'bg-forest-600 text-white shadow-card' : 'text-ink-soft hover:bg-forest-50 hover:text-forest-700'
              }`
            }
          >
            <item.icon size={17} />
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="rounded-2xl border border-forest-100 bg-canvas/70 p-3">
        <div className="flex items-center gap-3">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-forest-600 text-sm font-semibold text-white">
            {initials(user.name)}
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{user.name}</p>
            <p className="truncate text-xs text-ink-mute">
              {titleCase(role)} · {placeById(user.placeId).name}
            </p>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-1.5">
          {(['farmer', 'fpo', 'buyer', 'admin'] as const)
            .filter((r) => r !== role)
            .map((r) => (
              <button
                key={r}
                onClick={() => { signInAs(r); navigate(HOME_FOR[r]) }}
                className="flex items-center justify-center gap-1 rounded-lg border border-forest-100 bg-white px-2 py-1.5 text-xs font-medium text-ink-soft transition hover:border-forest-300 hover:text-forest-700"
              >
                <Repeat size={11} /> {titleCase(r)}
              </button>
            ))}
        </div>
        <Button variant="ghost" size="sm" className="mt-1.5 w-full" onClick={() => { signOut(); navigate('/') }}>
          <LogOut size={14} /> Sign out
        </Button>
      </div>
    </div>
  )

  return (
    <div className="flex min-h-full bg-canvas">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 border-r border-forest-100 bg-white lg:block">{sidebar}</aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-40 flex items-center justify-between gap-3 border-b border-forest-100 bg-canvas/90 px-4 py-3 backdrop-blur lg:hidden" style={{ top: 'env(safe-area-inset-top, 0px)' }}>
          <Link to="/"><Logo /></Link>
          <button onClick={() => setOpen(true)} className="rounded-lg p-2 text-ink-soft" aria-label="Open menu">
            <Menu size={20} />
          </button>
        </header>

        {open && (
          <div className="fixed inset-0 z-[70] lg:hidden">
            <button className="absolute inset-0 bg-ink/40" aria-label="Close menu" onClick={() => setOpen(false)} />
            <div className="absolute inset-y-0 left-0 w-72 max-w-[85%] animate-rise bg-white shadow-lift">
              <button onClick={() => setOpen(false)} className="absolute right-3 top-3 rounded-lg p-1.5 text-ink-mute" aria-label="Close menu">
                <X size={18} />
              </button>
              {sidebar}
            </div>
          </div>
        )}

        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6 lg:py-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
