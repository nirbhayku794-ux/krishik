import { useState } from 'react'
import { Link, NavLink, Outlet } from 'react-router-dom'
import { Menu, X } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { LinkButton } from '@/components/ui/Button'
import { Logo } from './Logo'

const LINKS = [
  { to: '/marketplace', label: 'Marketplace' },
  { to: '/farmer', label: 'For farmers' },
  { to: '/buyer', label: 'For buyers' },
  { to: '/about', label: 'About' },
]

export function PublicLayout() {
  const [open, setOpen] = useState(false)
  const { user } = useAuth()

  return (
    <div className="flex min-h-full flex-col">
      <header className="sticky top-0 z-50 border-b border-forest-100/80 bg-canvas/85 backdrop-blur" style={{ top: 'env(safe-area-inset-top, 0px)' }}>
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <Link to="/" className="shrink-0" aria-label="Krishik home">
            <Logo />
          </Link>

          <nav className="hidden items-center gap-1 md:flex">
            {LINKS.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  `rounded-lg px-3 py-2 text-sm font-medium transition ${isActive ? 'bg-forest-50 text-forest-700' : 'text-ink-soft hover:text-forest-700'}`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </nav>

          <div className="hidden items-center gap-2 md:flex">
            {user ? (
              <LinkButton to="/dashboard" size="sm">Go to dashboard</LinkButton>
            ) : (
              <>
                <LinkButton to="/login" variant="ghost" size="sm">Sign in</LinkButton>
                <LinkButton to="/register" size="sm">Join Krishik</LinkButton>
              </>
            )}
          </div>

          <button className="rounded-lg p-2 text-ink-soft md:hidden" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu" aria-expanded={open}>
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {open && (
          <div className="border-t border-forest-100 bg-white px-4 py-3 md:hidden">
            <nav className="flex flex-col">
              {LINKS.map((link) => (
                <NavLink key={link.to} to={link.to} onClick={() => setOpen(false)} className="rounded-lg px-3 py-2.5 text-sm font-medium text-ink-soft">
                  {link.label}
                </NavLink>
              ))}
            </nav>
            <div className="mt-2 flex gap-2">
              {user ? (
                <LinkButton to="/dashboard" size="sm" className="flex-1">Dashboard</LinkButton>
              ) : (
                <>
                  <LinkButton to="/login" variant="secondary" size="sm" className="flex-1">Sign in</LinkButton>
                  <LinkButton to="/register" size="sm" className="flex-1">Join</LinkButton>
                </>
              )}
            </div>
          </div>
        )}
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="border-t border-forest-100 bg-white">
        <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <Logo />
            <p className="mt-3 max-w-sm text-sm text-ink-soft">
              A direct farm-to-buyer marketplace built for Smart India Hackathon problem statement SIH26033. Prototype data, real logic.
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold">Product</h3>
            <ul className="mt-2 space-y-1.5 text-sm text-ink-soft">
              <li><Link to="/marketplace" className="hover:text-forest-700">Marketplace</Link></li>
              <li><Link to="/logistics" className="hover:text-forest-700">Transport feasibility</Link></li>
              <li><Link to="/ai-insights" className="hover:text-forest-700">Demand forecast</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold">Who it serves</h3>
            <ul className="mt-2 space-y-1.5 text-sm text-ink-soft">
              <li><Link to="/farmer" className="hover:text-forest-700">Farmers and FPOs</Link></li>
              <li><Link to="/buyer" className="hover:text-forest-700">Consumers and bulk buyers</Link></li>
              <li><Link to="/login" className="hover:text-forest-700">Demo accounts</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-forest-100 px-4 py-4 text-center text-xs text-ink-mute sm:px-6">
          Krishik · SIH26033 prototype · all figures are seeded demo data
        </div>
      </footer>
    </div>
  )
}
