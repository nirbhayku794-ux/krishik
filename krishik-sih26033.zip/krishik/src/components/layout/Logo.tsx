export function Logo({ tone = 'dark' }: { tone?: 'dark' | 'light' }) {
  return (
    <span className="inline-flex items-center gap-2">
      <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden className="shrink-0">
        <rect width="32" height="32" rx="9" fill="#184634" />
        <path d="M16 24V13" stroke="#ADD1BC" strokeWidth="2" strokeLinecap="round" />
        <path d="M16 15c0-3.3 2.6-6 6-6 0 3.3-2.6 6-6 6Z" fill="#7DB499" />
        <path d="M16 19c0-3.3-2.6-6-6-6 0 3.3 2.6 6 6 6Z" fill="#D99B22" />
      </svg>
      <span className={`font-display text-lg font-semibold tracking-tight ${tone === 'light' ? 'text-white' : 'text-ink'}`}>
        Krishik
      </span>
    </span>
  )
}
