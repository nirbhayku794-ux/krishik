import { Route, Routes } from 'react-router-dom'
import { PublicLayout } from '@/components/layout/PublicLayout'
import { AppShell } from '@/components/layout/AppShell'
import { RequireAuth, RequireRole } from '@/components/layout/Guards'

import { Landing } from '@/pages/public/Landing'
import { Login } from '@/pages/public/Login'
import { Register } from '@/pages/public/Register'
import { About } from '@/pages/public/About'
import { MarketplacePreview } from '@/pages/public/MarketplacePreview'
import { FarmerInfo } from '@/pages/public/FarmerInfo'
import { BuyerInfo } from '@/pages/public/BuyerInfo'

import { FarmerDashboard } from '@/pages/farmer/FarmerDashboard'
import { FarmerListings } from '@/pages/farmer/FarmerListings'
import { NewListing } from '@/pages/farmer/NewListing'
import { FarmerOrders } from '@/pages/farmer/FarmerOrders'
import { FarmerDemand } from '@/pages/farmer/FarmerDemand'
import { FarmerForecast } from '@/pages/farmer/FarmerForecast'

import { BuyerDashboard } from '@/pages/buyer/BuyerDashboard'
import { BuyerMarketplace } from '@/pages/buyer/BuyerMarketplace'
import { BuyerRequirements } from '@/pages/buyer/BuyerRequirements'
import { BuyerMatches } from '@/pages/buyer/BuyerMatches'
import { BuyerOrders } from '@/pages/buyer/BuyerOrders'

import { FPODashboard } from '@/pages/fpo/FPODashboard'
import { FPOProduce } from '@/pages/fpo/FPOProduce'
import { FPORequirements } from '@/pages/fpo/FPORequirements'
import { FPOAnalytics } from '@/pages/fpo/FPOAnalytics'

import { AdminDashboard } from '@/pages/admin/AdminDashboard'
import { AdminUsers } from '@/pages/admin/AdminUsers'
import { AdminListings } from '@/pages/admin/AdminListings'
import { AdminOrders } from '@/pages/admin/AdminOrders'
import { AdminAnalytics } from '@/pages/admin/AdminAnalytics'

import { DashboardRouter } from '@/pages/shared/DashboardRouter'
import { Logistics } from '@/pages/shared/Logistics'
import { AIInsights } from '@/pages/shared/AIInsights'
import { NotFound } from '@/pages/shared/NotFound'

const SELLER = ['farmer', 'fpo'] as const

export default function App() {
  return (
    <Routes>
      {/* Public */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/about" element={<About />} />
        <Route path="/marketplace" element={<MarketplacePreview />} />
        <Route path="/farmer" element={<FarmerInfo />} />
        <Route path="/buyer" element={<BuyerInfo />} />
        <Route path="*" element={<NotFound />} />
      </Route>

      {/* Authenticated workspaces */}
      <Route element={<RequireAuth><AppShell /></RequireAuth>}>
        <Route path="/dashboard" element={<DashboardRouter />} />

        <Route path="/farmer/dashboard" element={<RequireRole roles={['farmer']}><FarmerDashboard /></RequireRole>} />
        <Route path="/farmer/listings" element={<RequireRole roles={['farmer']}><FarmerListings /></RequireRole>} />
        <Route path="/farmer/listings/new" element={<RequireRole roles={[...SELLER]}><NewListing /></RequireRole>} />
        <Route path="/farmer/orders" element={<RequireRole roles={[...SELLER]}><FarmerOrders /></RequireRole>} />
        <Route path="/farmer/demand" element={<RequireRole roles={[...SELLER]}><FarmerDemand /></RequireRole>} />
        <Route path="/farmer/forecast" element={<RequireRole roles={[...SELLER]}><FarmerForecast /></RequireRole>} />

        <Route path="/buyer/dashboard" element={<RequireRole roles={['buyer']}><BuyerDashboard /></RequireRole>} />
        <Route path="/buyer/marketplace" element={<RequireRole roles={['buyer']}><BuyerMarketplace /></RequireRole>} />
        <Route path="/buyer/requirements" element={<RequireRole roles={['buyer']}><BuyerRequirements /></RequireRole>} />
        <Route path="/buyer/matches" element={<RequireRole roles={['buyer']}><BuyerMatches /></RequireRole>} />
        <Route path="/buyer/orders" element={<RequireRole roles={['buyer']}><BuyerOrders /></RequireRole>} />

        <Route path="/fpo/dashboard" element={<RequireRole roles={['fpo']}><FPODashboard /></RequireRole>} />
        <Route path="/fpo/produce" element={<RequireRole roles={['fpo']}><FPOProduce /></RequireRole>} />
        <Route path="/fpo/requirements" element={<RequireRole roles={['fpo']}><FPORequirements /></RequireRole>} />
        <Route path="/fpo/analytics" element={<RequireRole roles={['fpo']}><FPOAnalytics /></RequireRole>} />

        <Route path="/admin/dashboard" element={<RequireRole roles={['admin']}><AdminDashboard /></RequireRole>} />
        <Route path="/admin/users" element={<RequireRole roles={['admin']}><AdminUsers /></RequireRole>} />
        <Route path="/admin/listings" element={<RequireRole roles={['admin']}><AdminListings /></RequireRole>} />
        <Route path="/admin/orders" element={<RequireRole roles={['admin']}><AdminOrders /></RequireRole>} />
        <Route path="/admin/analytics" element={<RequireRole roles={['admin']}><AdminAnalytics /></RequireRole>} />

        <Route path="/logistics" element={<Logistics />} />
        <Route path="/ai-insights" element={<AIInsights />} />
      </Route>
    </Routes>
  )
}
