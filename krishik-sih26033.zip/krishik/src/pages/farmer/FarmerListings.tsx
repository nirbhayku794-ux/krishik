import { useState } from 'react'
import { PackagePlus } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/context/ToastContext'
import { useService } from '@/lib/useService'
import { getListingsBySeller, removeListing, updateListingStatus } from '@/services'
import { placeById, productById } from '@/data/seed'
import { date, kg, perKg } from '@/lib/format'
import { PageHeader } from '@/components/ui/PageHeader'
import { DataTable } from '@/components/ui/Table'
import { Badge } from '@/components/ui/Badge'
import { Button, LinkButton } from '@/components/ui/Button'
import { ConfirmDialog } from '@/components/ui/Modal'
import { SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState, ErrorState } from '@/components/ui/EmptyState'
import { Meter } from '@/components/ui/Meter'
import type { Listing } from '@/types'

export function FarmerListings() {
  const { user } = useAuth()
  const { notify } = useToast()
  const sellerId = user?.id ?? ''
  const { data: listings, loading, error, reload } = useService(() => getListingsBySeller(sellerId), [sellerId])
  const [toRemove, setToRemove] = useState<Listing | null>(null)

  const onRemove = async (listing: Listing) => {
    await removeListing(listing.id)
    notify('Listing removed', { body: `${productById(listing.productId).name} is no longer visible to buyers.` })
  }

  const onPause = async (listing: Listing) => {
    const next = listing.status === 'active' ? 'reserved' : 'active'
    await updateListingStatus(listing.id, next)
    notify(next === 'active' ? 'Listing published again' : 'Listing paused', {
      body: next === 'active' ? 'Buyers can see and order it now.' : 'It stays in your records but buyers cannot order it.',
    })
  }

  return (
    <>
      <PageHeader
        title="My listings"
        subtitle="Everything you have offered, with how much of each is still unsold."
        action={<LinkButton to="/farmer/listings/new"><PackagePlus size={16} /> New listing</LinkButton>}
      />

      {loading && <SkeletonRows count={5} />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {listings && (
        <DataTable
          rows={listings}
          rowKey={(l) => l.id}
          empty={
            <EmptyState
              title="No listings yet"
              body="Publish what you have ready. You can pause a listing at any time without losing its history."
              action={<LinkButton to="/farmer/listings/new" size="sm">Create a listing</LinkButton>}
            />
          }
          columns={[
            {
              header: 'Crop',
              cell: (l) => (
                <div className="flex items-center gap-2.5">
                  <span aria-hidden className="text-lg">{productById(l.productId).emoji}</span>
                  <div>
                    <p className="font-medium">{productById(l.productId).name}</p>
                    <p className="text-xs text-ink-mute">Grade {l.grade} · {placeById(l.farmPlaceId).name}</p>
                  </div>
                </div>
              ),
            },
            {
              header: 'Remaining',
              cell: (l) => (
                <div className="w-32">
                  <p className="tnum text-sm">{kg(l.remainingKg)} of {kg(l.quantityKg)}</p>
                  <Meter value={l.quantityKg - l.remainingKg} max={l.quantityKg} />
                </div>
              ),
            },
            { header: 'Price', align: 'right', cell: (l) => perKg(l.pricePerKg) },
            { header: 'Available until', hideOnMobile: true, cell: (l) => date(l.availableUntil) },
            {
              header: 'Status',
              cell: (l) => (
                <Badge tone={l.status === 'active' ? 'forest' : l.status === 'sold' ? 'neutral' : 'harvest'}>
                  {l.status === 'reserved' ? 'Paused' : l.status.charAt(0).toUpperCase() + l.status.slice(1)}
                </Badge>
              ),
            },
            {
              header: 'Actions',
              align: 'right',
              cell: (l) => (
                <div className="flex justify-end gap-1.5">
                  {l.status !== 'sold' && (
                    <Button variant="ghost" size="sm" onClick={() => onPause(l)}>
                      {l.status === 'active' ? 'Pause' : 'Publish'}
                    </Button>
                  )}
                  <Button variant="ghost" size="sm" onClick={() => setToRemove(l)}>Remove</Button>
                </div>
              ),
            },
          ]}
        />
      )}

      <ConfirmDialog
        open={!!toRemove}
        onClose={() => setToRemove(null)}
        onConfirm={() => toRemove && onRemove(toRemove)}
        title="Remove this listing?"
        body="Buyers will stop seeing it immediately. Orders already placed against it stay in your order history."
        confirmLabel="Remove listing"
        tone="danger"
      />
    </>
  )
}
