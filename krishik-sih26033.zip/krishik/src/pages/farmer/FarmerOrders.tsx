import { useAuth } from '@/context/AuthContext'
import { OrdersView } from '@/components/domain/OrdersView'
import { PageHeader } from '@/components/ui/PageHeader'

export function FarmerOrders() {
  const { user, role } = useAuth()
  if (!user || !role) return null
  return (
    <>
      <PageHeader
        title="Orders"
        subtitle="Accept or decline what buyers have committed to, then confirm the final price once transport is accounted for."
      />
      <OrdersView perspective="seller" userId={user.id} role={role} />
    </>
  )
}
