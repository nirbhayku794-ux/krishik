import { useState } from 'react'
import { useService } from '@/lib/useService'
import { getDemandForecast } from '@/services'
import { PageHeader } from '@/components/ui/PageHeader'
import { Badge } from '@/components/ui/Badge'
import { ForecastCard } from '@/components/domain/ForecastCard'
import { SkeletonCards } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'

export function FarmerForecast() {
  const [horizon, setHorizon] = useState(7)
  const { data: forecasts, loading } = useService(() => getDemandForecast(horizon), [horizon])

  return (
    <>
      <PageHeader
        title="Demand forecast"
        subtitle="Expected demand for the coming days against what is currently listed, crop by crop, with the factors behind each number."
        meta={<Badge tone="harvest">Prototype forecast · deterministic model on seeded data</Badge>}
        action={
          <div className="flex gap-1.5">
            {[7, 14, 30].map((days) => (
              <Button key={days} variant={horizon === days ? 'primary' : 'secondary'} size="sm" onClick={() => setHorizon(days)}>
                {days} days
              </Button>
            ))}
          </div>
        }
      />

      {loading && <SkeletonCards count={6} height="h-80" />}
      {forecasts && (
        <div className="grid gap-4 lg:grid-cols-2">
          {forecasts.map((forecast) => (
            <ForecastCard key={forecast.productId} forecast={forecast} expanded />
          ))}
        </div>
      )}
    </>
  )
}
