import { useAuth } from '@/context/AuthContext'
import { useService } from '@/lib/useService'
import { getDemandOpportunities, getDemandPools } from '@/services'
import { placeById } from '@/data/seed'
import { kg, perKg } from '@/lib/format'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { Badge } from '@/components/ui/Badge'
import { Meter } from '@/components/ui/Meter'
import { LinkButton } from '@/components/ui/Button'
import { SkeletonCards } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'

export function FarmerDemand() {
  const { user } = useAuth()
  const sellerId = user?.id ?? ''
  const { data: opportunities, loading } = useService(() => getDemandOpportunities(sellerId), [sellerId])
  const { data: pools } = useService(() => getDemandPools())

  return (
    <>
      <PageHeader
        title="Demand near you"
        subtitle="Open buyer requirements within about 45 km of the market you already sell at, pooled by crop."
        meta={<Badge tone="harvest">Prototype estimates on seeded data</Badge>}
      />

      {loading && <SkeletonCards count={4} height="h-44" />}
      {opportunities && opportunities.length === 0 && (
        <EmptyState title="No open demand nearby" body="Buyer requirements in your area will appear here as they are posted." />
      )}

      {opportunities && opportunities.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2">
          {opportunities.map((opp) => {
            const pool = pools?.find((p) => p.productId === opp.productId)
            return (
              <article key={opp.productId} className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span aria-hidden className="grid h-11 w-11 place-items-center rounded-xl bg-forest-50 text-xl">{opp.emoji}</span>
                    <div>
                      <h2 className="font-display text-lg font-semibold">{opp.productName}</h2>
                      <p className="text-sm text-ink-mute">{opp.buyers} open {opp.buyers === 1 ? 'requirement' : 'requirements'}</p>
                    </div>
                  </div>
                  <Badge tone={opp.intensity === 'high' ? 'forest' : opp.intensity === 'moderate' ? 'harvest' : 'neutral'}>
                    {opp.intensity === 'high' ? 'High demand' : opp.intensity === 'moderate' ? 'Moderate' : 'Well supplied'}
                  </Badge>
                </div>

                <dl className="tnum mt-4 grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <dt className="text-xs text-ink-mute">Buyer demand</dt>
                    <dd className="font-display text-xl font-semibold">{kg(opp.demandKg)}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-ink-mute">Listed supply</dt>
                    <dd className="font-display text-xl font-semibold">{kg(opp.supplyKg)}</dd>
                  </div>
                </dl>
                <div className="mt-3">
                  <Meter value={Math.min(opp.supplyKg, opp.demandKg)} max={Math.max(opp.demandKg, 1)} tone={opp.gap > 0 ? 'harvest' : 'forest'} />
                </div>
                <p className="mt-3 text-sm text-ink-soft">{opp.recommendation}</p>

                {pool && pool.demands.length > 0 && (
                  <div className="mt-4 border-t border-forest-50 pt-3">
                    <SectionTitle title="Who is asking" />
                    <ul className="space-y-1.5 text-sm">
                      {pool.demands.slice(0, 4).map((d) => (
                        <li key={d.requirementId} className="flex items-center justify-between gap-3">
                          <span className="truncate text-ink-soft">{d.buyerName} · {placeById(d.placeId).name}</span>
                          <span className="tnum shrink-0 font-medium">{kg(d.quantityKg)} @ {perKg(d.maxPricePerKg)}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <LinkButton to="/farmer/listings/new" variant="secondary" size="sm" className="mt-4">
                  List {opp.productName.toLowerCase()}
                </LinkButton>
              </article>
            )
          })}
        </div>
      )}
    </>
  )
}
