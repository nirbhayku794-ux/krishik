import { useMemo, useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { ImagePlus, Info } from 'lucide-react'
import { iso, places, productById, products } from '@/data/seed'
import type { Grade } from '@/types'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/context/ToastContext'
import { createListing, calculateTransportFeasibility } from '@/services'
import { perKg, round } from '@/lib/format'
import { PageHeader } from '@/components/ui/PageHeader'
import { Field, Input, Select, Textarea } from '@/components/ui/Field'
import { Button } from '@/components/ui/Button'
import { Badge, FeasibilityPill } from '@/components/ui/Badge'

const toDateInput = (isoString: string) => isoString.slice(0, 10)

export function NewListing() {
  const { user, role } = useAuth()
  const { notify } = useToast()
  const navigate = useNavigate()

  const defaultFarm = user?.placeId ?? 'p_buxar'
  const defaultSelling = user && 'preferredSellingPlaceId' in user ? (user as { preferredSellingPlaceId: string }).preferredSellingPlaceId : 'p_buxar_mandi'

  const [productId, setProductId] = useState('pr_tomato')
  const [quantity, setQuantity] = useState('500')
  const [price, setPrice] = useState('20')
  const [grade, setGrade] = useState<Grade>('A')
  const [harvestDate, setHarvestDate] = useState(toDateInput(iso(0)))
  const [availableFrom, setAvailableFrom] = useState(toDateInput(iso(0)))
  const [availableUntil, setAvailableUntil] = useState(toDateInput(iso(7)))
  const [farmPlaceId, setFarmPlaceId] = useState(defaultFarm)
  const [sellingPlaceId, setSellingPlaceId] = useState(defaultSelling)
  const [maxAdditionalKm, setMaxAdditionalKm] = useState('10')
  const [note, setNote] = useState('')
  const [imageName, setImageName] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const product = productById(productId)
  const reference = product.referencePricePerKg

  /* Live feasibility preview against a nearby buyer, so the farmer sees the
     consequence of their distance limit while they are still typing. */
  const preview = useMemo(() => {
    const qty = Number(quantity) || 1
    return calculateTransportFeasibility({
      farmPlaceId,
      preferredSellingPlaceId: sellingPlaceId,
      buyerPlaceId: farmPlaceId,
      quantityKg: qty,
      maxAdditionalKm: Number(maxAdditionalKm) || 0,
      farmerPricePerKg: Number(price) || 0,
      referencePricePerKg: reference,
    })
  }, [farmPlaceId, sellingPlaceId, quantity, maxAdditionalKm, price, reference])

  const validate = () => {
    const next: Record<string, string> = {}
    if (!productId) next.productId = 'Choose the crop you are listing.'
    if (!(Number(quantity) > 0)) next.quantity = 'Quantity must be greater than zero.'
    if (!(Number(price) > 0)) next.price = 'Price must be greater than zero.'
    if (Number(maxAdditionalKm) < 0) next.maxAdditionalKm = 'Distance cannot be negative.'
    if (!farmPlaceId) next.farmPlaceId = 'Select the farm location.'
    if (!sellingPlaceId) next.sellingPlaceId = 'Select where you usually sell.'
    if (new Date(availableUntil) < new Date(availableFrom)) next.availableUntil = 'The end date must fall after the start date.'
    setErrors(next)
    return Object.keys(next).length === 0
  }

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault()
    if (!user) return
    if (!validate()) {
      notify('Check the highlighted fields', { body: 'A listing needs a positive quantity, a positive price and valid dates.', tone: 'warning' })
      return
    }
    setSaving(true)
    const listing = await createListing({
      sellerId: user.id,
      sellerRole: role === 'fpo' ? 'fpo' : 'farmer',
      productId,
      quantityKg: Number(quantity),
      pricePerKg: Number(price),
      unit: 'kg',
      grade,
      harvestDate: new Date(harvestDate).toISOString(),
      availableFrom: new Date(availableFrom).toISOString(),
      availableUntil: new Date(availableUntil).toISOString(),
      farmPlaceId,
      preferredSellingPlaceId: sellingPlaceId,
      maxAdditionalKm: Number(maxAdditionalKm),
      note: note.trim() || undefined,
    })
    setSaving(false)
    notify('Listing published', {
      body: `${listing.quantityKg} kg of ${product.name.toLowerCase()} is now visible to buyers.`,
    })
    navigate('/farmer/listings')
  }

  const priceGap = round(reference - Number(price || 0), 2)

  return (
    <>
      <PageHeader
        title="Publish a listing"
        subtitle="Buyers filter on crop, grade, quantity and distance. The more exact this is, the better the matches."
      />

      <form onSubmit={onSubmit} className="grid gap-6 lg:grid-cols-[1.35fr_1fr]">
        <div className="space-y-5 rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Crop" required>
              <Select value={productId} onChange={(e) => setProductId(e.target.value)}>
                {products.map((p) => <option key={p.id} value={p.id}>{p.emoji} {p.name}</option>)}
              </Select>
            </Field>
            <Field label="Category">
              <Input value={product.category.charAt(0).toUpperCase() + product.category.slice(1)} disabled readOnly />
            </Field>
            <Field label="Quantity" required hint="Total you are offering." error={errors.quantity}>
              <div className="flex gap-2">
                <Input type="number" min={1} value={quantity} onChange={(e) => setQuantity(e.target.value)} required />
                <Select defaultValue="kg" className="w-28">
                  <option value="kg">kg</option>
                  <option value="quintal">quintal</option>
                </Select>
              </div>
            </Field>
            <Field label="Expected price per kg (₹)" required hint={`Reference mandi price today: ${perKg(reference)} (demo data).`} error={errors.price}>
              <Input type="number" min={1} step="0.5" value={price} onChange={(e) => setPrice(e.target.value)} required />
            </Field>
            <Field label="Grade" required>
              <Select value={grade} onChange={(e) => setGrade(e.target.value as Grade)}>
                <option value="A">Grade A — sorted, uniform</option>
                <option value="B">Grade B — mixed sizes</option>
                <option value="C">Grade C — processing quality</option>
              </Select>
            </Field>
            <Field label="Harvest date" required>
              <Input type="date" value={harvestDate} onChange={(e) => setHarvestDate(e.target.value)} required />
            </Field>
            <Field label="Available from" required>
              <Input type="date" value={availableFrom} onChange={(e) => setAvailableFrom(e.target.value)} required />
            </Field>
            <Field label="Available until" required error={errors.availableUntil}>
              <Input type="date" value={availableUntil} onChange={(e) => setAvailableUntil(e.target.value)} required />
            </Field>
            <Field label="Farm location" required>
              <Select value={farmPlaceId} onChange={(e) => setFarmPlaceId(e.target.value)}>
                {places.map((p) => <option key={p.id} value={p.id}>{p.name}, {p.district}</option>)}
              </Select>
            </Field>
            <Field label="Where you usually sell" required hint="The trip you already make. Extra distance is measured from here.">
              <Select value={sellingPlaceId} onChange={(e) => setSellingPlaceId(e.target.value)}>
                {places.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </Select>
            </Field>
            <Field label="Maximum extra distance (km)" required hint="Buyers beyond this are flagged before you see them." error={errors.maxAdditionalKm}>
              <Input type="number" min={0} max={80} value={maxAdditionalKm} onChange={(e) => setMaxAdditionalKm(e.target.value)} required />
            </Field>
          </div>

          <Field label="Note for buyers" hint="Optional. Sorting, packing, cold storage, anything that helps a buyer decide.">
            <Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Hand-picked and sorted the same morning." />
          </Field>

          <div>
            <span className="field-label">Photo (optional)</span>
            <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-forest-200 bg-canvas/50 px-4 py-4 text-sm text-ink-soft transition hover:border-forest-400">
              <ImagePlus size={18} className="text-forest-600" />
              <span>{imageName ?? 'Add a photo of the produce'}</span>
              <input
                type="file"
                accept="image/*"
                className="sr-only"
                onChange={(e) => setImageName(e.target.files?.[0]?.name ?? null)}
              />
            </label>
            <p className="mt-1 text-xs text-ink-mute">Images stay on your device in the prototype; nothing is uploaded.</p>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button type="submit" size="lg" disabled={saving}>{saving ? 'Publishing…' : 'Publish listing'}</Button>
            <Button type="button" variant="secondary" size="lg" onClick={() => navigate('/farmer/listings')}>Cancel</Button>
          </div>
        </div>

        <aside className="space-y-4">
          <div className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
            <h2 className="font-display text-lg font-semibold">How this will look to buyers</h2>
            <div className="mt-3 rounded-xl border border-forest-100 bg-canvas/50 p-4">
              <div className="flex items-center justify-between">
                <span className="font-display text-lg font-semibold">{product.emoji} {product.name}</span>
                <span className="tnum font-display text-lg font-semibold text-forest-700">{perKg(Number(price) || 0)}</span>
              </div>
              <p className="tnum mt-1 text-sm text-ink-soft">
                {Number(quantity) || 0} kg · Grade {grade} · {places.find((p) => p.id === farmPlaceId)?.name}
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <Badge tone={priceGap > 0 ? 'forest' : 'harvest'}>
                  {priceGap > 0 ? `₹${priceGap}/kg under reference price` : 'At or above reference price'}
                </Badge>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-display text-lg font-semibold">Your travel limit</h2>
              <FeasibilityPill status={preview.status} />
            </div>
            <p className="mt-2 text-sm text-ink-soft">
              A buyer sitting at your farm's own location adds {preview.additionalKm} km to the {preview.baselineKm} km trip you
              already make. Anything past {maxAdditionalKm || 0} km gets flagged to both sides before an order is confirmed.
            </p>
            <p className="mt-3 flex items-start gap-2 rounded-xl bg-forest-50 px-3 py-2 text-xs text-forest-700">
              <Info size={14} className="mt-0.5 shrink-0" />
              Krishik never books a vehicle for you. It only estimates what an extra stop would cost so you can decide.
            </p>
          </div>
        </aside>
      </form>
    </>
  )
}
