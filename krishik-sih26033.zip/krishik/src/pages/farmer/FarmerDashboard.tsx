import { Boxes, ClipboardList, Coins, PackagePlus, Scale, TrendingUp } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { useService } from '@/lib/useService'
import { getDemandOpportunities, getListingsBySeller, getOrders } from '@/services'
import { inr, kg } from '@/lib/format'
import { productById } from '@/data/seed'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { Stat } from '@/components/ui/Stat'
import { Badge, OrderStatusPill } from '@/components/ui/Badge'
import { Button, LinkButton } from '@/components/ui/Button'
import { Meter } from '@/components/ui/Meter'
import { SkeletonCards, SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'

export function FarmerDashboard() {
  const { user, role } = useAuth()
  const sellerId = user?.id ?? ''
  const { data: listings, loading: loadingListings } = useService(() => getListingsBySeller(sellerId), [sellerId])
  const { data: orders, loading: loadingOrders } = useService(() => getOrders({ sellerId }), [sellerId])
  const { data: opportunities, loading: loadingOpps } = useService(() => getDemandOpportunities(sellerId), [sellerId])

  const active = (listings ?? []).filter((l) => l.status === 'active')
  const totalKg = active.reduce((s, l) => s + l.remainingKg, 0)
  const pending = (orders ?? []).filter((o) => ['pending', 'feasibility_check', 'awaiting_confirmation', 'matched'].includes(o.status))
  const completed = (orders ?? []).filter((o) => o.status === 'completed')
  const live = (orders ?? []).filter((o) => o.status !== 'cancelled')
  const earnings = live.reduce((s, o) => s + o.pricePerKg * o.quantityKg, 0)

  return (
    <>
      <PageHeader
        title={`Good to see you, ${user?.name.split(' ')[0] ?? 'farmer'}`}
        subtitle={role === 'fpo' ? 'Aggregated stock, incoming orders and demand around your collection centre.' : 'Your listings, incoming orders and the demand building up near the market you already sell at.'}
        action={<LinkButton to="/farmer/listings/new"><PackagePlus size={16} /> New listing</LinkButton>}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Active listings" value={active.length} icon={<Boxes size={16} />} hint={`${(listings ?? []).length} created in total`} />
        <Stat label="Produce listed" value={kg(totalKg)} icon={<Scale size={16} />} hint="Quantity still unsold" />
        <Stat label="Pending orders" value={pending.length} icon={<ClipboardList size={16} />} hint={`${completed.length} completed so far`} />
        <Stat label="Expected earnings" value={inr(earnings)} icon={<Coins size={16} />} estimated hint="At your asking price, across live orders" tone="accent" />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.25fr_1fr]">
        <section>
          <SectionTitle
            title="Demand opportunities near you"
            hint="Open buyer requirements within roughly 45 km of your selling point."
            action={<Link to="/farmer/demand" className="text-sm font-medium text-forest-700 hover:underline">See all</Link>}
          />
          {loadingOpps && <SkeletonCards count={2} height="h-32" />}
          {opportunities && opportunities.length > 0 && (
            <div className="grid gap-3">
              {opportunities.slice(0, 3).map((opp) => (
                <article key={opp.productId} className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <span aria-hidden className="grid h-10 w-10 place-items-center rounded-xl bg-forest-50 text-lg">{opp.emoji}</span>
                      <div>
                        <h3 className="font-display text-lg font-semibold">{opp.productName}</h3>
                        <p className="text-sm text-ink-mute">{opp.buyers} open {opp.buyers === 1 ? 'requirement' : 'requirements'} nearby</p>
                      </div>
                    </div>
                    <Badge tone={opp.intensity === 'high' ? 'forest' : opp.intensity === 'moderate' ? 'harvest' : 'neutral'}>
                      {opp.intensity === 'high' ? 'High demand' : opp.intensity === 'moderate' ? 'Moderate demand' : 'Well supplied'}
                    </Badge>
                  </div>
                  <dl className="tnum mt-3 grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <dt className="text-xs text-ink-mute">Buyer demand</dt>
                      <dd className="font-semibold">{kg(opp.demandKg)}</dd>
                    </div>
                    <div>
                      <dt className="text-xs text-ink-mute">Listed supply</dt>
                      <dd className="font-semibold">{kg(opp.supplyKg)}</dd>
                    </div>
                  </dl>
                  <div className="mt-3">
                    <Meter value={Math.min(opp.supplyKg, opp.demandKg)} max={Math.max(opp.demandKg, 1)} tone={opp.gap > 0 ? 'harvest' : 'forest'} />
                  </div>
                  <p className="mt-2 text-sm text-ink-soft">{opp.recommendation}</p>
                  <LinkButton to="/farmer/listings/new" variant="secondary" size="sm" className="mt-3">
                    List {opp.productName.toLowerCase()}
                  </LinkButton>
                </article>
              ))}
            </div>
          )}
          <p className="mt-3 text-xs text-ink-mute">Forecast and demand figures are prototype estimates from seeded data.</p>
        </section>

        <section>
          <SectionTitle title="Latest orders" action={<Link to="/farmer/orders" className="text-sm font-medium text-forest-700 hover:underline">Manage</Link>} />
          {loadingOrders && <SkeletonRows count={4} />}
          {orders && orders.length === 0 && (
            <EmptyState
              title="No orders yet"
              body="Orders appear here the moment a buyer commits to a quantity from one of your listings."
              action={<LinkButton to="/farmer/listings/new" size="sm">Publish a listing</LinkButton>}
            />
          )}
          {orders && orders.length > 0 && (
            <ul className="space-y-2">
              {orders.slice(0, 5).map((order) => (
                <li key={order.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-forest-100 bg-white px-4 py-3 shadow-card">
                  <div>
                    <p className="font-medium">
                      {productById(order.productId).emoji} {productById(order.productId).name} · {kg(order.quantityKg)}
                    </p>
                    <p className="tnum text-sm text-ink-mute">{inr(order.pricePerKg * order.quantityKg)} at your asking price</p>
                  </div>
                  <OrderStatusPill status={order.status} />
                </li>
              ))}
            </ul>
          )}

          <div className="mt-4 rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
            <h3 className="flex items-center gap-2 font-semibold"><TrendingUp size={16} className="text-forest-600" /> Plan the week</h3>
            <p className="mt-1 text-sm text-ink-soft">
              The seven-day forecast compares expected demand with everything currently listed, crop by crop.
            </p>
            <LinkButton to="/farmer/forecast" variant="secondary" size="sm" className="mt-3">Open the forecast</LinkButton>
          </div>
        </section>
      </div>

      {loadingListings && <div className="mt-6"><SkeletonRows count={2} /></div>}
      {!loadingListings && active.length === 0 && (
        <div className="mt-8">
          <EmptyState
            title="Nothing listed right now"
            body="Publish what you have ready this week. Buyers filter by crop, grade and distance, so a listing with a clear harvest date gets found faster."
            action={<LinkButton to="/farmer/listings/new" size="sm"><PackagePlus size={15} /> Create your first listing</LinkButton>}
          />
        </div>
      )}
    </>
  )
}
