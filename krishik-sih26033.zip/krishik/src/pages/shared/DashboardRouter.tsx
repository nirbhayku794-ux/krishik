import { Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { HOME_FOR } from '@/components/layout/nav'

/** /dashboard sends each role to its own workspace. */
export function DashboardRouter() {
  const { role } = useAuth()
  if (!role) return <Navigate to="/login" replace />
  return <Navigate to={HOME_FOR[role]} replace />
}
