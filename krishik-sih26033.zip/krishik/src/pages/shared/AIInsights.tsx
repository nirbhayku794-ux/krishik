import { useState } from 'react'
import { ArrowRight, Check } from 'lucide-react'
import { useService } from '@/lib/useService'
import { getDemandForecast, getDemandPools } from '@/services'
import { placeById } from '@/data/seed'
import { kg, perKg } from '@/lib/format'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Meter } from '@/components/ui/Meter'
import { ForecastCard } from '@/components/domain/ForecastCard'
import { SkeletonCards } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'

export function AIInsights() {
  const [horizon, setHorizon] = useState(7)
  const { data: forecasts, loading } = useService(() => getDemandForecast(horizon), [horizon])
  const { data: pools, loading: loadingPools } = useService(() => getDemandPools())

  return (
    <>
      <PageHeader
        title="Demand insights"
        subtitle="Two views of the same market: what buyers are asking for right now, and what the model expects them to ask for next."
        meta={<Badge tone="harvest">Prototype forecast · deterministic model, seeded data, not a guarantee</Badge>}
        action={
          <div className="flex gap-1.5">
            {[7, 14, 30].map((days) => (
              <Button key={days} variant={horizon === days ? 'primary' : 'secondary'} size="sm" onClick={() => setHorizon(days)}>
                {days} days
              </Button>
            ))}
          </div>
        }
      />

      <SectionTitle title="Forecast by crop" hint={`Expected demand over the next ${horizon} days against listed supply.`} />
      {loading && <SkeletonCards count={4} height="h-80" />}
      {forecasts && (
        <div className="grid gap-4 lg:grid-cols-2">
          {forecasts.map((f) => <ForecastCard key={f.productId} forecast={f} expanded />)}
        </div>
      )}

      <div className="mt-10">
        <SectionTitle
          title="Demand aggregation"
          hint="Individually, these requirements are too small to interest a trader. Pooled, they become an order a farmer can plan around."
        />
        {loadingPools && <SkeletonCards count={2} height="h-64" />}
        {pools && pools.length === 0 && <EmptyState title="No open demand" body="Buyer requirements will be pooled here as they are posted." />}
        {pools && pools.length > 0 && (
          <div className="grid gap-4 lg:grid-cols-2">
            {pools.map((pool) => {
              const matched = Math.min(pool.demandKg, pool.supplyKg)
              return (
                <article key={pool.productId} className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
                  <div className="flex items-center justify-between gap-3">
                    <h3 className="flex items-center gap-2 font-display text-lg font-semibold">
                      <span aria-hidden>{pool.emoji}</span> {pool.productName}
                    </h3>
                    <Badge tone={pool.demandKg <= pool.supplyKg ? 'forest' : 'harvest'}>
                      {pool.demandKg <= pool.supplyKg ? 'Demand fully matched' : `${kg(pool.demandKg - pool.supplyKg)} short`}
                    </Badge>
                  </div>

                  <div className="mt-4 grid gap-4 sm:grid-cols-[1fr_auto_1fr]">
                    <div>
                      <p className="text-xs font-medium text-ink-mute">Fragmented buyer demand</p>
                      <ul className="mt-2 space-y-1.5 text-sm">
                        {pool.demands.slice(0, 5).map((d) => (
                          <li key={d.requirementId} className="flex items-center justify-between gap-2 rounded-lg bg-clay-100/50 px-2.5 py-1.5">
                            <span className="min-w-0 truncate">{d.buyerName}</span>
                            <span className="tnum shrink-0 font-medium">{kg(d.quantityKg)}</span>
                          </li>
                        ))}
                      </ul>
                      <p className="tnum mt-2 text-sm font-semibold">Total demand {kg(pool.demandKg)}</p>
                    </div>

                    <div className="hidden items-center justify-center text-forest-400 sm:flex">
                      <ArrowRight size={18} />
                    </div>

                    <div>
                      <p className="text-xs font-medium text-ink-mute">Farmer and FPO supply</p>
                      <ul className="mt-2 space-y-1.5 text-sm">
                        {pool.supplies.slice(0, 5).map((s) => (
                          <li key={s.listingId} className="flex items-center justify-between gap-2 rounded-lg bg-forest-50 px-2.5 py-1.5">
                            <span className="min-w-0 truncate">{s.sellerName} · {placeById(s.placeId).name}</span>
                            <span className="tnum shrink-0 font-medium">{kg(s.quantityKg)}</span>
                          </li>
                        ))}
                      </ul>
                      <p className="tnum mt-2 text-sm font-semibold">Total supply {kg(pool.supplyKg)}</p>
                    </div>
                  </div>

                  <div className="mt-4 border-t border-forest-50 pt-3">
                    <Meter value={matched} max={Math.max(pool.demandKg, 1)} label={`${kg(matched)} of pooled demand can be covered today`} />
                    {pool.supplies.length > 0 && (
                      <p className="tnum mt-2 flex items-center gap-1.5 text-sm text-forest-700">
                        <Check size={14} /> Cheapest listed offer {perKg(Math.min(...pool.supplies.map((s) => s.pricePerKg)))}
                      </p>
                    )}
                  </div>
                </article>
              )
            })}
          </div>
        )}
      </div>
    </>
  )
}
