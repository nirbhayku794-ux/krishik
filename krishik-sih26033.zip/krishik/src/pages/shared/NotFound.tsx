import { Compass } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { HOME_FOR } from '@/components/layout/nav'
import { LinkButton } from '@/components/ui/Button'

export function NotFound() {
  const { role } = useAuth()
  return (
    <div className="mx-auto flex w-full max-w-xl flex-col items-center px-4 py-24 text-center sm:px-6">
      <span className="mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-forest-50 text-forest-700">
        <Compass size={24} />
      </span>
      <h1 className="font-display text-3xl font-semibold">This page does not exist</h1>
      <p className="mt-2 text-ink-soft">
        The link may be out of date. The marketplace and your workspace are both one click away.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <LinkButton to="/marketplace">Go to the marketplace</LinkButton>
        <LinkButton to={role ? HOME_FOR[role] : '/'} variant="secondary">
          {role ? 'Back to my dashboard' : 'Back to home'}
        </LinkButton>
      </div>
    </div>
  )
}
