import { useMemo, useState } from 'react'
import { ArrowDown } from 'lucide-react'
import { places, productById, products } from '@/data/seed'
import { calculatePriceBreakdown, calculateTransportFeasibility } from '@/services'
import { inr, kg, perKg } from '@/lib/format'
import { PageHeader } from '@/components/ui/PageHeader'
import { Field, Input, Select } from '@/components/ui/Field'
import { Badge } from '@/components/ui/Badge'
import { FeasibilityPanel } from '@/components/domain/FeasibilityPanel'
import { PricePanel } from '@/components/domain/PricePanel'

export function Logistics() {
  const [farmPlaceId, setFarmPlaceId] = useState('p_buxar')
  const [sellingPlaceId, setSellingPlaceId] = useState('p_buxar_mandi')
  const [buyerPlaceId, setBuyerPlaceId] = useState('p_dumraon')
  const [productId, setProductId] = useState('pr_tomato')
  const [quantity, setQuantity] = useState('300')
  const [price, setPrice] = useState('20')
  const [maxKm, setMaxKm] = useState('10')

  const product = productById(productId)

  const { transport, pricing } = useMemo(() => {
    const qty = Math.max(1, Number(quantity) || 1)
    const t = calculateTransportFeasibility({
      farmPlaceId,
      preferredSellingPlaceId: sellingPlaceId,
      buyerPlaceId,
      quantityKg: qty,
      maxAdditionalKm: Number(maxKm) || 0,
      farmerPricePerKg: Number(price) || 0,
      referencePricePerKg: product.referencePricePerKg,
    })
    const p = calculatePriceBreakdown({
      farmerPricePerKg: Number(price) || 0,
      transportPerKg: t.costPerKg,
      quantityKg: qty,
      referencePricePerKg: product.referencePricePerKg,
    })
    return { transport: t, pricing: p }
  }, [farmPlaceId, sellingPlaceId, buyerPlaceId, quantity, price, maxKm, product])

  const name = (id: string) => places.find((p) => p.id === id)?.name ?? id

  return (
    <>
      <PageHeader
        title="Transport feasibility"
        subtitle="Krishik books no vehicles. This tool estimates the extra distance and cost a buyer adds to the trip a farmer was already making, and whether the direct sale still pays."
        meta={<Badge tone="harvest">Decision support · estimates on demo distances</Badge>}
      />

      <div className="grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
        <div className="space-y-4 rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
          <h2 className="font-display text-lg font-semibold">Inputs</h2>
          <Field label="Farm location">
            <Select value={farmPlaceId} onChange={(e) => setFarmPlaceId(e.target.value)}>
              {places.map((p) => <option key={p.id} value={p.id}>{p.name}, {p.district}</option>)}
            </Select>
          </Field>
          <Field label="Where the farmer already sells" hint="Mandi, retailer, wholesaler or any usual selling point.">
            <Select value={sellingPlaceId} onChange={(e) => setSellingPlaceId(e.target.value)}>
              {places.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
          <Field label="Buyer location">
            <Select value={buyerPlaceId} onChange={(e) => setBuyerPlaceId(e.target.value)}>
              {places.map((p) => <option key={p.id} value={p.id}>{p.name}, {p.district}</option>)}
            </Select>
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Crop">
              <Select value={productId} onChange={(e) => setProductId(e.target.value)}>
                {products.map((p) => <option key={p.id} value={p.id}>{p.emoji} {p.name}</option>)}
              </Select>
            </Field>
            <Field label="Quantity (kg)">
              <Input type="number" min={1} value={quantity} onChange={(e) => setQuantity(e.target.value)} />
            </Field>
            <Field label="Farmer price (₹/kg)">
              <Input type="number" min={1} step="0.5" value={price} onChange={(e) => setPrice(e.target.value)} />
            </Field>
            <Field label="Extra distance limit (km)">
              <Input type="number" min={0} value={maxKm} onChange={(e) => setMaxKm(e.target.value)} />
            </Field>
          </div>

          <div className="rounded-2xl border border-forest-100 bg-canvas/60 p-4">
            <h3 className="text-sm font-semibold">Suggested farmer-to-buyer movement</h3>
            <ol className="mt-3 space-y-1.5">
              {[
                { label: name(farmPlaceId), note: 'Farm — load here' },
                { label: name(buyerPlaceId), note: `Buyer — hand over ${kg(Number(quantity) || 0)}` },
                { label: name(sellingPlaceId), note: 'Continue to the usual selling point' },
              ].map((step, i, arr) => (
                <li key={`${step.label}-${i}`}>
                  <p className="font-medium">{step.label}</p>
                  <p className="text-xs text-ink-mute">{step.note}</p>
                  {i < arr.length - 1 && <ArrowDown size={14} className="my-1 text-forest-400" />}
                </li>
              ))}
            </ol>
            <p className="tnum mt-3 border-t border-forest-100 pt-3 text-sm text-ink-soft">
              {transport.routeKm} km total against {transport.baselineKm} km already planned ·
              {' '}{inr(transport.additionalCost)} extra ({perKg(transport.costPerKg)})
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <FeasibilityPanel
            analysis={transport}
            stops={[
              { placeId: farmPlaceId, label: 'Farm', kind: 'farm' },
              { placeId: buyerPlaceId, label: 'Buyer', kind: 'buyer' },
              { placeId: sellingPlaceId, label: 'Usual selling point', kind: 'market' },
            ]}
            baselineStops={[
              { placeId: farmPlaceId, label: 'Farm', kind: 'farm' },
              { placeId: sellingPlaceId, label: 'Usual selling point', kind: 'market' },
            ]}
          />
          <PricePanel pricing={pricing} quantityKg={Math.max(1, Number(quantity) || 1)} />
        </div>
      </div>
    </>
  )
}
