import { ArrowRight, Boxes, LineChart, MapPin, Route, ShieldCheck, Store, TrendingUp } from 'lucide-react'
import { Link } from 'react-router-dom'
import { LinkButton } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { useService } from '@/lib/useService'
import { getPlatformAnalytics } from '@/services'
import { inrShort, kg } from '@/lib/format'

const PILLARS = [
  {
    icon: Store,
    title: 'Direct marketplace',
    body: 'Farmers and FPOs list what they actually have this week. Buyers see the seller, the grade, the quantity and the asking price without a chain of resellers in between.',
    link: { to: '/marketplace', label: 'See live listings' },
  },
  {
    icon: Boxes,
    title: 'Smart demand matching',
    body: 'A restaurant needing 100 kg and a hostel needing 150 kg are too small to interest a trader. Krishik pools them into one order worth a farmer\u2019s attention.',
    link: { to: '/buyer', label: 'How pooling works' },
  },
  {
    icon: Route,
    title: 'Transport feasibility',
    body: 'Krishik owns no trucks. It measures the extra distance a buyer adds to the trip a farmer was already making, and says plainly when that extra travel is not worth it.',
    link: { to: '/logistics', label: 'Open the transport check' },
  },
]

const STEPS = [
  { title: 'Farmer lists produce', body: 'Crop, quantity, grade, asking price, and the market they were already heading to.' },
  { title: 'Buyer posts a requirement', body: 'Or orders straight from a listing. Individual households and bulk buyers both fit.' },
  { title: 'Krishik matches supply to demand', body: 'Small requirements are pooled, then split across nearby sellers who can actually cover them.' },
  { title: 'The full price is calculated', body: 'Asking price, transport, platform and handling, compared against the reference mandi price.' },
  { title: 'Transport feasibility is checked', body: 'Extra kilometres and extra cost, measured against the farmer\u2019s existing route and their own limit.' },
  { title: 'Both sides confirm', body: 'The farmer accepts, the buyer confirms the final price, and the handover is recorded.' },
]

export function Landing() {
  const { data: stats } = useService(() => getPlatformAnalytics())

  return (
    <>
      {/* Hero */}
      <section className="hero-wash">
        <div className="mx-auto w-full max-w-6xl px-4 pb-16 pt-14 sm:px-6 lg:pb-24 lg:pt-20">
          <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
            <div className="animate-rise">
              <Badge tone="forest" className="mb-5">
                <ShieldCheck size={13} /> Built for SIH26033
              </Badge>
              <h1 className="font-display text-[2.4rem] font-semibold leading-[1.05] sm:text-5xl lg:text-[3.4rem]">
                From farm to buyer, with fewer intermediaries.
              </h1>
              <p className="mt-5 max-w-xl text-lg text-ink-soft">
                Krishik connects farmers and FPOs directly with consumers and bulk buyers, while making demand, pricing and
                transport feasibility transparent.
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <LinkButton to="/marketplace" size="lg">
                  Explore marketplace <ArrowRight size={18} />
                </LinkButton>
                <LinkButton to="/register" variant="secondary" size="lg">Join Krishik</LinkButton>
              </div>
              <p className="mt-4 text-sm text-ink-mute">
                Prototype with seeded data.{' '}
                <Link to="/login" className="font-medium text-forest-700 underline underline-offset-2">
                  Sign in as a farmer, buyer, FPO or admin
                </Link>{' '}
                to walk the full flow.
              </p>
            </div>

            <FlowCard />
          </div>

          <dl className="mt-14 grid grid-cols-2 gap-4 border-t border-forest-100 pt-8 sm:grid-cols-4">
            {[
              { label: 'Produce listed', value: stats ? kg(stats.listedKg) : '—' },
              { label: 'Demand matched', value: stats ? kg(stats.matchedKg) : '—' },
              { label: 'Registered buyers', value: stats ? String(stats.buyers) : '—' },
              { label: 'Transaction value', value: stats ? inrShort(stats.transactionValue) : '—' },
            ].map((item) => (
              <div key={item.label}>
                <dt className="text-sm text-ink-mute">{item.label}</dt>
                <dd className="tnum font-display text-2xl font-semibold sm:text-3xl">{item.value}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-3 text-xs text-ink-mute">All figures are demo data from the seeded prototype dataset.</p>
        </div>
      </section>

      {/* Problem vs Krishik */}
      <section className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-20">
        <h2 className="max-w-2xl font-display text-3xl font-semibold">
          Every extra hop is a cut for someone and a cost for everyone.
        </h2>
        <p className="mt-3 max-w-2xl text-ink-soft">
          A tomato leaving a Buxar farm can change hands four times before a household buys it. Each hop adds margin and
          another trip. Krishik does not claim to erase that chain, it shows when going around it actually pays.
        </p>

        <div className="mt-8 grid gap-5 lg:grid-cols-2">
          <div className="rounded-2xl border border-clay-100 bg-clay-100/40 p-6">
            <p className="text-sm font-semibold text-clay-500">Today</p>
            <ChainRow items={['Farmer', 'Local trader', 'Wholesaler', 'Retailer', 'Consumer']} tone="clay" />
            <p className="mt-4 text-sm text-ink-soft">
              The farmer sells at the first price offered. The consumer pays the last one. Nobody in the middle is visible to either.
            </p>
          </div>
          <div className="rounded-2xl border border-forest-200 bg-forest-50 p-6">
            <p className="text-sm font-semibold text-forest-700">With Krishik</p>
            <ChainRow items={['Farmer / FPO', 'Krishik', 'Buyer']} tone="forest" />
            <p className="mt-4 text-sm text-ink-soft">
              One matching layer instead of three trading layers, with the full landed price shown to both sides before anyone commits.
            </p>
          </div>
        </div>
      </section>

      {/* Pillars */}
      <section className="border-y border-forest-100 bg-white">
        <div className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-20">
          <h2 className="font-display text-3xl font-semibold">Three things the platform actually does</h2>
          <div className="mt-8 grid gap-5 md:grid-cols-3">
            {PILLARS.map((pillar) => (
              <article key={pillar.title} className="flex flex-col rounded-2xl border border-forest-100 bg-canvas/50 p-6">
                <span className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-forest-600 text-white">
                  <pillar.icon size={20} />
                </span>
                <h3 className="font-display text-xl font-semibold">{pillar.title}</h3>
                <p className="mt-2 flex-1 text-sm text-ink-soft">{pillar.body}</p>
                <Link to={pillar.link.to} className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-forest-700 hover:underline">
                  {pillar.link.label} <ArrowRight size={14} />
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-20">
        <h2 className="font-display text-3xl font-semibold">How Krishik works</h2>
        <p className="mt-2 max-w-2xl text-ink-soft">Six steps, in the order a real transaction takes them.</p>
        <ol className="mt-8 grid gap-x-8 gap-y-6 sm:grid-cols-2 lg:grid-cols-3">
          {STEPS.map((step, i) => (
            <li key={step.title} className="border-t border-forest-200 pt-4">
              <span className="tnum font-display text-sm font-semibold text-forest-600">Step {i + 1}</span>
              <h3 className="mt-1 font-display text-lg font-semibold">{step.title}</h3>
              <p className="mt-1 text-sm text-ink-soft">{step.body}</p>
            </li>
          ))}
        </ol>
      </section>

      {/* Honesty section */}
      <section className="border-t border-forest-100 bg-forest-800 text-white">
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:py-20">
          <div>
            <h2 className="font-display text-3xl font-semibold text-white">What Krishik does not claim</h2>
            <p className="mt-3 max-w-xl text-forest-100">
              Direct is not automatically cheaper. A buyer 38 km off the farmer's route can cost more in fuel than the
              trader's margin ever did. The platform says so, on the screen, before the order is placed.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <LinkButton to="/logistics" variant="harvest" size="md">Try the transport check</LinkButton>
              <LinkButton to="/ai-insights" variant="secondary" size="md">See the demand forecast</LinkButton>
            </div>
          </div>
          <ul className="grid gap-3">
            {[
              { icon: MapPin, text: 'No fleet, no truck booking. Only an estimate of the extra distance a buyer adds.' },
              { icon: TrendingUp, text: 'Forecasts are labelled as prototype estimates, never as guaranteed demand.' },
              { icon: LineChart, text: 'Market comparisons use reference demo prices and are named as such.' },
            ].map((item) => (
              <li key={item.text} className="flex items-start gap-3 rounded-2xl bg-forest-700/60 p-4 text-sm text-forest-50">
                <item.icon size={18} className="mt-0.5 shrink-0 text-harvest-300" />
                {item.text}
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  )
}

function ChainRow({ items, tone }: { items: string[]; tone: 'clay' | 'forest' }) {
  return (
    <div className="mt-4 flex flex-wrap items-center gap-2">
      {items.map((item, i) => (
        <span key={item} className="flex items-center gap-2">
          <span className={`rounded-xl px-3 py-2 text-sm font-medium ${tone === 'clay' ? 'bg-white text-clay-500' : 'bg-forest-600 text-white'}`}>
            {item}
          </span>
          {i < items.length - 1 && <ArrowRight size={14} className={tone === 'clay' ? 'text-clay-500' : 'text-forest-600'} />}
        </span>
      ))}
    </div>
  )
}

function FlowCard() {
  return (
    <div className="rounded-2xl border border-forest-100 bg-white p-6 shadow-lift">
      <p className="text-sm font-medium text-ink-mute">A live example from the demo data</p>
      <div className="mt-4 space-y-3">
        <FlowRow title="Ravi Kumar · Buxar" sub="500 kg tomato, Grade A, ₹20/kg" tone="forest" />
        <div className="flex items-center gap-2 pl-4 text-sm text-ink-mute">
          <span className="h-6 w-px bg-forest-200" />
          Krishik pools three nearby buyers and checks the route
        </div>
        <FlowRow title="Annapurna Restaurant · Buxar" sub="Needs 300 kg by Thursday, ceiling ₹22/kg" tone="clay" />
      </div>

      <div className="mt-5 grid grid-cols-3 gap-3 rounded-xl bg-canvas p-4 text-center">
        <div>
          <p className="tnum font-display text-lg font-semibold text-forest-700">₹20.00</p>
          <p className="text-xs text-ink-mute">Farmer gets</p>
        </div>
        <div>
          <p className="tnum font-display text-lg font-semibold">₹20.95</p>
          <p className="text-xs text-ink-mute">Buyer pays</p>
        </div>
        <div>
          <p className="tnum font-display text-lg font-semibold text-ink-mute line-through">₹24.00</p>
          <p className="text-xs text-ink-mute">Reference mandi</p>
        </div>
      </div>
      <p className="mt-3 text-xs text-ink-mute">
        Includes ₹0.45/kg estimated transport for 3.2 km of extra travel. Demo figures.
      </p>
    </div>
  )
}

function FlowRow({ title, sub, tone }: { title: string; sub: string; tone: 'forest' | 'clay' }) {
  return (
    <div className={`rounded-xl border p-3 ${tone === 'forest' ? 'border-forest-200 bg-forest-50' : 'border-clay-100 bg-clay-100/50'}`}>
      <p className="font-semibold">{title}</p>
      <p className="text-sm text-ink-soft">{sub}</p>
    </div>
  )
}
