import { CalendarCheck, Coins, Route, TrendingUp } from 'lucide-react'
import { PageHeader } from '@/components/ui/PageHeader'
import { LinkButton } from '@/components/ui/Button'

const POINTS = [
  { icon: Coins, title: 'You set the asking price', body: 'List the crop, quantity and grade with the price you want. Buyers see that number and what it becomes after transport, so there is nothing to haggle down at the gate.' },
  { icon: Route, title: 'Sell along the route you already take', body: 'Tell Krishik where you normally sell and how much extra distance you accept. Buyers beyond that show up with the added cost attached, not hidden.' },
  { icon: TrendingUp, title: 'See demand before you harvest', body: 'Open requirements near you and a seven-day demand forecast tell you which crops are short of supply this week.' },
  { icon: CalendarCheck, title: 'Confirmed orders, not enquiries', body: 'A buyer places a quantity, you accept or decline, both sides confirm the final price. The order is recorded with a timeline.' },
]

export function FarmerInfo() {
  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-12 sm:px-6">
      <PageHeader
        title="For farmers and FPOs"
        subtitle="List once, reach buyers who have already committed to a quantity and a price ceiling, and know the transport cost before you agree to anything."
        action={<LinkButton to="/login">Try the farmer dashboard</LinkButton>}
      />

      <div className="grid gap-4 sm:grid-cols-2">
        {POINTS.map((point) => (
          <article key={point.title} className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
            <span className="mb-3 grid h-10 w-10 place-items-center rounded-xl bg-forest-50 text-forest-700">
              <point.icon size={18} />
            </span>
            <h2 className="font-display text-lg font-semibold">{point.title}</h2>
            <p className="mt-1.5 text-sm text-ink-soft">{point.body}</p>
          </article>
        ))}
      </div>

      <section className="mt-8 rounded-2xl border border-forest-200 bg-forest-50 p-6">
        <h2 className="font-display text-xl font-semibold">What an FPO gets on top</h2>
        <p className="mt-2 text-sm text-ink-soft">
          Member produce can be pooled into a single large listing, which is what makes institutional and wholesale
          requirements reachable. The FPO workspace keeps crop-level stock, incoming bulk requirements and the same
          feasibility and forecast tools in one place.
        </p>
        <LinkButton to="/login" variant="secondary" size="sm" className="mt-4">Open the FPO workspace</LinkButton>
      </section>
    </div>
  )
}
