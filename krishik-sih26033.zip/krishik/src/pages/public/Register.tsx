import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { places } from '@/data/seed'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/context/ToastContext'
import { HOME_FOR } from '@/components/layout/nav'
import { Button } from '@/components/ui/Button'
import { Field, Input, Select } from '@/components/ui/Field'
import type { BulkCategory, BuyerType, Role } from '@/types'

const ROLES: { value: Role; label: string; note: string }[] = [
  { value: 'farmer', label: 'Farmer', note: 'List your own produce' },
  { value: 'fpo', label: 'FPO', note: 'Aggregate produce for members' },
  { value: 'buyer', label: 'Buyer', note: 'Household or bulk purchase' },
]

const BULK: { value: BulkCategory; label: string }[] = [
  { value: 'retailer', label: 'Retailer' },
  { value: 'restaurant', label: 'Restaurant' },
  { value: 'hostel', label: 'Hostel' },
  { value: 'canteen', label: 'Canteen' },
  { value: 'business', label: 'Local business' },
  { value: 'institution', label: 'Institutional buyer' },
]

export function Register() {
  const navigate = useNavigate()
  const { signInAs } = useAuth()
  const { notify } = useToast()
  const [role, setRole] = useState<Role>('farmer')
  const [buyerType, setBuyerType] = useState<BuyerType>('bulk')

  const onSubmit = (e: FormEvent) => {
    e.preventDefault()
    notify('Account created', {
      body: 'The prototype signs you into the matching demo account so you can see populated screens.',
    })
    signInAs(role)
    navigate(HOME_FOR[role])
  }

  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-12 sm:px-6 lg:py-16">
      <h1 className="font-display text-3xl font-semibold">Join Krishik</h1>
      <p className="mt-2 text-ink-soft">
        Tell us who you are and where you trade. In this prototype, registration drops you into a seeded account of the same
        role so every screen has real data to show.
      </p>

      <form onSubmit={onSubmit} className="mt-8 space-y-5 rounded-2xl border border-forest-100 bg-white p-6 shadow-card">
        <fieldset>
          <legend className="field-label">I am joining as</legend>
          <div className="grid gap-2 sm:grid-cols-3">
            {ROLES.map((option) => (
              <button
                type="button"
                key={option.value}
                onClick={() => setRole(option.value)}
                className={`rounded-xl border px-4 py-3 text-left transition ${
                  role === option.value ? 'border-forest-500 bg-forest-50' : 'border-forest-100 hover:border-forest-300'
                }`}
                aria-pressed={role === option.value}
              >
                <span className="block font-medium">{option.label}</span>
                <span className="block text-xs text-ink-mute">{option.note}</span>
              </button>
            ))}
          </div>
        </fieldset>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={role === 'fpo' ? 'Organisation name' : 'Full name'} required>
            <Input required placeholder={role === 'fpo' ? 'Buxar Vegetable Producers FPO' : 'Ravi Kumar'} />
          </Field>
          <Field label="Mobile number" required>
            <Input required type="tel" placeholder="+91 90000 00000" />
          </Field>
          <Field label="Email" required>
            <Input required type="email" placeholder="you@example.com" />
          </Field>
          <Field label="Location" required>
            <Select required defaultValue="p_buxar">
              {places.map((place) => (
                <option key={place.id} value={place.id}>{place.name}, {place.district}</option>
              ))}
            </Select>
          </Field>
        </div>

        {role === 'buyer' && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Buying for">
              <Select value={buyerType} onChange={(e) => setBuyerType(e.target.value as BuyerType)}>
                <option value="individual">My household</option>
                <option value="bulk">A business or institution</option>
              </Select>
            </Field>
            {buyerType === 'bulk' && (
              <Field label="Type of buyer">
                <Select defaultValue="restaurant">
                  {BULK.map((b) => <option key={b.value} value={b.value}>{b.label}</option>)}
                </Select>
              </Field>
            )}
          </div>
        )}

        {role === 'farmer' && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Where do you usually sell?" hint="Used to estimate how far a buyer takes you off your route.">
              <Select defaultValue="p_buxar_mandi">
                {places.map((place) => <option key={place.id} value={place.id}>{place.name}</option>)}
              </Select>
            </Field>
            <Field label="Extra distance you accept (km)" hint="Krishik will not suggest buyers beyond this without flagging it.">
              <Input type="number" min={0} max={80} defaultValue={10} />
            </Field>
          </div>
        )}

        {role === 'fpo' && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="FPO registration number" required>
              <Input required placeholder="FPO/BR/2021/0148" />
            </Field>
            <Field label="Member farmers">
              <Input type="number" min={1} defaultValue={120} />
            </Field>
          </div>
        )}

        <Button type="submit" size="lg" className="w-full">Create account</Button>
        <p className="text-center text-sm text-ink-mute">
          Already registered? <Link to="/login" className="font-medium text-forest-700 underline underline-offset-2">Sign in</Link>
        </p>
      </form>
    </div>
  )
}
