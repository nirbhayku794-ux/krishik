import { useState, type FormEvent } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Building2, ShoppingBasket, Shield, Sprout } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/context/ToastContext'
import { HOME_FOR } from '@/components/layout/nav'
import { Button } from '@/components/ui/Button'
import { Field, Input } from '@/components/ui/Field'
import type { Role } from '@/types'

const DEMO: { role: Role; label: string; email: string; blurb: string; icon: typeof Sprout }[] = [
  { role: 'farmer', label: 'Continue as farmer', email: 'farmer@krishik.demo', blurb: 'Ravi Kumar · Buxar', icon: Sprout },
  { role: 'buyer', label: 'Continue as buyer', email: 'buyer@krishik.demo', blurb: 'Annapurna Restaurant · bulk', icon: ShoppingBasket },
  { role: 'fpo', label: 'Continue as FPO', email: 'fpo@krishik.demo', blurb: 'Buxar Vegetable Producers', icon: Building2 },
  { role: 'admin', label: 'Continue as admin', email: 'admin@krishik.demo', blurb: 'Platform operations', icon: Shield },
]

export function Login() {
  const { signIn, signInAs } = useAuth()
  const { notify } = useToast()
  const navigate = useNavigate()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [error, setError] = useState<string | null>(null)

  const go = (role: Role) => {
    const from = (location.state as { from?: string } | null)?.from
    navigate(from && from !== '/login' ? from : HOME_FOR[role])
  }

  const onSubmit = (e: FormEvent) => {
    e.preventDefault()
    const user = signIn(email)
    if (!user) {
      setError('No demo account matches that email. Use one of the four accounts below.')
      return
    }
    notify(`Signed in as ${user.name}`, { body: 'Demo session — no password needed in the prototype.' })
    go(user.role)
  }

  return (
    <div className="mx-auto grid w-full max-w-5xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1fr_1fr] lg:py-20">
      <div>
        <h1 className="font-display text-3xl font-semibold">Sign in</h1>
        <p className="mt-2 text-ink-soft">
          The prototype runs on seeded accounts, so pick a role and walk the whole flow. No password is set up yet.
        </p>

        <form onSubmit={onSubmit} className="mt-6 space-y-4">
          <Field label="Email" required>
            <Input
              type="email"
              value={email}
              onChange={(e) => { setEmail(e.target.value); setError(null) }}
              placeholder="farmer@krishik.demo"
              autoComplete="email"
              required
            />
          </Field>
          {error && <p className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}
          <Button type="submit" size="lg" className="w-full">Sign in</Button>
        </form>

        <p className="mt-4 text-sm text-ink-mute">
          New here? <Link to="/register" className="font-medium text-forest-700 underline underline-offset-2">Create an account</Link>
        </p>
      </div>

      <div className="rounded-2xl border border-forest-100 bg-white p-6 shadow-card">
        <h2 className="font-display text-lg font-semibold">Demo accounts</h2>
        <p className="mt-1 text-sm text-ink-mute">One tap, no credentials. You can switch roles again from the sidebar.</p>
        <div className="mt-4 grid gap-2.5">
          {DEMO.map((item) => (
            <button
              key={item.role}
              onClick={() => { const u = signInAs(item.role); if (u) { notify(`Signed in as ${u.name}`); go(item.role) } }}
              className="flex items-center gap-3 rounded-xl border border-forest-100 bg-canvas/50 px-4 py-3 text-left transition hover:border-forest-400 hover:bg-forest-50"
            >
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-forest-600 text-white">
                <item.icon size={18} />
              </span>
              <span className="min-w-0">
                <span className="block font-medium">{item.label}</span>
                <span className="block truncate text-sm text-ink-mute">{item.blurb} · {item.email}</span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
