import { Boxes, IndianRupee, ScanSearch, Users } from 'lucide-react'
import { PageHeader } from '@/components/ui/PageHeader'
import { LinkButton } from '@/components/ui/Button'

const POINTS = [
  { icon: Boxes, title: 'Small orders still count', body: 'A hostel needing 150 kg and a restaurant needing 100 kg are pooled into one requirement that farmers can realistically fill.' },
  { icon: IndianRupee, title: 'One price, fully itemised', body: 'Asking price, estimated transport, platform cost and handling, shown against a reference mandi price before you commit.' },
  { icon: ScanSearch, title: 'Matched to sellers who can deliver', body: 'Matches are ranked on price headroom, distance, how much of your order a seller covers and whether it is ready in time.' },
  { icon: Users, title: 'Households and institutions both fit', body: 'Buy 12 kg for a kitchen or 900 kg for a canteen. The workflow is the same, only the pooling changes.' },
]

export function BuyerInfo() {
  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-12 sm:px-6">
      <PageHeader
        title="For consumers and bulk buyers"
        subtitle="Post what you need, see which farmers can cover it, and know the landed price before you place the order."
        action={<LinkButton to="/marketplace">Browse produce</LinkButton>}
      />

      <div className="grid gap-4 sm:grid-cols-2">
        {POINTS.map((point) => (
          <article key={point.title} className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
            <span className="mb-3 grid h-10 w-10 place-items-center rounded-xl bg-forest-50 text-forest-700">
              <point.icon size={18} />
            </span>
            <h2 className="font-display text-lg font-semibold">{point.title}</h2>
            <p className="mt-1.5 text-sm text-ink-soft">{point.body}</p>
          </article>
        ))}
      </div>

      <section className="mt-8 rounded-2xl border border-harvest-100 bg-harvest-50 p-6">
        <h2 className="font-display text-xl font-semibold">When buying direct will not help you</h2>
        <p className="mt-2 text-sm text-ink-soft">
          If the nearest farmer with your crop is 38 km off their usual route, the fuel cost can exceed the margin you were
          trying to avoid. Krishik shows that as low economic advantage and points you to a nearer seller instead of
          completing the sale quietly.
        </p>
        <LinkButton to="/logistics" variant="secondary" size="sm" className="mt-4">Check a route yourself</LinkButton>
      </section>
    </div>
  )
}
