import { PageHeader } from '@/components/ui/PageHeader'
import { LinkButton } from '@/components/ui/Button'

const MAPPING = [
  { problem: 'Long intermediary chains cut farmer earnings', feature: 'Direct marketplace where farmers and FPOs set their own asking price and sell to a confirmed buyer.' },
  { problem: 'Small buyers are too small to interest traders', feature: 'Demand aggregation pools fragmented requirements per crop into one order worth fulfilling.' },
  { problem: 'Consumers cannot see what they are paying for', feature: 'Price transparency shows asking price, transport, platform and handling against a reference mandi price.' },
  { problem: 'Produce travels further than it needs to', feature: 'Transport feasibility measures the extra distance a buyer adds to a trip the farmer was already making.' },
  { problem: 'Farmers plant and list blind to demand', feature: 'A prototype forecast compares expected demand with listed supply for the week ahead.' },
]

export function About() {
  return (
    <div className="mx-auto w-full max-w-4xl px-4 py-12 sm:px-6">
      <PageHeader
        title="About Krishik"
        subtitle="A prototype built for Smart India Hackathon problem statement SIH26033: multiple intermediaries reduce farmers' earnings and increase consumer prices."
      />

      <div className="space-y-6 text-ink-soft">
        <p>
          Krishik is a direct farm-to-buyer marketplace. Farmers and FPOs list what they have, consumers and bulk buyers
          state what they need, and the platform does the matching, the pricing arithmetic and the route check that a
          trader would otherwise do invisibly and for a fee.
        </p>

        <div className="rounded-2xl border border-forest-200 bg-forest-50 p-5">
          <h2 className="font-display text-lg font-semibold text-ink">The position we take</h2>
          <p className="mt-2">
            Removing every middleman does not automatically make food cheaper. Intermediaries carry produce, take risk and
            hold stock. What Krishik claims is narrower and testable: direct transactions become practical when demand is
            aggregated, pricing is transparent and the extra transport is actually measured. When those conditions do not
            hold, the platform says so rather than pushing the sale.
          </p>
        </div>

        <div>
          <h2 className="font-display text-xl font-semibold text-ink">How the problem maps to the product</h2>
          <ul className="mt-4 space-y-3">
            {MAPPING.map((row) => (
              <li key={row.problem} className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
                <p className="font-medium text-ink">{row.problem}</p>
                <p className="mt-1 text-sm">{row.feature}</p>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="font-display text-xl font-semibold text-ink">What is real and what is simulated</h2>
          <p className="mt-2">
            The matching, pricing, distance and feasibility logic all run for real in the browser on a seeded dataset of
            farmers, FPOs, buyers, listings and orders around Buxar, Ara, Patna and Varanasi. Authentication, payments,
            live mandi price feeds and satellite routing are not connected yet. Every estimated figure carries a label.
          </p>
        </div>

        <div className="flex flex-wrap gap-3 pt-2">
          <LinkButton to="/marketplace">See the marketplace</LinkButton>
          <LinkButton to="/login" variant="secondary">Open a demo account</LinkButton>
        </div>
      </div>
    </div>
  )
}
