import { MarketplaceBrowser } from '@/components/domain/MarketplaceBrowser'
import { PageHeader } from '@/components/ui/PageHeader'
import { Badge } from '@/components/ui/Badge'

export function MarketplacePreview() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6">
      <PageHeader
        title="What farmers are selling right now"
        subtitle="A public view of live listings. Prices are what the farmer asks for; the landed price a buyer pays is shown on every listing, transport included."
        meta={<Badge tone="harvest">Seeded demo listings</Badge>}
      />
      <MarketplaceBrowser mode="public" />
    </div>
  )
}
