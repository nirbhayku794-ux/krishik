import { ClipboardList, IndianRupee, ListChecks, Store } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { useService } from '@/lib/useService'
import { getAllMatches, getOrders, getRequirements } from '@/services'
import { productById } from '@/data/seed'
import { inr, kg, perKg, relativeDays } from '@/lib/format'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { Stat } from '@/components/ui/Stat'
import { Badge, OrderStatusPill } from '@/components/ui/Badge'
import { LinkButton } from '@/components/ui/Button'
import { Meter } from '@/components/ui/Meter'
import { SkeletonCards, SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'

export function BuyerDashboard() {
  const { user } = useAuth()
  const buyerId = user?.id ?? ''
  const { data: requirements, loading: loadingReqs } = useService(() => getRequirements(buyerId), [buyerId])
  const { data: orders, loading: loadingOrders } = useService(() => getOrders({ buyerId }), [buyerId])
  const { data: matches, loading: loadingMatches } = useService(() => getAllMatches(buyerId), [buyerId])

  const open = (requirements ?? []).filter((r) => r.status !== 'closed' && r.status !== 'matched')
  const live = (orders ?? []).filter((o) => o.status !== 'cancelled')
  const spend = live.reduce((s, o) => s + (o.pricing?.buyerTotal ?? o.pricePerKg * o.quantityKg), 0)
  const saved = live.reduce((s, o) => s + (o.pricing ? Math.max(0, o.pricing.differencePerKg) * o.quantityKg : 0), 0)
  const matchedKg = (matches ?? []).reduce((s, m) => s + m.matchedKg, 0)

  return (
    <>
      <PageHeader
        title={`Welcome back, ${(user as { businessName?: string } | null)?.businessName ?? user?.name.split(' ')[0] ?? 'buyer'}`}
        subtitle="Your open requirements, what farmers can cover today, and where each order stands."
        action={<LinkButton to="/buyer/requirements"><ListChecks size={16} /> Post a requirement</LinkButton>}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Open requirements" value={open.length} icon={<ListChecks size={16} />} hint={`${(requirements ?? []).length} posted in total`} />
        <Stat label="Supply matched" value={kg(matchedKg)} icon={<Store size={16} />} hint="Across your open requirements" />
        <Stat label="Live orders" value={live.length} icon={<ClipboardList size={16} />} hint={`${live.filter((o) => o.status === 'completed').length} completed`} />
        <Stat label="Estimated spend" value={inr(spend)} icon={<IndianRupee size={16} />} estimated hint={saved > 0 ? `About ${inr(saved)} under reference prices` : 'Landed price including transport'} tone="accent" />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <section>
          <SectionTitle
            title="What farmers can cover right now"
            hint="Live matching against your open requirements."
            action={<Link to="/buyer/matches" className="text-sm font-medium text-forest-700 hover:underline">See matches</Link>}
          />
          {loadingMatches && <SkeletonCards count={2} height="h-36" />}
          {matches && matches.length === 0 && (
            <EmptyState
              title="No open requirements"
              body="Post what you need for the week and Krishik will pool it with other buyers and match nearby farmers."
              action={<LinkButton to="/buyer/requirements" size="sm">Post a requirement</LinkButton>}
            />
          )}
          {matches && matches.length > 0 && (
            <div className="grid gap-3">
              {matches.slice(0, 3).map((match) => {
                const product = productById(match.requirement.productId)
                return (
                  <article key={match.requirement.id} className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <h3 className="font-display text-lg font-semibold">
                          {product.emoji} {product.name} · {kg(match.requirement.quantityKg)}
                        </h3>
                        <p className="text-sm text-ink-mute">
                          Needed {relativeDays(match.requirement.requiredBy)} · ceiling {perKg(match.requirement.maxPricePerKg)}
                        </p>
                      </div>
                      <Badge tone={match.shortfallKg === 0 ? 'forest' : 'harvest'}>
                        {match.shortfallKg === 0 ? 'Fully matched' : `${kg(match.shortfallKg)} short`}
                      </Badge>
                    </div>
                    <div className="mt-3">
                      <Meter
                        value={match.matchedKg}
                        max={match.requirement.quantityKg}
                        label={`${match.matches.length} ${match.matches.length === 1 ? 'seller' : 'sellers'} · weighted ${perKg(match.weightedPricePerKg || 0)}`}
                      />
                    </div>
                    <LinkButton to="/buyer/matches" variant="secondary" size="sm" className="mt-3">Review sellers</LinkButton>
                  </article>
                )
              })}
            </div>
          )}
        </section>

        <section>
          <SectionTitle title="Recent orders" action={<Link to="/buyer/orders" className="text-sm font-medium text-forest-700 hover:underline">All orders</Link>} />
          {loadingOrders && <SkeletonRows count={4} />}
          {orders && orders.length === 0 && (
            <EmptyState title="No orders yet" body="Order straight from a listing or accept a match to get started." action={<LinkButton to="/buyer/marketplace" size="sm">Browse produce</LinkButton>} />
          )}
          {orders && orders.length > 0 && (
            <ul className="space-y-2">
              {orders.slice(0, 5).map((order) => (
                <li key={order.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-forest-100 bg-white px-4 py-3 shadow-card">
                  <div>
                    <p className="font-medium">{productById(order.productId).emoji} {productById(order.productId).name} · {kg(order.quantityKg)}</p>
                    <p className="tnum text-sm text-ink-mute">
                      {order.pricing ? `${perKg(order.pricing.finalBuyerPricePerKg)} landed` : perKg(order.pricePerKg)}
                    </p>
                  </div>
                  <OrderStatusPill status={order.status} />
                </li>
              ))}
            </ul>
          )}
          {loadingReqs && <div className="mt-4"><SkeletonRows count={2} /></div>}
        </section>
      </div>
    </>
  )
}
