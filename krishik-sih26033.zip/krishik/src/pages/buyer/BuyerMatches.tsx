import { useState } from 'react'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/context/ToastContext'
import { useService } from '@/lib/useService'
import { createOrder, getAllMatches } from '@/services'
import { productById } from '@/data/seed'
import { kg } from '@/lib/format'
import { PageHeader } from '@/components/ui/PageHeader'
import { Badge } from '@/components/ui/Badge'
import { MatchList } from '@/components/domain/MatchList'
import { SkeletonCards } from '@/components/ui/Skeleton'
import { EmptyState, ErrorState } from '@/components/ui/EmptyState'
import { LinkButton } from '@/components/ui/Button'

export function BuyerMatches() {
  const { user } = useAuth()
  const { notify } = useToast()
  const buyerId = user?.id ?? ''
  const { data: matches, loading, error, reload } = useService(() => getAllMatches(buyerId), [buyerId])
  const [busyId, setBusyId] = useState<string | null>(null)

  const accept = async (requirementId: string, listingId: string, quantityKg: number) => {
    if (!user) return
    setBusyId(listingId)
    const order = await createOrder({ listingId, buyerId: user.id, quantityKg, requirementId })
    setBusyId(null)
    if (!order) {
      notify('Could not place that order', { body: 'The seller no longer has that quantity available.', tone: 'warning' })
      return
    }
    notify('Order placed', {
      body: `${kg(quantityKg)} of ${productById(order.productId).name.toLowerCase()} sent to the seller for acceptance.`,
    })
  }

  return (
    <>
      <PageHeader
        title="Supply matches"
        subtitle="Nearby sellers ranked against each open requirement, with the quantity each one can cover."
        meta={<Badge tone="harvest">Match score is a prototype ranking, not a guarantee</Badge>}
      />

      {loading && <SkeletonCards count={3} height="h-56" />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {matches && matches.length === 0 && (
        <EmptyState
          title="No requirements to match"
          body="Post what you need and Krishik will rank the farmers and FPOs who can cover it."
          action={<LinkButton to="/buyer/requirements" size="sm">Post a requirement</LinkButton>}
        />
      )}

      {matches && matches.length > 0 && (
        <div className="space-y-8">
          {matches.map((match) => (
            <section key={match.requirement.id}>
              {match.matches.length === 0 ? (
                <div className="rounded-2xl border border-harvest-100 bg-harvest-50 p-5">
                  <h2 className="font-display text-lg font-semibold">
                    {productById(match.requirement.productId).name} · {kg(match.requirement.quantityKg)}
                  </h2>
                  <p className="mt-1 text-sm text-ink-soft">
                    No seller currently clears both your price ceiling and the transport check. Raising the ceiling slightly or
                    moving the pickup point closer to a farming cluster usually opens matches.
                  </p>
                </div>
              ) : (
                <MatchList
                  result={match}
                  busyId={busyId}
                  onAccept={(listingId, quantityKg) => accept(match.requirement.id, listingId, quantityKg)}
                />
              )}
            </section>
          ))}
        </div>
      )}
    </>
  )
}
