import { MarketplaceBrowser } from '@/components/domain/MarketplaceBrowser'
import { PageHeader } from '@/components/ui/PageHeader'
import { LinkButton } from '@/components/ui/Button'

export function BuyerMarketplace() {
  return (
    <>
      <PageHeader
        title="Browse produce"
        subtitle="Open any listing to see the landed price and the transport check before you order."
        action={<LinkButton to="/buyer/requirements" variant="secondary">Post a requirement instead</LinkButton>}
      />
      <MarketplaceBrowser mode="buyer" />
    </>
  )
}
