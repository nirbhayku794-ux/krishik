import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { Users } from 'lucide-react'
import { iso, places, productById, products } from '@/data/seed'
import type { BulkCategory, BuyerType } from '@/types'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/context/ToastContext'
import { useService } from '@/lib/useService'
import { closeRequirement, createRequirement, getDemandPools, getRequirements } from '@/services'
import { kg, perKg, relativeDays, titleCase } from '@/lib/format'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { Field, Input, Select } from '@/components/ui/Field'
import { Button, LinkButton } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Meter } from '@/components/ui/Meter'
import { SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'

const BULK: BulkCategory[] = ['retailer', 'restaurant', 'hostel', 'canteen', 'business', 'institution']

export function BuyerRequirements() {
  const { user } = useAuth()
  const { notify } = useToast()
  const navigate = useNavigate()
  const buyer = user as { id: string; placeId: string; buyerType?: BuyerType; bulkCategory?: BulkCategory } | null

  const [productId, setProductId] = useState('pr_tomato')
  const [quantity, setQuantity] = useState('300')
  const [maxPrice, setMaxPrice] = useState('22')
  const [requiredBy, setRequiredBy] = useState(iso(4).slice(0, 10))
  const [buyerPlaceId, setBuyerPlaceId] = useState(buyer?.placeId ?? 'p_buxar')
  const [pickupPlaceId, setPickupPlaceId] = useState(buyer?.placeId ?? 'p_buxar')
  const [buyerType, setBuyerType] = useState<BuyerType>(buyer?.buyerType ?? 'bulk')
  const [bulkCategory, setBulkCategory] = useState<BulkCategory>(buyer?.bulkCategory ?? 'restaurant')
  const [saving, setSaving] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const { data: requirements, loading } = useService(() => getRequirements(buyer?.id ?? ''), [buyer?.id])
  const { data: pools } = useService(() => getDemandPools())
  const pool = pools?.find((p) => p.productId === productId)

  const validate = () => {
    const next: Record<string, string> = {}
    if (!productId) next.productId = 'Choose a crop.'
    if (!(Number(quantity) > 0)) next.quantity = 'Quantity must be greater than zero.'
    if (!(Number(maxPrice) > 0)) next.maxPrice = 'Maximum price must be greater than zero.'
    if (!requiredBy) next.requiredBy = 'Pick the date you need it by.'
    else if (new Date(requiredBy) < new Date(new Date().toDateString())) next.requiredBy = 'The required date cannot be in the past.'
    if (!pickupPlaceId) next.pickupPlaceId = 'Select a pickup or delivery point.'
    setErrors(next)
    return Object.keys(next).length === 0
  }

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault()
    if (!buyer) return
    if (!validate()) {
      notify('Check the highlighted fields', { body: 'A requirement needs a positive quantity, a price ceiling and a future date.', tone: 'warning' })
      return
    }
    setSaving(true)
    await createRequirement({
      buyerId: buyer.id,
      productId,
      quantityKg: Number(quantity),
      maxPricePerKg: Number(maxPrice),
      requiredBy: new Date(requiredBy).toISOString(),
      buyerPlaceId,
      pickupPlaceId,
      buyerType,
      bulkCategory: buyerType === 'bulk' ? bulkCategory : undefined,
    })
    setSaving(false)
    notify('Requirement posted', {
      body: `${quantity} kg of ${productById(productId).name.toLowerCase()} is now being matched against nearby supply.`,
    })
    navigate('/buyer/matches')
  }

  return (
    <>
      <PageHeader
        title="Requirements"
        subtitle="Say what you need and by when. Krishik pools it with other buyers asking for the same crop, then splits it across farmers who can cover it."
      />

      <div className="grid gap-6 lg:grid-cols-[1.15fr_1fr]">
        <form onSubmit={onSubmit} className="space-y-5 rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
          <h2 className="font-display text-lg font-semibold">Post a requirement</h2>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Product" required>
              <Select value={productId} onChange={(e) => setProductId(e.target.value)}>
                {products.map((p) => <option key={p.id} value={p.id}>{p.emoji} {p.name}</option>)}
              </Select>
            </Field>
            <Field label="Quantity required (kg)" required error={errors.quantity}>
              <Input type="number" min={1} value={quantity} onChange={(e) => setQuantity(e.target.value)} required />
            </Field>
            <Field label="Maximum price (₹/kg)" required hint={`Reference mandi price: ${perKg(productById(productId).referencePricePerKg)} (demo).`} error={errors.maxPrice}>
              <Input type="number" min={1} step="0.5" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} required />
            </Field>
            <Field label="Required by" required error={errors.requiredBy}>
              <Input type="date" value={requiredBy} onChange={(e) => setRequiredBy(e.target.value)} required />
            </Field>
            <Field label="Your location" required>
              <Select value={buyerPlaceId} onChange={(e) => setBuyerPlaceId(e.target.value)}>
                {places.map((p) => <option key={p.id} value={p.id}>{p.name}, {p.district}</option>)}
              </Select>
            </Field>
            <Field label="Pickup or delivery point" required hint="Where the handover happens. Distance is measured to here.">
              <Select value={pickupPlaceId} onChange={(e) => setPickupPlaceId(e.target.value)}>
                {places.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </Select>
            </Field>
            <Field label="Buying for" required>
              <Select value={buyerType} onChange={(e) => setBuyerType(e.target.value as BuyerType)}>
                <option value="individual">My household</option>
                <option value="bulk">A business or institution</option>
              </Select>
            </Field>
            {buyerType === 'bulk' && (
              <Field label="Buyer type" required>
                <Select value={bulkCategory} onChange={(e) => setBulkCategory(e.target.value as BulkCategory)}>
                  {BULK.map((b) => <option key={b} value={b}>{titleCase(b)}</option>)}
                </Select>
              </Field>
            )}
          </div>

          <Button type="submit" size="lg" disabled={saving}>{saving ? 'Posting…' : 'Post requirement'}</Button>
        </form>

        <aside className="space-y-4">
          <div className="rounded-2xl border border-forest-200 bg-forest-50 p-5">
            <h2 className="flex items-center gap-2 font-display text-lg font-semibold">
              <Users size={18} className="text-forest-700" /> Who else is asking for this
            </h2>
            {pool ? (
              <>
                <p className="mt-1 text-sm text-ink-soft">
                  {pool.demands.length} open {pool.demands.length === 1 ? 'requirement' : 'requirements'} for {pool.productName.toLowerCase()},
                  pooled into {kg(pool.demandKg)} against {kg(pool.supplyKg)} listed supply.
                </p>
                <div className="mt-3">
                  <Meter value={Math.min(pool.supplyKg, pool.demandKg)} max={Math.max(pool.demandKg, 1)} />
                </div>
                <ul className="mt-3 space-y-1.5 text-sm">
                  {pool.demands.slice(0, 5).map((d) => (
                    <li key={d.requirementId} className="flex items-center justify-between gap-3">
                      <span className="truncate text-ink-soft">{d.buyerName}</span>
                      <span className="tnum shrink-0 font-medium">{kg(d.quantityKg)}</span>
                    </li>
                  ))}
                </ul>
              </>
            ) : (
              <p className="mt-1 text-sm text-ink-soft">You would be the first buyer asking for this crop this week.</p>
            )}
          </div>

          <div>
            <SectionTitle title="Your requirements" />
            {loading && <SkeletonRows count={3} />}
            {requirements && requirements.length === 0 && (
              <EmptyState title="Nothing posted yet" body="Your requirements will be listed here with how much of each is matched." />
            )}
            {requirements && requirements.length > 0 && (
              <ul className="space-y-2">
                {requirements.map((r) => {
                  const product = productById(r.productId)
                  return (
                    <li key={r.id} className="rounded-xl border border-forest-100 bg-white p-4 shadow-card">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <p className="font-medium">{product.emoji} {product.name} · {kg(r.quantityKg)}</p>
                          <p className="text-sm text-ink-mute">
                            Ceiling {perKg(r.maxPricePerKg)} · needed {relativeDays(r.requiredBy)}
                          </p>
                        </div>
                        <Badge tone={r.status === 'matched' ? 'forest' : r.status === 'closed' ? 'neutral' : 'harvest'}>
                          {titleCase(r.status)}
                        </Badge>
                      </div>
                      <div className="mt-2">
                        <Meter value={r.matchedKg} max={r.quantityKg} label={`${kg(r.matchedKg)} matched`} />
                      </div>
                      {r.status !== 'closed' && (
                        <div className="mt-2 flex gap-2">
                          <LinkButton to="/buyer/matches" variant="secondary" size="sm">See matches</LinkButton>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={async () => { await closeRequirement(r.id); notify('Requirement closed') }}
                          >
                            Close
                          </Button>
                        </div>
                      )}
                    </li>
                  )
                })}
              </ul>
            )}
          </div>
        </aside>
      </div>
    </>
  )
}
