import { useAuth } from '@/context/AuthContext'
import { OrdersView } from '@/components/domain/OrdersView'
import { PageHeader } from '@/components/ui/PageHeader'

export function BuyerOrders() {
  const { user, role } = useAuth()
  if (!user || !role) return null
  return (
    <>
      <PageHeader
        title="Orders"
        subtitle="Each order carries its own price breakdown and transport check. Confirm once you are happy with the final landed price."
      />
      <OrdersView perspective="buyer" userId={user.id} role={role} />
    </>
  )
}
