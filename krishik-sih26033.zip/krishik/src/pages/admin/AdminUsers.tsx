import { useMemo, useState } from 'react'
import { Search } from 'lucide-react'
import { useService } from '@/lib/useService'
import { getUsers, setVerified } from '@/services'
import { useToast } from '@/context/ToastContext'
import { placeById, places } from '@/data/seed'
import { date, initials, titleCase } from '@/lib/format'
import type { AnyUser, Role } from '@/types'
import { PageHeader } from '@/components/ui/PageHeader'
import { DataTable } from '@/components/ui/Table'
import { Badge, VerifiedBadge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Field, Select } from '@/components/ui/Field'
import { Modal } from '@/components/ui/Modal'
import { SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState, ErrorState } from '@/components/ui/EmptyState'

export function AdminUsers() {
  const { notify } = useToast()
  const { data: users, loading, error, reload } = useService(() => getUsers())
  const [search, setSearch] = useState('')
  const [role, setRole] = useState<Role | 'any'>('any')
  const [placeId, setPlaceId] = useState('any')
  const [status, setStatus] = useState<'any' | 'verified' | 'unverified'>('any')
  const [detail, setDetail] = useState<AnyUser | null>(null)

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase()
    return (users ?? []).filter((u) => {
      if (role !== 'any' && u.role !== role) return false
      if (placeId !== 'any' && u.placeId !== placeId) return false
      if (status === 'verified' && !u.verified) return false
      if (status === 'unverified' && u.verified) return false
      if (q && !(u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q))) return false
      return true
    })
  }, [users, search, role, placeId, status])

  const toggle = async (user: AnyUser) => {
    await setVerified(user.id, !user.verified)
    notify(user.verified ? 'Verification removed' : 'User verified', { body: user.name })
    reload()
  }

  return (
    <>
      <PageHeader title="Users" subtitle="Farmers, FPOs, buyers and operators registered on the platform." />

      <div className="mb-4 grid gap-3 rounded-2xl border border-forest-100 bg-white p-4 shadow-card sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <span className="field-label">Search</span>
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-mute" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Name or email"
              className="field-input pl-9"
              aria-label="Search users"
            />
          </div>
        </div>
        <Field label="Role">
          <Select value={role} onChange={(e) => setRole(e.target.value as Role | 'any')}>
            <option value="any">All roles</option>
            <option value="farmer">Farmer</option>
            <option value="fpo">FPO</option>
            <option value="buyer">Buyer</option>
            <option value="admin">Admin</option>
          </Select>
        </Field>
        <Field label="Location">
          <Select value={placeId} onChange={(e) => setPlaceId(e.target.value)}>
            <option value="any">Anywhere</option>
            {places.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
        </Field>
        <Field label="Status">
          <Select value={status} onChange={(e) => setStatus(e.target.value as 'any' | 'verified' | 'unverified')}>
            <option value="any">Any status</option>
            <option value="verified">Verified</option>
            <option value="unverified">Not verified</option>
          </Select>
        </Field>
      </div>

      {loading && <SkeletonRows count={6} />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {users && (
        <DataTable
          rows={rows}
          rowKey={(u) => u.id}
          empty={
            <EmptyState
              title="No users match these filters"
              body="Clear the search or widen the role and location filters."
              action={<Button variant="secondary" size="sm" onClick={() => { setSearch(''); setRole('any'); setPlaceId('any'); setStatus('any') }}>Clear filters</Button>}
            />
          }
          columns={[
            {
              header: 'User',
              cell: (u) => (
                <div className="flex items-center gap-2.5">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-forest-600 text-xs font-semibold text-white">
                    {initials(u.name)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate font-medium">{u.name}</p>
                    <p className="truncate text-xs text-ink-mute">{u.email}</p>
                  </div>
                </div>
              ),
            },
            { header: 'Role', cell: (u) => <Badge tone={u.role === 'admin' ? 'clay' : 'neutral'}>{titleCase(u.role)}</Badge> },
            { header: 'Location', hideOnMobile: true, cell: (u) => placeById(u.placeId).name },
            { header: 'Joined', hideOnMobile: true, cell: (u) => date(u.joinedOn) },
            { header: 'Status', cell: (u) => <VerifiedBadge verified={u.verified} /> },
            {
              header: 'Actions',
              align: 'right',
              cell: (u) => (
                <div className="flex justify-end gap-1.5">
                  <Button variant="ghost" size="sm" onClick={() => setDetail(u)}>Details</Button>
                  <Button variant="secondary" size="sm" onClick={() => toggle(u)}>
                    {u.verified ? 'Unverify' : 'Verify'}
                  </Button>
                </div>
              ),
            },
          ]}
        />
      )}

      <Modal open={!!detail} onClose={() => setDetail(null)} title={detail?.name ?? ''} width="max-w-lg">
        {detail && (
          <dl className="space-y-2.5 text-sm">
            {[
              ['Role', titleCase(detail.role)],
              ['Email', detail.email],
              ['Phone', detail.phone],
              ['Location', placeById(detail.placeId).name],
              ['Joined', date(detail.joinedOn)],
              ['Status', detail.verified ? 'Verified' : 'Not yet verified'],
              ...('businessName' in detail && detail.businessName ? [['Business', detail.businessName as string]] : []),
              ...('buyerType' in detail ? [['Buyer type', titleCase(String(detail.buyerType))]] : []),
              ...('farmSizeAcres' in detail ? [['Farm size', `${detail.farmSizeAcres} acres`]] : []),
              ...('vehicleAccess' in detail ? [['Vehicle access', titleCase(String(detail.vehicleAccess).replace(/-/g, ' '))]] : []),
              ...('memberCount' in detail ? [['Member farmers', String(detail.memberCount)]] : []),
              ...('registrationNo' in detail ? [['Registration', String(detail.registrationNo)]] : []),
            ].map(([label, value]) => (
              <div key={label} className="flex items-baseline justify-between gap-4 border-b border-forest-50 pb-2">
                <dt className="text-ink-mute">{label}</dt>
                <dd className="text-right font-medium">{value}</dd>
              </div>
            ))}
          </dl>
        )}
      </Modal>
    </>
  )
}
