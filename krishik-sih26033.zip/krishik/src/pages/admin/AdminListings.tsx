import { useMemo, useState } from 'react'
import { Search } from 'lucide-react'
import { useService } from '@/lib/useService'
import { getListings, sellerName, updateListingStatus } from '@/services'
import { useToast } from '@/context/ToastContext'
import { placeById, places, productById, products } from '@/data/seed'
import { date, kg, perKg } from '@/lib/format'
import { PageHeader } from '@/components/ui/PageHeader'
import { DataTable } from '@/components/ui/Table'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Field, Select } from '@/components/ui/Field'
import { Meter } from '@/components/ui/Meter'
import { SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState, ErrorState } from '@/components/ui/EmptyState'

export function AdminListings() {
  const { notify } = useToast()
  const { data: listings, loading, error, reload } = useService(() => getListings({ availableOnly: false }))
  const [search, setSearch] = useState('')
  const [productId, setProductId] = useState('any')
  const [placeId, setPlaceId] = useState('any')
  const [status, setStatus] = useState('any')

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase()
    return (listings ?? []).filter((l) => {
      if (productId !== 'any' && l.productId !== productId) return false
      if (placeId !== 'any' && l.farmPlaceId !== placeId) return false
      if (status !== 'any' && l.status !== status) return false
      if (q && !(productById(l.productId).name.toLowerCase().includes(q) || sellerName(l.sellerId).toLowerCase().includes(q))) return false
      return true
    })
  }, [listings, search, productId, placeId, status])

  return (
    <>
      <PageHeader title="Listings" subtitle="Every lot published by farmers and FPOs, with how much of it has been matched." />

      <div className="mb-4 grid gap-3 rounded-2xl border border-forest-100 bg-white p-4 shadow-card sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <span className="field-label">Search</span>
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-mute" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Crop or seller" className="field-input pl-9" aria-label="Search listings" />
          </div>
        </div>
        <Field label="Crop">
          <Select value={productId} onChange={(e) => setProductId(e.target.value)}>
            <option value="any">All crops</option>
            {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
        </Field>
        <Field label="Location">
          <Select value={placeId} onChange={(e) => setPlaceId(e.target.value)}>
            <option value="any">Anywhere</option>
            {places.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
        </Field>
        <Field label="Status">
          <Select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="any">Any status</option>
            <option value="active">Active</option>
            <option value="reserved">Paused</option>
            <option value="sold">Sold</option>
          </Select>
        </Field>
      </div>

      {loading && <SkeletonRows count={6} />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {listings && (
        <DataTable
          rows={rows}
          rowKey={(l) => l.id}
          empty={
            <EmptyState
              title="No listings match these filters"
              body="Widen the crop, location or status filter to see more."
              action={<Button variant="secondary" size="sm" onClick={() => { setSearch(''); setProductId('any'); setPlaceId('any'); setStatus('any') }}>Clear filters</Button>}
            />
          }
          columns={[
            {
              header: 'Crop',
              cell: (l) => (
                <div className="flex items-center gap-2.5">
                  <span aria-hidden className="text-lg">{productById(l.productId).emoji}</span>
                  <div>
                    <p className="font-medium">{productById(l.productId).name}</p>
                    <p className="text-xs text-ink-mute">Grade {l.grade}</p>
                  </div>
                </div>
              ),
            },
            {
              header: 'Seller',
              cell: (l) => (
                <div>
                  <p className="font-medium">{sellerName(l.sellerId)}</p>
                  <p className="text-xs text-ink-mute">{l.sellerRole === 'fpo' ? 'FPO' : 'Farmer'} · {placeById(l.farmPlaceId).name}</p>
                </div>
              ),
            },
            { header: 'Quantity', align: 'right', cell: (l) => kg(l.quantityKg) },
            {
              header: 'Matched',
              cell: (l) => (
                <div className="w-28">
                  <p className="tnum text-sm">{kg(l.quantityKg - l.remainingKg)}</p>
                  <Meter value={l.quantityKg - l.remainingKg} max={l.quantityKg} />
                </div>
              ),
            },
            { header: 'Price', align: 'right', cell: (l) => perKg(l.pricePerKg) },
            { header: 'Listed', hideOnMobile: true, cell: (l) => date(l.createdAt) },
            {
              header: 'Status',
              cell: (l) => (
                <Badge tone={l.status === 'active' ? 'forest' : l.status === 'sold' ? 'neutral' : 'harvest'}>
                  {l.status === 'reserved' ? 'Paused' : l.status.charAt(0).toUpperCase() + l.status.slice(1)}
                </Badge>
              ),
            },
            {
              header: 'Actions',
              align: 'right',
              cell: (l) =>
                l.status === 'sold' ? (
                  <span className="text-sm text-ink-mute">—</span>
                ) : (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={async () => {
                      const next = l.status === 'active' ? 'reserved' : 'active'
                      await updateListingStatus(l.id, next)
                      notify(next === 'active' ? 'Listing restored' : 'Listing paused', { body: `${productById(l.productId).name} · ${sellerName(l.sellerId)}` })
                    }}
                  >
                    {l.status === 'active' ? 'Pause' : 'Restore'}
                  </Button>
                ),
            },
          ]}
        />
      )}
    </>
  )
}
