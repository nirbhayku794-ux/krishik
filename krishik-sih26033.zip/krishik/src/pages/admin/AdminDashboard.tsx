import { Boxes, ClipboardList, ListChecks, Scale, Store, Users } from 'lucide-react'
import { Link } from 'react-router-dom'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useService } from '@/lib/useService'
import { getOrders, getPlatformAnalytics } from '@/services'
import { findUser } from '@/services'
import { productById } from '@/data/seed'
import { inr, inrShort, kg, perKg } from '@/lib/format'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { Stat } from '@/components/ui/Stat'
import { Badge, OrderStatusPill } from '@/components/ui/Badge'
import { Meter } from '@/components/ui/Meter'
import { Card, CardBody, CardHead } from '@/components/ui/Card'
import { SkeletonCards, SkeletonRows } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/EmptyState'

export function AdminDashboard() {
  const { data: analytics, loading, error, reload } = useService(() => getPlatformAnalytics())
  const { data: orders } = useService(() => getOrders())

  const activeOrders = (orders ?? []).filter((o) => !['completed', 'cancelled'].includes(o.status))

  return (
    <>
      <PageHeader
        title="Platform overview"
        subtitle="Supply, demand and matching across every district in the prototype dataset."
        meta={<Badge tone="harvest">Seeded demo data · estimated figures are labelled</Badge>}
      />

      {loading && <SkeletonCards count={4} height="h-32" />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {analytics && (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Registered farmers" value={analytics.farmers} icon={<Users size={16} />} hint={`${analytics.fpos} FPOs aggregating produce`} />
            <Stat label="Registered buyers" value={analytics.buyers} icon={<Store size={16} />} hint="Households, retailers and institutions" />
            <Stat label="Active listings" value={analytics.activeListings} icon={<Boxes size={16} />} hint={`${kg(analytics.listedKg)} listed`} />
            <Stat label="Active requirements" value={analytics.openRequirements} icon={<ListChecks size={16} />} hint={`${kg(analytics.demandKg)} of demand`} />
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Matched quantity" value={kg(analytics.matchedKg)} icon={<Scale size={16} />} hint={`${kg(analytics.unmatchedKg)} unmatched`} tone="accent" />
            <Stat label="Active orders" value={activeOrders.length} icon={<ClipboardList size={16} />} hint={`${analytics.completedOrders} completed transactions`} />
            <Stat label="Transaction value" value={inrShort(analytics.transactionValue)} estimated hint="Landed value across live orders" />
            <Stat label="Unnecessary movement avoided" value={`${analytics.movementReductionPct}%`} estimated hint="Against a four-hop conventional chain" />
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-[1.2fr_1fr]">
            <Card>
              <CardHead title="Matched quantity by month" subtitle="Volume moving through direct matches, in kilograms." />
              <CardBody>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={analytics.monthly} margin={{ top: 8, right: 8, bottom: 0, left: -14 }}>
                      <defs>
                        <linearGradient id="adminArea" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#2F7658" stopOpacity={0.35} />
                          <stop offset="100%" stopColor="#2F7658" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke="#EDF5F0" vertical={false} />
                      <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#6B7C74' }} tickLine={false} axisLine={false} />
                      <YAxis tick={{ fontSize: 11, fill: '#6B7C74' }} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #D6E8DD', fontSize: 12 }} formatter={(v: number) => `${v} kg`} />
                      <Area type="monotone" dataKey="matchedKg" name="Matched" stroke="#2F7658" strokeWidth={2} fill="url(#adminArea)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHead title="Price spread" subtitle="What farmers receive against what buyers pay, and the reference market price." />
              <CardBody className="space-y-4">
                <div>
                  <p className="text-sm text-ink-mute">Average farmer price</p>
                  <p className="tnum font-display text-2xl font-semibold text-forest-700">{perKg(analytics.avgFarmerPrice)}</p>
                </div>
                <div>
                  <p className="text-sm text-ink-mute">Average buyer landed price</p>
                  <p className="tnum font-display text-2xl font-semibold">{perKg(analytics.avgBuyerPrice)}</p>
                </div>
                <div>
                  <p className="text-sm text-ink-mute">Reference market price (demo)</p>
                  <p className="tnum font-display text-2xl font-semibold text-ink-mute">{perKg(analytics.avgReferencePrice)}</p>
                </div>
                <div className="border-t border-forest-100 pt-3">
                  <Meter
                    value={Math.max(0, analytics.avgReferencePrice - analytics.avgBuyerPrice)}
                    max={Math.max(analytics.avgReferencePrice, 1)}
                    label={`Buyers pay about ${perKg(Math.max(0, analytics.avgReferencePrice - analytics.avgBuyerPrice))} under the reference price on average`}
                  />
                </div>
                <p className="text-xs text-ink-mute">
                  Estimated transport across live orders: {inr(analytics.transportCost)}.
                </p>
              </CardBody>
            </Card>
          </div>

          <div className="mt-6">
            <SectionTitle
              title="Live orders"
              hint="Everything currently moving through the lifecycle."
              action={<Link to="/admin/orders" className="text-sm font-medium text-forest-700 hover:underline">Manage orders</Link>}
            />
            {!orders && <SkeletonRows count={4} />}
            {orders && (
              <ul className="space-y-2">
                {(activeOrders.length ? activeOrders : orders).slice(0, 6).map((order) => (
                  <li key={order.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-forest-100 bg-white px-4 py-3 shadow-card">
                    <div>
                      <p className="font-medium">
                        {productById(order.productId).emoji} {productById(order.productId).name} · {kg(order.quantityKg)}
                      </p>
                      <p className="text-sm text-ink-mute">
                        {findUser(order.sellerId)?.name ?? '—'} → {findUser(order.buyerId)?.name ?? '—'}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="tnum text-sm text-ink-soft">{inr(order.pricing?.buyerTotal ?? order.pricePerKg * order.quantityKg)}</span>
                      <OrderStatusPill status={order.status} />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      )}
    </>
  )
}
