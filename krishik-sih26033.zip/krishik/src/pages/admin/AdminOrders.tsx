import { useMemo, useState } from 'react'
import { useService } from '@/lib/useService'
import { cancelOrder, findUser, getOrders } from '@/services'
import { useToast } from '@/context/ToastContext'
import { productById } from '@/data/seed'
import { date, inr, kg, perKg, titleCase } from '@/lib/format'
import type { Order, OrderStatus } from '@/types'
import { PageHeader } from '@/components/ui/PageHeader'
import { DataTable } from '@/components/ui/Table'
import { OrderStatusPill, FeasibilityPill } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Field, Select } from '@/components/ui/Field'
import { Modal, ConfirmDialog } from '@/components/ui/Modal'
import { SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState, ErrorState } from '@/components/ui/EmptyState'
import { PricePanel } from '@/components/domain/PricePanel'
import { FeasibilityPanel } from '@/components/domain/FeasibilityPanel'
import { OrderProgress, OrderTimeline } from '@/components/domain/OrderTimeline'

const STATUSES: (OrderStatus | 'any')[] = ['any', 'pending', 'feasibility_check', 'awaiting_confirmation', 'confirmed', 'completed', 'cancelled']

export function AdminOrders() {
  const { notify } = useToast()
  const { data: orders, loading, error, reload } = useService(() => getOrders())
  const [status, setStatus] = useState<OrderStatus | 'any'>('any')
  const [detail, setDetail] = useState<Order | null>(null)
  const [toCancel, setToCancel] = useState<Order | null>(null)

  const rows = useMemo(
    () => (orders ?? []).filter((o) => status === 'any' || o.status === status),
    [orders, status],
  )

  return (
    <>
      <PageHeader
        title="Orders and transactions"
        subtitle="Every order with its product value, transport estimate and final landed value."
      />

      <div className="mb-4 max-w-xs">
        <Field label="Filter by status">
          <Select value={status} onChange={(e) => setStatus(e.target.value as OrderStatus | 'any')}>
            {STATUSES.map((s) => <option key={s} value={s}>{s === 'any' ? 'All statuses' : titleCase(s)}</option>)}
          </Select>
        </Field>
      </div>

      {loading && <SkeletonRows count={6} />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {orders && (
        <DataTable
          rows={rows}
          rowKey={(o) => o.id}
          empty={<EmptyState title="No orders with this status" body="Change the filter to see orders at other stages of the lifecycle." />}
          columns={[
            { header: 'Order', cell: (o) => <span className="font-medium">{o.id.toUpperCase()}</span> },
            {
              header: 'Parties',
              cell: (o) => (
                <div>
                  <p className="font-medium">{findUser(o.sellerId)?.name ?? '—'}</p>
                  <p className="text-xs text-ink-mute">to {findUser(o.buyerId)?.name ?? '—'}</p>
                </div>
              ),
            },
            {
              header: 'Crop',
              cell: (o) => (
                <span>
                  {productById(o.productId).emoji} {productById(o.productId).name}
                  <span className="block text-xs text-ink-mute tnum">{kg(o.quantityKg)} at {perKg(o.pricePerKg)}</span>
                </span>
              ),
            },
            { header: 'Product value', align: 'right', cell: (o) => inr(o.pricePerKg * o.quantityKg) },
            {
              header: 'Transport',
              align: 'right',
              hideOnMobile: true,
              cell: (o) => (o.transport ? `${inr(o.transport.additionalCost)}` : '—'),
            },
            {
              header: 'Landed value',
              align: 'right',
              cell: (o) => (o.pricing ? inr(o.pricing.buyerTotal) : '—'),
            },
            { header: 'Placed', hideOnMobile: true, cell: (o) => date(o.createdAt) },
            { header: 'Status', cell: (o) => <OrderStatusPill status={o.status} /> },
            {
              header: 'Actions',
              align: 'right',
              cell: (o) => (
                <div className="flex justify-end gap-1.5">
                  <Button variant="ghost" size="sm" onClick={() => setDetail(o)}>Open</Button>
                  {!['completed', 'cancelled'].includes(o.status) && (
                    <Button variant="ghost" size="sm" onClick={() => setToCancel(o)}>Cancel</Button>
                  )}
                </div>
              ),
            },
          ]}
        />
      )}

      <Modal
        open={!!detail}
        onClose={() => setDetail(null)}
        width="max-w-3xl"
        title={detail ? `Order ${detail.id.toUpperCase()} · ${productById(detail.productId).name}` : ''}
      >
        {detail && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <OrderStatusPill status={detail.status} />
              {detail.transport && <FeasibilityPill status={detail.transport.status} />}
            </div>
            <OrderProgress status={detail.status} />
            {detail.pricing && <PricePanel pricing={detail.pricing} quantityKg={detail.quantityKg} />}
            {detail.transport && <FeasibilityPanel analysis={detail.transport} showMap={false} />}
            <div className="rounded-2xl border border-forest-100 bg-white p-5 shadow-card">
              <h3 className="mb-3 font-semibold">Order history</h3>
              <OrderTimeline order={detail} />
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!toCancel}
        onClose={() => setToCancel(null)}
        onConfirm={async () => {
          if (!toCancel) return
          await cancelOrder(toCancel.id, 'admin')
          notify('Order cancelled', { body: 'The reserved quantity has been returned to the listing.', tone: 'warning' })
        }}
        title="Cancel this order?"
        body="Both parties are notified and the reserved quantity returns to the seller's listing."
        confirmLabel="Cancel order"
        tone="danger"
      />
    </>
  )
}
