import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useService } from '@/lib/useService'
import { getDemandForecast, getListings, getPlatformAnalytics, getRequirements } from '@/services'
import { placeById } from '@/data/seed'
import { inr, inrShort, kg, perKg } from '@/lib/format'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { Stat } from '@/components/ui/Stat'
import { Badge } from '@/components/ui/Badge'
import { Meter } from '@/components/ui/Meter'
import { Card, CardBody, CardHead } from '@/components/ui/Card'
import { SkeletonCards } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/EmptyState'

const AXIS = { fontSize: 11, fill: '#6B7C74' }
const TOOLTIP = { borderRadius: 12, border: '1px solid #D6E8DD', fontSize: 12 }

export function AdminAnalytics() {
  const { data: analytics, loading, error, reload } = useService(() => getPlatformAnalytics())
  const { data: forecasts } = useService(() => getDemandForecast(7))
  const { data: listings } = useService(() => getListings())
  const { data: requirements } = useService(() => getRequirements())

  const matchPct = analytics && analytics.demandKg > 0
    ? Math.min(100, Math.round((analytics.matchedKg / analytics.demandKg) * 100))
    : 0

  const locationActivity = (() => {
    const map = new Map<string, { name: string; supply: number; demand: number }>()
    for (const l of listings ?? []) {
      const name = placeById(l.farmPlaceId).name
      const row = map.get(name) ?? { name, supply: 0, demand: 0 }
      row.supply += l.remainingKg
      map.set(name, row)
    }
    for (const r of requirements ?? []) {
      if (r.status === 'closed') continue
      const name = placeById(r.pickupPlaceId).name
      const row = map.get(name) ?? { name, supply: 0, demand: 0 }
      row.demand += r.quantityKg - r.matchedKg
      map.set(name, row)
    }
    return [...map.values()].sort((a, b) => b.supply + b.demand - (a.supply + a.demand)).slice(0, 7)
  })()

  const priceVisibility = analytics
    ? [
        { name: 'Farmer receives', value: analytics.avgFarmerPrice },
        { name: 'Transport and platform', value: Math.max(0, Number((analytics.avgBuyerPrice - analytics.avgFarmerPrice).toFixed(2))) },
        { name: 'Reference premium avoided', value: Math.max(0, Number((analytics.avgReferencePrice - analytics.avgBuyerPrice).toFixed(2))) },
      ]
    : []

  return (
    <>
      <PageHeader
        title="Platform analytics"
        subtitle="Demand against supply, match rate, price visibility and where activity is concentrated."
        meta={<Badge tone="harvest">Derived from the seeded demo dataset</Badge>}
      />

      {loading && <SkeletonCards count={4} height="h-32" />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {analytics && (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Total produce listed" value={kg(analytics.listedKg)} hint={`${analytics.activeListings} active listings`} />
            <Stat label="Total demand" value={kg(analytics.demandKg)} hint={`${analytics.openRequirements} open requirements`} />
            <Stat label="Match rate" value={`${matchPct}%`} estimated hint={`${kg(analytics.unmatchedKg)} demand still unmatched`} tone="accent" />
            <Stat label="Estimated transport" value={inr(analytics.transportCost)} estimated hint={`On ${inrShort(analytics.transactionValue)} of transactions`} />
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHead title="Demand against supply by crop" subtitle="Listed supply, open demand and what has been matched." />
              <CardBody>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.byProduct} margin={{ top: 8, right: 8, bottom: 0, left: -14 }}>
                      <CartesianGrid stroke="#EDF5F0" vertical={false} />
                      <XAxis dataKey="name" tick={AXIS} tickLine={false} axisLine={false} />
                      <YAxis tick={AXIS} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={TOOLTIP} formatter={(v: number) => `${v} kg`} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Bar dataKey="listedKg" name="Listed" fill="#2F7658" radius={[6, 6, 0, 0]} />
                      <Bar dataKey="demandKg" name="Demand" fill="#D99B22" radius={[6, 6, 0, 0]} />
                      <Bar dataKey="matchedKg" name="Matched" fill="#9C6644" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHead title="Where each rupee goes" subtitle="Average split of a kilogram against the reference market price." />
              <CardBody>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={priceVisibility} dataKey="value" nameKey="name" innerRadius={58} outerRadius={100} paddingAngle={2}>
                        {priceVisibility.map((entry, i) => (
                          <Cell key={entry.name} fill={['#215C44', '#EDBF69', '#ADD1BC'][i]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={TOOLTIP} formatter={(v: number) => perKg(Number(v))} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHead title="Activity by location" subtitle="Unsold supply against open demand, in kilograms." />
              <CardBody>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={locationActivity} layout="vertical" margin={{ top: 8, right: 16, bottom: 0, left: 24 }}>
                      <CartesianGrid stroke="#EDF5F0" horizontal={false} />
                      <XAxis type="number" tick={AXIS} tickLine={false} axisLine={false} />
                      <YAxis type="category" dataKey="name" tick={AXIS} tickLine={false} axisLine={false} width={90} />
                      <Tooltip contentStyle={TOOLTIP} formatter={(v: number) => `${v} kg`} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Bar dataKey="supply" name="Supply" fill="#2F7658" radius={[0, 6, 6, 0]} />
                      <Bar dataKey="demand" name="Demand" fill="#D99B22" radius={[0, 6, 6, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHead title="Matched volume and value" subtitle="Six-month view of quantity matched and landed value." />
              <CardBody>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={analytics.monthly} margin={{ top: 8, right: 8, bottom: 0, left: -6 }}>
                      <CartesianGrid stroke="#EDF5F0" vertical={false} />
                      <XAxis dataKey="month" tick={AXIS} tickLine={false} axisLine={false} />
                      <YAxis yAxisId="left" tick={AXIS} tickLine={false} axisLine={false} />
                      <YAxis yAxisId="right" orientation="right" tick={AXIS} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={TOOLTIP} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Line yAxisId="left" type="monotone" dataKey="matchedKg" name="Matched (kg)" stroke="#2F7658" strokeWidth={2} dot={false} />
                      <Line yAxisId="right" type="monotone" dataKey="value" name="Value (₹)" stroke="#9C6644" strokeWidth={2} strokeDasharray="5 4" dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHead title="Transport feasibility" subtitle="How much movement direct matching avoids against a four-hop chain." />
              <CardBody className="space-y-3">
                <Meter value={analytics.movementReductionPct} max={100} label={`${analytics.movementReductionPct}% estimated reduction in unnecessary movement`} />
                <p className="text-sm text-ink-soft">
                  Estimated additional transport across live orders is {inr(analytics.transportCost)}, or about{' '}
                  {perKg(analytics.matchedKg ? analytics.transportCost / analytics.matchedKg : 0)} on matched volume.
                </p>
                <p className="text-xs text-ink-mute">
                  Krishik runs no vehicles. These are estimates from the detour model, not fleet telemetry.
                </p>
              </CardBody>
            </Card>

            <Card>
              <CardHead title="Forecast trends" subtitle="Next seven days, by crop." />
              <CardBody>
                <ul className="space-y-2.5">
                  {(forecasts ?? []).map((f) => (
                    <li key={f.productId} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-forest-100 bg-canvas/50 px-3 py-2.5">
                      <span className="font-medium">{f.emoji} {f.productName}</span>
                      <span className="tnum text-sm text-ink-soft">{kg(f.currentDemandKg)} open → {kg(f.predictedDemandKg)} forecast</span>
                      <Badge tone={f.trend === 'up' ? 'forest' : f.trend === 'down' ? 'harvest' : 'neutral'}>
                        {f.trend === 'up' ? 'Increasing' : f.trend === 'down' ? 'Easing' : 'Stable'}
                      </Badge>
                    </li>
                  ))}
                </ul>
                <p className="mt-3 text-xs text-ink-mute">Prototype forecast on seeded data. Not a guarantee.</p>
              </CardBody>
            </Card>
          </div>

          <div className="mt-6">
            <SectionTitle title="Ecosystem totals" />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Stat label="Farmers" value={analytics.farmers} />
              <Stat label="FPOs" value={analytics.fpos} />
              <Stat label="Buyers" value={analytics.buyers} />
              <Stat label="Completed transactions" value={analytics.completedOrders} />
            </div>
          </div>
        </>
      )}
    </>
  )
}
