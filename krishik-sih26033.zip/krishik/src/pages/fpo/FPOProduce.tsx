import { useState } from 'react'
import { Warehouse } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/context/ToastContext'
import { useService } from '@/lib/useService'
import { getListingsBySeller, removeListing, updateListingStatus } from '@/services'
import { placeById, productById } from '@/data/seed'
import { date, inr, kg, perKg } from '@/lib/format'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { DataTable } from '@/components/ui/Table'
import { Badge } from '@/components/ui/Badge'
import { Button, LinkButton } from '@/components/ui/Button'
import { ConfirmDialog } from '@/components/ui/Modal'
import { Meter } from '@/components/ui/Meter'
import { SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState, ErrorState } from '@/components/ui/EmptyState'
import type { Listing } from '@/types'

export function FPOProduce() {
  const { user } = useAuth()
  const { notify } = useToast()
  const fpoId = user?.id ?? ''
  const { data: listings, loading, error, reload } = useService(() => getListingsBySeller(fpoId), [fpoId])
  const [toRemove, setToRemove] = useState<Listing | null>(null)

  const active = (listings ?? []).filter((l) => l.status === 'active')
  const byCrop = Object.values(
    active.reduce<Record<string, { productId: string; quantityKg: number; remainingKg: number; value: number }>>((acc, l) => {
      const row = acc[l.productId] ?? { productId: l.productId, quantityKg: 0, remainingKg: 0, value: 0 }
      row.quantityKg += l.quantityKg
      row.remainingKg += l.remainingKg
      row.value += l.remainingKg * l.pricePerKg
      acc[l.productId] = row
      return acc
    }, {}),
  )

  return (
    <>
      <PageHeader
        title="Aggregated produce"
        subtitle="Member produce pooled into sellable lots, with how much of each crop is still available."
        action={<LinkButton to="/farmer/listings/new"><Warehouse size={16} /> Add produce</LinkButton>}
      />

      {byCrop.length > 0 && (
        <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {byCrop.map((row) => {
            const product = productById(row.productId)
            return (
              <article key={row.productId} className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
                <div className="flex items-center justify-between gap-2">
                  <h2 className="font-display text-lg font-semibold">{product.emoji} {product.name}</h2>
                  <Badge tone="neutral">{kg(row.remainingKg)} left</Badge>
                </div>
                <p className="tnum mt-1 font-display text-2xl font-semibold text-forest-700">{kg(row.quantityKg)}</p>
                <div className="mt-2">
                  <Meter value={row.quantityKg - row.remainingKg} max={row.quantityKg} label={`${inr(row.value)} of stock still unsold`} />
                </div>
              </article>
            )
          })}
        </div>
      )}

      <SectionTitle title="Every lot" hint="Pause a lot to take it off the marketplace without losing its history." />

      {loading && <SkeletonRows count={5} />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {listings && (
        <DataTable
          rows={listings}
          rowKey={(l) => l.id}
          empty={
            <EmptyState
              title="No produce aggregated yet"
              body="Pool member harvests into one lot so bulk and institutional buyers can reach it."
              action={<LinkButton to="/farmer/listings/new" size="sm">Add produce</LinkButton>}
            />
          }
          columns={[
            {
              header: 'Crop',
              cell: (l) => (
                <div className="flex items-center gap-2.5">
                  <span aria-hidden className="text-lg">{productById(l.productId).emoji}</span>
                  <div>
                    <p className="font-medium">{productById(l.productId).name}</p>
                    <p className="text-xs text-ink-mute">Grade {l.grade} · {placeById(l.farmPlaceId).name}</p>
                  </div>
                </div>
              ),
            },
            { header: 'Quantity', align: 'right', cell: (l) => kg(l.quantityKg) },
            {
              header: 'Available',
              cell: (l) => (
                <div className="w-32">
                  <p className="tnum text-sm">{kg(l.remainingKg)}</p>
                  <Meter value={l.quantityKg - l.remainingKg} max={l.quantityKg} />
                </div>
              ),
            },
            { header: 'Expected price', align: 'right', cell: (l) => perKg(l.pricePerKg) },
            { header: 'Available until', hideOnMobile: true, cell: (l) => date(l.availableUntil) },
            {
              header: 'Status',
              cell: (l) => (
                <Badge tone={l.status === 'active' ? 'forest' : l.status === 'sold' ? 'neutral' : 'harvest'}>
                  {l.status === 'reserved' ? 'Paused' : l.status.charAt(0).toUpperCase() + l.status.slice(1)}
                </Badge>
              ),
            },
            {
              header: 'Actions',
              align: 'right',
              cell: (l) => (
                <div className="flex justify-end gap-1.5">
                  {l.status !== 'sold' && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={async () => {
                        const next = l.status === 'active' ? 'reserved' : 'active'
                        await updateListingStatus(l.id, next)
                        notify(next === 'active' ? 'Lot published again' : 'Lot paused')
                      }}
                    >
                      {l.status === 'active' ? 'Pause' : 'Publish'}
                    </Button>
                  )}
                  <Button variant="ghost" size="sm" onClick={() => setToRemove(l)}>Remove</Button>
                </div>
              ),
            },
          ]}
        />
      )}

      <ConfirmDialog
        open={!!toRemove}
        onClose={() => setToRemove(null)}
        onConfirm={async () => {
          if (!toRemove) return
          await removeListing(toRemove.id)
          notify('Lot removed', { body: `${productById(toRemove.productId).name} is no longer visible to buyers.` })
        }}
        title="Remove this lot?"
        body="Buyers stop seeing it immediately. Orders already placed against it stay in your records."
        confirmLabel="Remove lot"
        tone="danger"
      />
    </>
  )
}
