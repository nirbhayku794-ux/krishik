import { useState } from 'react'
import { Check, X } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/context/ToastContext'
import { useService } from '@/lib/useService'
import { buildMatch, createOrder, findUser, getListingsBySeller, getRequirements } from '@/services'
import { placeById, productById } from '@/data/seed'
import { date, kg, perKg, titleCase } from '@/lib/format'
import { PageHeader } from '@/components/ui/PageHeader'
import { Badge, FeasibilityPill } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Meter } from '@/components/ui/Meter'
import { SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState, ErrorState } from '@/components/ui/EmptyState'
import { Modal } from '@/components/ui/Modal'
import { FeasibilityPanel } from '@/components/domain/FeasibilityPanel'

export function FPORequirements() {
  const { user } = useAuth()
  const { notify } = useToast()
  const fpoId = user?.id ?? ''
  const { data: requirements, loading, error, reload } = useService(() => getRequirements())
  const { data: listings } = useService(() => getListingsBySeller(fpoId), [fpoId])
  const [detail, setDetail] = useState<string | null>(null)
  const [busy, setBusy] = useState<string | null>(null)

  const stock = (listings ?? []).filter((l) => l.status === 'active' && l.remainingKg > 0)
  const open = (requirements ?? []).filter((r) => r.status !== 'closed')

  const rowsFor = open.map((requirement) => {
    const lot = stock.find((l) => l.productId === requirement.productId)
    const outstanding = requirement.quantityKg - requirement.matchedKg
    const coverKg = lot ? Math.min(lot.remainingKg, outstanding) : 0
    const match = lot && coverKg > 0 ? buildMatch(lot, requirement, coverKg) : null
    return { requirement, lot, outstanding, coverKg, match }
  })

  const respond = async (requirementId: string, listingId: string, buyerId: string, quantityKg: number) => {
    setBusy(requirementId)
    const order = await createOrder({ listingId, buyerId, quantityKg, requirementId })
    setBusy(null)
    if (!order) {
      notify('Could not respond', { body: 'That quantity is no longer available in your stock.', tone: 'warning' })
      return
    }
    notify('Offer sent to the buyer', {
      body: `${kg(quantityKg)} reserved from your stock. The buyer confirms the final landed price.`,
    })
  }

  const detailRow = rowsFor.find((r) => r.requirement.id === detail)

  return (
    <>
      <PageHeader
        title="Bulk requirements"
        subtitle="Open buyer demand across the platform, with how much of each your current stock can cover."
      />

      {loading && <SkeletonRows count={5} />}
      {error && <ErrorState message={error} onRetry={reload} />}

      {requirements && open.length === 0 && (
        <EmptyState title="No open requirements" body="Buyer requirements appear here as they are posted." />
      )}

      {open.length > 0 && (
        <ul className="space-y-3">
          {rowsFor.map(({ requirement, lot, outstanding, coverKg, match }) => {
            const product = productById(requirement.productId)
            const buyer = findUser(requirement.buyerId) as { name: string; businessName?: string } | undefined
            const priceOk = !!lot && lot.pricePerKg <= requirement.maxPricePerKg
            return (
              <li key={requirement.id} className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <span aria-hidden className="grid h-11 w-11 place-items-center rounded-xl bg-forest-50 text-xl">{product.emoji}</span>
                    <div>
                      <h2 className="font-semibold">{product.name} · {kg(outstanding)}</h2>
                      <p className="text-sm text-ink-mute">
                        {buyer?.businessName ?? buyer?.name ?? 'Buyer'} · {titleCase(requirement.bulkCategory ?? requirement.buyerType)} ·{' '}
                        {placeById(requirement.pickupPlaceId).name}
                      </p>
                      <p className="tnum text-sm text-ink-soft">
                        Ceiling {perKg(requirement.maxPricePerKg)} · needed by {date(requirement.requiredBy)}
                      </p>
                    </div>
                  </div>
                  <Badge tone={requirement.status === 'matched' ? 'forest' : requirement.status === 'partially_matched' ? 'harvest' : 'neutral'}>
                    {titleCase(requirement.status)}
                  </Badge>
                </div>

                <div className="mt-3">
                  <Meter
                    value={Math.min(coverKg, outstanding)}
                    max={Math.max(requirement.quantityKg, 1)}
                    tone={coverKg >= outstanding ? 'forest' : 'harvest'}
                    label={lot
                      ? `Your stock can cover ${kg(coverKg)} of this requirement`
                      : `No ${product.name.toLowerCase()} in your aggregated stock right now`}
                  />
                </div>

                <ul className="mt-3 grid gap-1.5 sm:grid-cols-3">
                  {[
                    { label: 'Crop in stock', ok: !!lot },
                    { label: priceOk ? 'Your price is within the ceiling' : 'Your price is above the ceiling', ok: priceOk },
                    { label: match ? `Transport: +${match.transport.additionalKm} km` : 'Transport not evaluated', ok: !!match && match.transport.status !== 'not-feasible' },
                  ].map((check) => (
                    <li key={check.label} className="flex items-center gap-2 text-sm">
                      <span className={`rounded-full p-0.5 ${check.ok ? 'bg-forest-100 text-forest-700' : 'bg-red-100 text-red-700'}`}>
                        {check.ok ? <Check size={12} /> : <X size={12} />}
                      </span>
                      <span className={check.ok ? 'text-ink-soft' : 'text-red-800'}>{check.label}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-forest-50 pt-3">
                  {match ? <FeasibilityPill status={match.transport.status} /> : <span className="text-sm text-ink-mute">Add this crop to respond</span>}
                  <div className="flex gap-2">
                    {match && <Button variant="secondary" size="sm" onClick={() => setDetail(requirement.id)}>Why this works</Button>}
                    {lot && coverKg > 0 && priceOk && (
                      <Button
                        size="sm"
                        disabled={busy === requirement.id}
                        onClick={() => respond(requirement.id, lot.id, requirement.buyerId, coverKg)}
                      >
                        {busy === requirement.id ? 'Sending…' : `Offer ${kg(coverKg)}`}
                      </Button>
                    )}
                  </div>
                </div>
              </li>
            )
          })}
        </ul>
      )}

      <Modal
        open={!!detailRow?.match}
        onClose={() => setDetail(null)}
        width="max-w-2xl"
        title={detailRow ? `Feasibility for ${productById(detailRow.requirement.productId).name}` : ''}
      >
        {detailRow?.match && detailRow.lot && (
          <FeasibilityPanel
            analysis={detailRow.match.transport}
            stops={[
              { placeId: detailRow.lot.farmPlaceId, label: 'Collection centre', kind: 'farm' },
              { placeId: detailRow.requirement.pickupPlaceId, label: 'Buyer pickup', kind: 'buyer' },
              { placeId: detailRow.lot.preferredSellingPlaceId, label: 'Usual selling point', kind: 'market' },
            ]}
            baselineStops={[
              { placeId: detailRow.lot.farmPlaceId, label: 'Collection centre', kind: 'farm' },
              { placeId: detailRow.lot.preferredSellingPlaceId, label: 'Usual selling point', kind: 'market' },
            ]}
          />
        )}
      </Modal>
    </>
  )
}
