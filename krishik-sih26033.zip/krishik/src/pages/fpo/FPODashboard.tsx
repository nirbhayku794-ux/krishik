import { Boxes, ClipboardList, ListChecks, Scale, Users, Warehouse } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { useService } from '@/lib/useService'
import { getDemandPools, getListingsBySeller, getOrders, getRequirements } from '@/services'
import { placeById, productById } from '@/data/seed'
import { date, inr, kg, perKg } from '@/lib/format'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { Stat } from '@/components/ui/Stat'
import { Badge, OrderStatusPill } from '@/components/ui/Badge'
import { LinkButton } from '@/components/ui/Button'
import { Meter } from '@/components/ui/Meter'
import { SkeletonRows } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'

export function FPODashboard() {
  const { user } = useAuth()
  const fpoId = user?.id ?? ''
  const org = user as { memberCount?: number; villagesCovered?: number; registrationNo?: string } | null

  const { data: listings, loading: loadingListings } = useService(() => getListingsBySeller(fpoId), [fpoId])
  const { data: orders, loading: loadingOrders } = useService(() => getOrders({ sellerId: fpoId }), [fpoId])
  const { data: requirements, loading: loadingReqs } = useService(() => getRequirements())
  const { data: pools } = useService(() => getDemandPools())

  const active = (listings ?? []).filter((l) => l.status === 'active')
  const aggregatedKg = active.reduce((s, l) => s + l.quantityKg, 0)
  const availableKg = active.reduce((s, l) => s + l.remainingKg, 0)
  const live = (orders ?? []).filter((o) => o.status !== 'cancelled')
  const activeOrders = live.filter((o) => o.status !== 'completed')
  const stockedCrops = new Set(active.map((l) => l.productId))

  const relevant = (requirements ?? []).filter((r) => r.status !== 'closed' && stockedCrops.has(r.productId))
  const demandKg = relevant.reduce((s, r) => s + (r.quantityKg - r.matchedKg), 0)
  const matchedKg = live.reduce((s, o) => s + o.quantityKg, 0)
  const unmatchedKg = Math.max(0, demandKg - availableKg)

  const priceSignals = (pools ?? [])
    .filter((p) => stockedCrops.has(p.productId))
    .map((pool) => {
      const listing = active.find((l) => l.productId === pool.productId)
      const reference = productById(pool.productId).referencePricePerKg
      const ceiling = pool.demands.length ? Math.max(...pool.demands.map((d) => d.maxPricePerKg)) : 0
      return { pool, ourPrice: listing?.pricePerKg ?? 0, reference, ceiling }
    })

  return (
    <>
      <PageHeader
        title={user?.name ?? 'FPO workspace'}
        subtitle={org?.registrationNo
          ? `${org.registrationNo} · ${org.memberCount ?? 0} member farmers across ${org.villagesCovered ?? 0} villages`
          : 'Pooled member produce, incoming bulk demand and how much of it your stock can cover.'}
        action={<LinkButton to="/farmer/listings/new"><Warehouse size={16} /> Add aggregated produce</LinkButton>}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Aggregated produce" value={kg(aggregatedKg)} icon={<Scale size={16} />} hint={`${kg(availableKg)} still unsold`} />
        <Stat label="Active listings" value={active.length} icon={<Boxes size={16} />} hint={`${stockedCrops.size} crops in stock`} />
        <Stat label="Buyer demand on your crops" value={kg(demandKg)} icon={<ListChecks size={16} />} hint={`${relevant.length} open requirements`} />
        <Stat label="Active orders" value={activeOrders.length} icon={<ClipboardList size={16} />} hint={`${live.filter((o) => o.status === 'completed').length} completed`} tone="accent" />
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
          <p className="text-sm text-ink-mute">Demand your stock can cover</p>
          <p className="tnum mt-1 font-display text-2xl font-semibold text-forest-700">{kg(Math.min(demandKg, availableKg))}</p>
          <div className="mt-3">
            <Meter value={Math.min(demandKg, availableKg)} max={Math.max(demandKg, 1)} label={`${kg(unmatchedKg)} of nearby demand is beyond current stock`} />
          </div>
        </div>
        <div className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
          <p className="text-sm text-ink-mute">Quantity already matched to orders</p>
          <p className="tnum mt-1 font-display text-2xl font-semibold">{kg(matchedKg)}</p>
          <p className="mt-1 text-xs text-ink-mute">
            <span className="mr-1 rounded bg-canvas px-1.5 py-0.5 text-[11px] text-ink-soft">estimated</span>
            {inr(live.reduce((s, o) => s + o.pricePerKg * o.quantityKg, 0))} to member farmers at listed prices
          </p>
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.15fr_1fr]">
        <section>
          <SectionTitle
            title="Price signals"
            hint="Your listed price against the reference mandi price and what buyers are willing to pay."
            action={<Link to="/fpo/analytics" className="text-sm font-medium text-forest-700 hover:underline">Analytics</Link>}
          />
          {priceSignals.length === 0 && (
            <EmptyState title="No crops listed yet" body="Add aggregated produce and price comparisons will appear here." />
          )}
          <div className="grid gap-3">
            {priceSignals.map(({ pool, ourPrice, reference, ceiling }) => (
              <article key={pool.productId} className="rounded-2xl border border-forest-100 bg-white p-4 shadow-card">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="font-display text-lg font-semibold">{pool.emoji} {pool.productName}</h3>
                  <Badge tone={ourPrice && ourPrice < reference ? 'forest' : 'harvest'}>
                    {ourPrice && ourPrice < reference ? 'Below reference price' : 'At or above reference'}
                  </Badge>
                </div>
                <dl className="tnum mt-3 grid grid-cols-3 gap-3 text-sm">
                  <div><dt className="text-xs text-ink-mute">Your price</dt><dd className="font-semibold">{perKg(ourPrice)}</dd></div>
                  <div><dt className="text-xs text-ink-mute">Reference (demo)</dt><dd className="font-semibold">{perKg(reference)}</dd></div>
                  <div><dt className="text-xs text-ink-mute">Buyer ceiling</dt><dd className="font-semibold">{ceiling ? perKg(ceiling) : '—'}</dd></div>
                </dl>
                <p className="mt-2 text-sm text-ink-soft">
                  {kg(pool.demandKg)} pooled demand against {kg(pool.supplyKg)} listed supply across the platform.
                </p>
              </article>
            ))}
          </div>
        </section>

        <section>
          <SectionTitle title="Recent activity" action={<Link to="/farmer/orders" className="text-sm font-medium text-forest-700 hover:underline">All orders</Link>} />
          {(loadingOrders || loadingListings || loadingReqs) && <SkeletonRows count={4} />}
          {orders && orders.length === 0 && (
            <EmptyState title="No orders yet" body="Bulk buyers reaching your stock will appear here for acceptance." />
          )}
          {orders && orders.length > 0 && (
            <ul className="space-y-2">
              {orders.slice(0, 5).map((order) => (
                <li key={order.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-forest-100 bg-white px-4 py-3 shadow-card">
                  <div>
                    <p className="font-medium">{productById(order.productId).emoji} {productById(order.productId).name} · {kg(order.quantityKg)}</p>
                    <p className="tnum text-sm text-ink-mute">{inr(order.pricePerKg * order.quantityKg)} · {date(order.createdAt)}</p>
                  </div>
                  <OrderStatusPill status={order.status} />
                </li>
              ))}
            </ul>
          )}

          <div className="mt-4">
            <SectionTitle title="Open bulk requirements" action={<Link to="/fpo/requirements" className="text-sm font-medium text-forest-700 hover:underline">Respond</Link>} />
            {relevant.length === 0 ? (
              <EmptyState title="No demand on your crops yet" body="Requirements matching the crops you stock will be listed here." icon={<Users size={20} />} />
            ) : (
              <ul className="space-y-2">
                {relevant.slice(0, 4).map((r) => (
                  <li key={r.id} className="rounded-xl border border-forest-100 bg-white px-4 py-3 shadow-card">
                    <p className="font-medium">{productById(r.productId).name} · {kg(r.quantityKg - r.matchedKg)}</p>
                    <p className="tnum text-sm text-ink-mute">
                      up to {perKg(r.maxPricePerKg)} · {placeById(r.pickupPlaceId).name} · by {date(r.requiredBy)}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      </div>

      {!loadingListings && active.length === 0 && (
        <div className="mt-8">
          <EmptyState
            title="No aggregated produce listed"
            body="Pool member produce into a single listing so institutional and wholesale requirements become reachable."
            action={<LinkButton to="/farmer/listings/new" size="sm">Add produce</LinkButton>}
          />
        </div>
      )}
    </>
  )
}
