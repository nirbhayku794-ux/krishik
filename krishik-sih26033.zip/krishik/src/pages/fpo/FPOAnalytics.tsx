import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useAuth } from '@/context/AuthContext'
import { useService } from '@/lib/useService'
import { getDemandForecast, getListingsBySeller, getPlatformAnalytics } from '@/services'
import { kg, perKg } from '@/lib/format'
import { PageHeader, SectionTitle } from '@/components/ui/PageHeader'
import { Badge } from '@/components/ui/Badge'
import { Stat } from '@/components/ui/Stat'
import { SkeletonCards } from '@/components/ui/Skeleton'
import { Card, CardBody, CardHead } from '@/components/ui/Card'

const AXIS = { fontSize: 11, fill: '#6B7C74' }
const TOOLTIP = { borderRadius: 12, border: '1px solid #D6E8DD', fontSize: 12 }

export function FPOAnalytics() {
  const { user } = useAuth()
  const fpoId = user?.id ?? ''
  const org = user as { memberCount?: number; villagesCovered?: number } | null
  const { data: analytics, loading } = useService(() => getPlatformAnalytics())
  const { data: forecasts } = useService(() => getDemandForecast(7))
  const { data: listings } = useService(() => getListingsBySeller(fpoId), [fpoId])

  const active = (listings ?? []).filter((l) => l.status === 'active')
  const ourKg = active.reduce((s, l) => s + l.quantityKg, 0)

  const supplyDemand = (analytics?.byProduct ?? []).map((row) => ({
    name: row.name,
    supply: row.listedKg,
    demand: row.demandKg,
    matched: row.matchedKg,
  }))

  const matchSplit = analytics
    ? [
        { name: 'Matched demand', value: Math.round(Math.min(analytics.matchedKg, analytics.demandKg)) },
        { name: 'Unmatched demand', value: Math.round(analytics.unmatchedKg) },
      ]
    : []

  const priceTrend = (analytics?.monthly ?? []).map((m) => ({
    month: m.month,
    farmerPrice: Number((analytics!.avgFarmerPrice * (0.92 + (m.matchedKg % 17) / 100)).toFixed(2)),
    buyerPrice: Number((analytics!.avgBuyerPrice * (0.94 + (m.matchedKg % 13) / 100)).toFixed(2)),
    reference: analytics!.avgReferencePrice,
  }))

  return (
    <>
      <PageHeader
        title="FPO analytics"
        subtitle="Where your pooled supply sits against platform demand, and which crops are worth aggregating next."
        meta={<Badge tone="harvest">Figures derived from the seeded demo dataset</Badge>}
      />

      {loading && <SkeletonCards count={4} height="h-32" />}

      {analytics && (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Your aggregated supply" value={kg(ourKg)} hint={`${active.length} active lots`} />
            <Stat label="Platform demand" value={kg(analytics.demandKg)} hint={`${analytics.openRequirements} open requirements`} />
            <Stat label="Matched demand" value={kg(analytics.matchedKg)} hint={`${kg(analytics.unmatchedKg)} still unmatched`} tone="accent" />
            <Stat label="Member farmers" value={org?.memberCount ?? 0} hint={`${org?.villagesCovered ?? 0} villages covered`} />
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHead title="Supply and demand by crop" subtitle="Listed supply against open buyer demand, in kilograms." />
              <CardBody>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={supplyDemand} margin={{ top: 8, right: 8, bottom: 0, left: -14 }}>
                      <CartesianGrid stroke="#EDF5F0" vertical={false} />
                      <XAxis dataKey="name" tick={AXIS} tickLine={false} axisLine={false} />
                      <YAxis tick={AXIS} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={TOOLTIP} formatter={(v: number) => `${v} kg`} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Bar dataKey="supply" name="Listed supply" fill="#2F7658" radius={[6, 6, 0, 0]} />
                      <Bar dataKey="demand" name="Buyer demand" fill="#D99B22" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHead title="Matched against unmatched demand" subtitle="How much open demand current supply can actually cover." />
              <CardBody>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={matchSplit} dataKey="value" nameKey="name" innerRadius={60} outerRadius={100} paddingAngle={2}>
                        {matchSplit.map((entry, i) => (
                          <Cell key={entry.name} fill={i === 0 ? '#2F7658' : '#EDBF69'} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={TOOLTIP} formatter={(v: number) => `${v} kg`} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHead title="Price trend" subtitle="Average farmer price and buyer landed price against the reference mandi price." />
              <CardBody>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={priceTrend} margin={{ top: 8, right: 8, bottom: 0, left: -14 }}>
                      <CartesianGrid stroke="#EDF5F0" vertical={false} />
                      <XAxis dataKey="month" tick={AXIS} tickLine={false} axisLine={false} />
                      <YAxis tick={AXIS} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={TOOLTIP} formatter={(v: number) => perKg(Number(v))} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Line type="monotone" dataKey="farmerPrice" name="Farmer price" stroke="#2F7658" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="buyerPrice" name="Buyer landed price" stroke="#9C6644" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="reference" name="Reference (demo)" stroke="#D99B22" strokeWidth={1.5} strokeDasharray="5 4" dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHead title="Forecast signals" subtitle="Where next week's demand is expected to outrun listed supply." />
              <CardBody>
                <ul className="space-y-2.5">
                  {(forecasts ?? []).map((f) => {
                    const gap = f.predictedDemandKg - f.currentSupplyKg
                    return (
                      <li key={f.productId} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-forest-100 bg-canvas/50 px-3 py-2.5">
                        <span className="font-medium">{f.emoji} {f.productName}</span>
                        <span className="tnum text-sm text-ink-soft">
                          {kg(f.predictedDemandKg)} forecast · {kg(f.currentSupplyKg)} listed
                        </span>
                        <Badge tone={gap > 150 ? 'forest' : gap > 0 ? 'harvest' : 'neutral'}>
                          {gap > 0 ? `${kg(gap)} short` : 'Covered'}
                        </Badge>
                      </li>
                    )
                  })}
                </ul>
                <p className="mt-3 text-xs text-ink-mute">Prototype forecast on seeded data. Not a guarantee of demand.</p>
              </CardBody>
            </Card>
          </div>

          <div className="mt-6">
            <SectionTitle title="Farmer participation" hint="Member farms and how their produce reaches buyers." />
            <div className="grid gap-4 sm:grid-cols-3">
              <Stat label="Member farmers" value={org?.memberCount ?? 0} />
              <Stat label="Villages covered" value={org?.villagesCovered ?? 0} />
              <Stat label="Crops aggregated" value={new Set(active.map((l) => l.productId)).size} />
            </div>
          </div>
        </>
      )}
    </>
  )
}
