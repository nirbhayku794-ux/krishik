/** Formatting helpers — INR, kilograms, Indian dates. */

export const inr = (value: number, opts: { decimals?: number } = {}) => {
  const decimals = opts.decimals ?? (Number.isInteger(value) ? 0 : 2)
  return '₹' + value.toLocaleString('en-IN', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })
}

export const perKg = (value: number) => `₹${round(value, 2).toLocaleString('en-IN', { minimumFractionDigits: value % 1 === 0 ? 0 : 2, maximumFractionDigits: 2 })}/kg`

export const kg = (value: number) => `${Math.round(value).toLocaleString('en-IN')} kg`

/** ₹2.4L / ₹1.2Cr style short form for dashboard tiles. */
export const inrShort = (value: number) => {
  if (value >= 1e7) return `₹${round(value / 1e7, 2)}Cr`
  if (value >= 1e5) return `₹${round(value / 1e5, 2)}L`
  if (value >= 1e3) return `₹${round(value / 1e3, 1)}K`
  return inr(value)
}

export const round = (value: number, decimals = 2) => {
  const f = Math.pow(10, decimals)
  return Math.round(value * f) / f
}

/** 25 Sept 2026 — the format Indian users read fastest. */
export const date = (isoString: string) =>
  new Date(isoString).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })

export const dateShort = (isoString: string) =>
  new Date(isoString).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })

export const relativeDays = (isoString: string) => {
  const diff = Math.round((new Date(isoString).getTime() - Date.now()) / 86_400_000)
  if (diff === 0) return 'today'
  if (diff === 1) return 'tomorrow'
  if (diff === -1) return 'yesterday'
  return diff > 0 ? `in ${diff} days` : `${Math.abs(diff)} days ago`
}

export const initials = (name: string) =>
  name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase()

export const titleCase = (value: string) => value.charAt(0).toUpperCase() + value.slice(1).replace(/_/g, ' ')
