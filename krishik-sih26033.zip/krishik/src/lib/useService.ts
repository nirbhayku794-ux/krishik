import { useCallback, useEffect, useState, useSyncExternalStore } from 'react'
import { getVersion, subscribe } from '@/services/store'

/** Re-renders whenever any service mutates the store. */
export const useStoreVersion = () => useSyncExternalStore(subscribe, getVersion, getVersion)

interface State<T> { data: T | null; loading: boolean; error: string | null }

/**
 * Runs an async service function, tracks loading/error state, and re-runs
 * whenever the store changes or a dependency changes.
 */
export function useService<T>(fn: () => Promise<T>, deps: unknown[] = []): State<T> & { reload: () => void } {
  const version = useStoreVersion()
  const [state, setState] = useState<State<T>>({ data: null, loading: true, error: null })
  const [nonce, setNonce] = useState(0)

  useEffect(() => {
    let cancelled = false
    setState((s) => ({ ...s, loading: true }))
    fn()
      .then((data) => !cancelled && setState({ data, loading: false, error: null }))
      .catch((e) => !cancelled && setState({ data: null, loading: false, error: e?.message ?? 'Something went wrong' }))
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [version, nonce, ...deps])

  const reload = useCallback(() => setNonce((n) => n + 1), [])
  return { ...state, reload }
}
