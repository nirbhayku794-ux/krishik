import { placeById } from '@/data/seed'

/** Straight-line distance in km between two coordinates. */
export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371
  const toRad = (d: number) => (d * Math.PI) / 180
  const dLat = toRad(b.lat - a.lat)
  const dLng = toRad(b.lng - a.lng)
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(s))
}

/**
 * Road distance estimate. Straight-line distance understates real travel, so
 * we apply a 1.25 detour factor — the usual planning rule of thumb for rural
 * road networks. Deterministic, no map API needed.
 */
export function roadKm(fromPlaceId: string, toPlaceId: string) {
  if (fromPlaceId === toPlaceId) return 0
  const km = haversineKm(placeById(fromPlaceId), placeById(toPlaceId)) * 1.25
  return Math.round(km * 10) / 10
}

/** Normalised 0–1 position of a place inside the demo bounding box, for the mock map. */
export function projectPlace(placeId: string) {
  const p = placeById(placeId)
  const bounds = { minLat: 25.25, maxLat: 25.70, minLng: 82.90, maxLng: 85.20 }
  return {
    x: (p.lng - bounds.minLng) / (bounds.maxLng - bounds.minLng),
    y: 1 - (p.lat - bounds.minLat) / (bounds.maxLat - bounds.minLat),
  }
}
