import type {
  Admin, Buyer, FPO, Farmer, Listing, Order, Place, Product, Requirement,
} from '@/types'

/* Every date in the demo dataset is expressed relative to this anchor so the
   prototype never looks stale, and the seed stays deterministic. */
export const TODAY = new Date()
export const iso = (offsetDays: number) => {
  const d = new Date(TODAY)
  d.setDate(d.getDate() + offsetDays)
  d.setHours(9, 0, 0, 0)
  return d.toISOString()
}

/* ----------------------------- Places ----------------------------- */
export const places: Place[] = [
  { id: 'p_buxar', name: 'Buxar', district: 'Buxar', state: 'Bihar', lat: 25.5647, lng: 83.9784 },
  { id: 'p_buxar_mandi', name: 'Buxar Krishi Mandi', district: 'Buxar', state: 'Bihar', lat: 25.5742, lng: 83.9931 },
  { id: 'p_dumraon', name: 'Dumraon', district: 'Buxar', state: 'Bihar', lat: 25.5527, lng: 84.1514 },
  { id: 'p_chausa', name: 'Chausa', district: 'Buxar', state: 'Bihar', lat: 25.5150, lng: 83.8890 },
  { id: 'p_itarhi', name: 'Itarhi', district: 'Buxar', state: 'Bihar', lat: 25.4180, lng: 84.0860 },
  { id: 'p_ara', name: 'Ara', district: 'Bhojpur', state: 'Bihar', lat: 25.5541, lng: 84.6630 },
  { id: 'p_ara_mandi', name: 'Ara Subzi Mandi', district: 'Bhojpur', state: 'Bihar', lat: 25.5608, lng: 84.6702 },
  { id: 'p_bihiya', name: 'Bihiya', district: 'Bhojpur', state: 'Bihar', lat: 25.5490, lng: 84.4900 },
  { id: 'p_patna', name: 'Patna', district: 'Patna', state: 'Bihar', lat: 25.5941, lng: 85.1376 },
  { id: 'p_danapur', name: 'Danapur', district: 'Patna', state: 'Bihar', lat: 25.6360, lng: 85.0470 },
  { id: 'p_varanasi', name: 'Varanasi', district: 'Varanasi', state: 'Uttar Pradesh', lat: 25.3176, lng: 82.9739 },
  { id: 'p_mughalsarai', name: 'Pandit Deen Dayal Upadhyaya Nagar', district: 'Chandauli', state: 'Uttar Pradesh', lat: 25.2820, lng: 83.1190 },
]

export const placeById = (id: string) => places.find((p) => p.id === id) ?? places[0]

/* ---------------------------- Products ---------------------------- */
/* seasonality[m] multiplies baseline demand for month m (0 = January). */
export const products: Product[] = [
  { id: 'pr_tomato', name: 'Tomato', category: 'vegetable', emoji: '🍅', referencePricePerKg: 24, seasonality: [1.1, 1.05, 1, 0.95, 0.9, 0.95, 1.15, 1.25, 1.3, 1.2, 1.1, 1.05] },
  { id: 'pr_potato', name: 'Potato', category: 'vegetable', emoji: '🥔', referencePricePerKg: 18, seasonality: [0.95, 0.9, 0.95, 1, 1.05, 1.1, 1.15, 1.1, 1.05, 1, 0.95, 0.9] },
  { id: 'pr_onion', name: 'Onion', category: 'vegetable', emoji: '🧅', referencePricePerKg: 28, seasonality: [1, 0.95, 0.9, 0.95, 1.05, 1.15, 1.2, 1.25, 1.2, 1.1, 1.05, 1] },
  { id: 'pr_cauliflower', name: 'Cauliflower', category: 'vegetable', emoji: '🥬', referencePricePerKg: 22, seasonality: [1.2, 1.1, 0.95, 0.85, 0.8, 0.85, 0.95, 1.05, 1.15, 1.25, 1.3, 1.25] },
  { id: 'pr_wheat', name: 'Wheat', category: 'grain', emoji: '🌾', referencePricePerKg: 26, seasonality: [1, 1.05, 1.15, 1.2, 1.1, 1, 0.95, 0.95, 1, 1.05, 1.05, 1] },
  { id: 'pr_rice', name: 'Rice', category: 'grain', emoji: '🍚', referencePricePerKg: 34, seasonality: [1.05, 1, 0.95, 0.95, 1, 1.05, 1.1, 1.1, 1.05, 1.15, 1.2, 1.1] },
]

export const productById = (id: string) => products.find((p) => p.id === id) ?? products[0]

/* ----------------------------- Farmers ---------------------------- */
export const farmers: Farmer[] = [
  { id: 'u_f1', role: 'farmer', name: 'Ravi Kumar', email: 'farmer@krishik.demo', phone: '+91 90000 11001', placeId: 'p_buxar', verified: true, joinedOn: iso(-210), farmSizeAcres: 4.5, fpoId: 'u_fpo1', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 10, vehicleAccess: 'own-pickup', rating: 4.7 },
  { id: 'u_f2', role: 'farmer', name: 'Amit Singh', email: 'amit.singh@krishik.demo', phone: '+91 90000 11002', placeId: 'p_dumraon', verified: true, joinedOn: iso(-180), farmSizeAcres: 3.2, fpoId: 'u_fpo1', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 15, vehicleAccess: 'hired', rating: 4.4 },
  { id: 'u_f3', role: 'farmer', name: 'Sanjay Yadav', email: 'sanjay.yadav@krishik.demo', phone: '+91 90000 11003', placeId: 'p_chausa', verified: true, joinedOn: iso(-150), farmSizeAcres: 6, preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 12, vehicleAccess: 'own-two-wheeler', rating: 4.2 },
  { id: 'u_f4', role: 'farmer', name: 'Pooja Devi', email: 'pooja.devi@krishik.demo', phone: '+91 90000 11004', placeId: 'p_itarhi', verified: true, joinedOn: iso(-120), farmSizeAcres: 2.4, fpoId: 'u_fpo1', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 8, vehicleAccess: 'none', rating: 4.8 },
  { id: 'u_f5', role: 'farmer', name: 'Manoj Prasad', email: 'manoj.prasad@krishik.demo', phone: '+91 90000 11005', placeId: 'p_bihiya', verified: false, joinedOn: iso(-64), farmSizeAcres: 5.1, preferredSellingPlaceId: 'p_ara_mandi', maxAdditionalKm: 20, vehicleAccess: 'hired', rating: 4.1 },
  { id: 'u_f6', role: 'farmer', name: 'Rekha Kumari', email: 'rekha.kumari@krishik.demo', phone: '+91 90000 11006', placeId: 'p_ara', verified: true, joinedOn: iso(-95), farmSizeAcres: 3.8, preferredSellingPlaceId: 'p_ara_mandi', maxAdditionalKm: 14, vehicleAccess: 'own-pickup', rating: 4.5 },
  { id: 'u_f7', role: 'farmer', name: 'Dinesh Rai', email: 'dinesh.rai@krishik.demo', phone: '+91 90000 11007', placeId: 'p_mughalsarai', verified: true, joinedOn: iso(-88), farmSizeAcres: 7.2, preferredSellingPlaceId: 'p_varanasi', maxAdditionalKm: 18, vehicleAccess: 'hired', rating: 4.3 },
  { id: 'u_f8', role: 'farmer', name: 'Shanti Devi', email: 'shanti.devi@krishik.demo', phone: '+91 90000 11008', placeId: 'p_danapur', verified: false, joinedOn: iso(-40), farmSizeAcres: 1.9, preferredSellingPlaceId: 'p_patna', maxAdditionalKm: 10, vehicleAccess: 'none', rating: 4.0 },
]

/* ------------------------------- FPOs ------------------------------ */
export const fpos: FPO[] = [
  { id: 'u_fpo1', role: 'fpo', name: 'Buxar Vegetable Producers FPO', email: 'fpo@krishik.demo', phone: '+91 90000 22001', placeId: 'p_buxar', verified: true, joinedOn: iso(-300), registrationNo: 'FPO/BR/2021/0148', memberCount: 212, villagesCovered: 14, preferredSellingPlaceId: 'p_buxar_mandi' },
  { id: 'u_fpo2', role: 'fpo', name: 'Bhojpur Kisan Producer Company', email: 'fpo2@krishik.demo', phone: '+91 90000 22002', placeId: 'p_ara', verified: true, joinedOn: iso(-240), registrationNo: 'FPO/BR/2022/0311', memberCount: 158, villagesCovered: 9, preferredSellingPlaceId: 'p_ara_mandi' },
]

/* ------------------------------ Buyers ----------------------------- */
export const buyers: Buyer[] = [
  { id: 'u_b1', role: 'buyer', name: 'Neha Verma', email: 'buyer@krishik.demo', phone: '+91 90000 33001', placeId: 'p_buxar', verified: true, joinedOn: iso(-100), buyerType: 'bulk', bulkCategory: 'restaurant', businessName: 'Annapurna Restaurant', monthlyVolumeKg: 2400 },
  { id: 'u_b2', role: 'buyer', name: 'Imran Khan', email: 'imran@krishik.demo', phone: '+91 90000 33002', placeId: 'p_buxar', verified: true, joinedOn: iso(-88), buyerType: 'bulk', bulkCategory: 'retailer', businessName: 'Sabzi Point Retail', monthlyVolumeKg: 5200 },
  { id: 'u_b3', role: 'buyer', name: 'Warden, Gyan Bharti Hostel', email: 'hostel@krishik.demo', phone: '+91 90000 33003', placeId: 'p_dumraon', verified: true, joinedOn: iso(-70), buyerType: 'bulk', bulkCategory: 'hostel', businessName: 'Gyan Bharti Hostel', monthlyVolumeKg: 3100 },
  { id: 'u_b4', role: 'buyer', name: 'Ajay Gupta', email: 'ajay@krishik.demo', phone: '+91 90000 33004', placeId: 'p_ara', verified: false, joinedOn: iso(-52), buyerType: 'bulk', bulkCategory: 'canteen', businessName: 'Bhojpur College Canteen', monthlyVolumeKg: 1800 },
  { id: 'u_b5', role: 'buyer', name: 'Kavita Sharma', email: 'kavita@krishik.demo', phone: '+91 90000 33005', placeId: 'p_buxar', verified: true, joinedOn: iso(-33), buyerType: 'individual', monthlyVolumeKg: 40 },
  { id: 'u_b6', role: 'buyer', name: 'Rohit Anand', email: 'rohit@krishik.demo', phone: '+91 90000 33006', placeId: 'p_patna', verified: true, joinedOn: iso(-28), buyerType: 'bulk', bulkCategory: 'business', businessName: 'FreshCart Patna', monthlyVolumeKg: 8600 },
  { id: 'u_b7', role: 'buyer', name: 'Sunita Rani', email: 'sunita@krishik.demo', phone: '+91 90000 33007', placeId: 'p_varanasi', verified: true, joinedOn: iso(-21), buyerType: 'bulk', bulkCategory: 'institution', businessName: 'Kashi Seva Bhojanalaya', monthlyVolumeKg: 4200 },
  { id: 'u_b8', role: 'buyer', name: 'Deepak Mishra', email: 'deepak@krishik.demo', phone: '+91 90000 33008', placeId: 'p_chausa', verified: false, joinedOn: iso(-12), buyerType: 'individual', monthlyVolumeKg: 25 },
]

export const admins: Admin[] = [
  { id: 'u_a1', role: 'admin', name: 'Krishik Operations', email: 'admin@krishik.demo', phone: '+91 90000 44001', placeId: 'p_patna', verified: true, joinedOn: iso(-365) },
]

/* ----------------------------- Listings ---------------------------- */
export const listings: Listing[] = [
  { id: 'l_01', sellerId: 'u_f1', sellerRole: 'farmer', productId: 'pr_tomato', quantityKg: 500, remainingKg: 500, pricePerKg: 20, unit: 'kg', grade: 'A', harvestDate: iso(-1), availableFrom: iso(0), availableUntil: iso(6), farmPlaceId: 'p_buxar', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 10, note: 'Hand-picked, sorted same day.', createdAt: iso(-1), status: 'active' },
  { id: 'l_02', sellerId: 'u_f2', sellerRole: 'farmer', productId: 'pr_tomato', quantityKg: 320, remainingKg: 320, pricePerKg: 21, unit: 'kg', grade: 'A', harvestDate: iso(-2), availableFrom: iso(0), availableUntil: iso(5), farmPlaceId: 'p_dumraon', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 15, createdAt: iso(-2), status: 'active' },
  { id: 'l_03', sellerId: 'u_f3', sellerRole: 'farmer', productId: 'pr_tomato', quantityKg: 260, remainingKg: 180, pricePerKg: 20, unit: 'kg', grade: 'B', harvestDate: iso(-3), availableFrom: iso(0), availableUntil: iso(4), farmPlaceId: 'p_chausa', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 12, createdAt: iso(-3), status: 'active' },
  { id: 'l_04', sellerId: 'u_f4', sellerRole: 'farmer', productId: 'pr_potato', quantityKg: 900, remainingKg: 900, pricePerKg: 14, unit: 'kg', grade: 'A', harvestDate: iso(-6), availableFrom: iso(0), availableUntil: iso(20), farmPlaceId: 'p_itarhi', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 8, note: 'Stored in cold room, graded.', createdAt: iso(-5), status: 'active' },
  { id: 'l_05', sellerId: 'u_f6', sellerRole: 'farmer', productId: 'pr_potato', quantityKg: 640, remainingKg: 640, pricePerKg: 15, unit: 'kg', grade: 'B', harvestDate: iso(-7), availableFrom: iso(0), availableUntil: iso(18), farmPlaceId: 'p_ara', preferredSellingPlaceId: 'p_ara_mandi', maxAdditionalKm: 14, createdAt: iso(-6), status: 'active' },
  { id: 'l_06', sellerId: 'u_f5', sellerRole: 'farmer', productId: 'pr_onion', quantityKg: 780, remainingKg: 780, pricePerKg: 23, unit: 'kg', grade: 'A', harvestDate: iso(-9), availableFrom: iso(0), availableUntil: iso(25), farmPlaceId: 'p_bihiya', preferredSellingPlaceId: 'p_ara_mandi', maxAdditionalKm: 20, createdAt: iso(-8), status: 'active' },
  { id: 'l_07', sellerId: 'u_f7', sellerRole: 'farmer', productId: 'pr_onion', quantityKg: 1200, remainingKg: 1050, pricePerKg: 22, unit: 'kg', grade: 'A', harvestDate: iso(-10), availableFrom: iso(0), availableUntil: iso(30), farmPlaceId: 'p_mughalsarai', preferredSellingPlaceId: 'p_varanasi', maxAdditionalKm: 18, createdAt: iso(-9), status: 'active' },
  { id: 'l_08', sellerId: 'u_f3', sellerRole: 'farmer', productId: 'pr_cauliflower', quantityKg: 400, remainingKg: 400, pricePerKg: 17, unit: 'kg', grade: 'A', harvestDate: iso(-1), availableFrom: iso(0), availableUntil: iso(4), farmPlaceId: 'p_chausa', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 12, createdAt: iso(-1), status: 'active' },
  { id: 'l_09', sellerId: 'u_f1', sellerRole: 'farmer', productId: 'pr_cauliflower', quantityKg: 280, remainingKg: 280, pricePerKg: 18, unit: 'kg', grade: 'B', harvestDate: iso(-2), availableFrom: iso(1), availableUntil: iso(7), farmPlaceId: 'p_buxar', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 10, createdAt: iso(-2), status: 'active' },
  { id: 'l_10', sellerId: 'u_fpo1', sellerRole: 'fpo', productId: 'pr_tomato', quantityKg: 2500, remainingKg: 2300, pricePerKg: 19.5, unit: 'kg', grade: 'A', harvestDate: iso(-2), availableFrom: iso(0), availableUntil: iso(8), farmPlaceId: 'p_buxar', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 25, note: 'Aggregated from 38 member farms.', createdAt: iso(-2), status: 'active' },
  { id: 'l_11', sellerId: 'u_fpo1', sellerRole: 'fpo', productId: 'pr_potato', quantityKg: 1800, remainingKg: 1800, pricePerKg: 13.5, unit: 'kg', grade: 'A', harvestDate: iso(-8), availableFrom: iso(0), availableUntil: iso(28), farmPlaceId: 'p_buxar', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 25, createdAt: iso(-7), status: 'active' },
  { id: 'l_12', sellerId: 'u_fpo1', sellerRole: 'fpo', productId: 'pr_onion', quantityKg: 1200, remainingKg: 1200, pricePerKg: 21.5, unit: 'kg', grade: 'A', harvestDate: iso(-12), availableFrom: iso(0), availableUntil: iso(32), farmPlaceId: 'p_buxar', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 25, createdAt: iso(-11), status: 'active' },
  { id: 'l_13', sellerId: 'u_fpo2', sellerRole: 'fpo', productId: 'pr_wheat', quantityKg: 4200, remainingKg: 4200, pricePerKg: 23, unit: 'kg', grade: 'A', harvestDate: iso(-40), availableFrom: iso(0), availableUntil: iso(60), farmPlaceId: 'p_ara', preferredSellingPlaceId: 'p_ara_mandi', maxAdditionalKm: 30, createdAt: iso(-30), status: 'active' },
  { id: 'l_14', sellerId: 'u_f8', sellerRole: 'farmer', productId: 'pr_rice', quantityKg: 1500, remainingKg: 1500, pricePerKg: 30, unit: 'kg', grade: 'A', harvestDate: iso(-25), availableFrom: iso(0), availableUntil: iso(45), farmPlaceId: 'p_danapur', preferredSellingPlaceId: 'p_patna', maxAdditionalKm: 10, createdAt: iso(-20), status: 'active' },
  { id: 'l_15', sellerId: 'u_f6', sellerRole: 'farmer', productId: 'pr_wheat', quantityKg: 900, remainingKg: 900, pricePerKg: 24, unit: 'kg', grade: 'B', harvestDate: iso(-45), availableFrom: iso(0), availableUntil: iso(50), farmPlaceId: 'p_ara', preferredSellingPlaceId: 'p_ara_mandi', maxAdditionalKm: 14, createdAt: iso(-22), status: 'active' },
  { id: 'l_17', sellerId: 'u_f8', sellerRole: 'farmer', productId: 'pr_rice', quantityKg: 800, remainingKg: 800, pricePerKg: 33, unit: 'kg', grade: 'B', harvestDate: iso(-28), availableFrom: iso(0), availableUntil: iso(40), farmPlaceId: 'p_danapur', preferredSellingPlaceId: 'p_patna', maxAdditionalKm: 10, note: 'Late-season lot, priced close to the mandi rate.', createdAt: iso(-18), status: 'active' },
  { id: 'l_16', sellerId: 'u_f4', sellerRole: 'farmer', productId: 'pr_tomato', quantityKg: 180, remainingKg: 0, pricePerKg: 19, unit: 'kg', grade: 'B', harvestDate: iso(-14), availableFrom: iso(-14), availableUntil: iso(-8), farmPlaceId: 'p_itarhi', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 8, createdAt: iso(-14), status: 'sold' },
]

/* --------------------------- Requirements -------------------------- */
export const requirements: Requirement[] = [
  { id: 'r_01', buyerId: 'u_b1', productId: 'pr_tomato', quantityKg: 300, maxPricePerKg: 22, requiredBy: iso(4), buyerPlaceId: 'p_buxar', pickupPlaceId: 'p_buxar', buyerType: 'bulk', bulkCategory: 'restaurant', createdAt: iso(-1), status: 'open', matchedKg: 0 },
  { id: 'r_02', buyerId: 'u_b2', productId: 'pr_tomato', quantityKg: 200, maxPricePerKg: 21.5, requiredBy: iso(3), buyerPlaceId: 'p_buxar', pickupPlaceId: 'p_buxar_mandi', buyerType: 'bulk', bulkCategory: 'retailer', createdAt: iso(-1), status: 'open', matchedKg: 0 },
  { id: 'r_03', buyerId: 'u_b3', productId: 'pr_tomato', quantityKg: 150, maxPricePerKg: 23, requiredBy: iso(5), buyerPlaceId: 'p_dumraon', pickupPlaceId: 'p_dumraon', buyerType: 'bulk', bulkCategory: 'hostel', createdAt: iso(-2), status: 'open', matchedKg: 0 },
  { id: 'r_04', buyerId: 'u_b4', productId: 'pr_potato', quantityKg: 400, maxPricePerKg: 16, requiredBy: iso(6), buyerPlaceId: 'p_ara', pickupPlaceId: 'p_ara_mandi', buyerType: 'bulk', bulkCategory: 'canteen', createdAt: iso(-3), status: 'open', matchedKg: 0 },
  { id: 'r_05', buyerId: 'u_b6', productId: 'pr_onion', quantityKg: 900, maxPricePerKg: 24, requiredBy: iso(8), buyerPlaceId: 'p_patna', pickupPlaceId: 'p_patna', buyerType: 'bulk', bulkCategory: 'business', createdAt: iso(-4), status: 'partially_matched', matchedKg: 150 },
  { id: 'r_06', buyerId: 'u_b7', productId: 'pr_onion', quantityKg: 500, maxPricePerKg: 23.5, requiredBy: iso(7), buyerPlaceId: 'p_varanasi', pickupPlaceId: 'p_varanasi', buyerType: 'bulk', bulkCategory: 'institution', createdAt: iso(-2), status: 'open', matchedKg: 0 },
  { id: 'r_07', buyerId: 'u_b5', productId: 'pr_cauliflower', quantityKg: 12, maxPricePerKg: 20, requiredBy: iso(2), buyerPlaceId: 'p_buxar', pickupPlaceId: 'p_buxar', buyerType: 'individual', createdAt: iso(-1), status: 'open', matchedKg: 0 },
  { id: 'r_08', buyerId: 'u_b1', productId: 'pr_cauliflower', quantityKg: 120, maxPricePerKg: 19, requiredBy: iso(3), buyerPlaceId: 'p_buxar', pickupPlaceId: 'p_buxar', buyerType: 'bulk', bulkCategory: 'restaurant', createdAt: iso(-2), status: 'open', matchedKg: 0 },
  { id: 'r_09', buyerId: 'u_b6', productId: 'pr_rice', quantityKg: 1000, maxPricePerKg: 33, requiredBy: iso(12), buyerPlaceId: 'p_patna', pickupPlaceId: 'p_danapur', buyerType: 'bulk', bulkCategory: 'business', createdAt: iso(-6), status: 'open', matchedKg: 0 },
  { id: 'r_10', buyerId: 'u_b2', productId: 'pr_potato', quantityKg: 250, maxPricePerKg: 15.5, requiredBy: iso(5), buyerPlaceId: 'p_buxar', pickupPlaceId: 'p_buxar_mandi', buyerType: 'bulk', bulkCategory: 'retailer', createdAt: iso(-1), status: 'open', matchedKg: 0 },
]

/* ------------------------------ Orders ----------------------------- */
const ev = (offset: number, label: string, by: Order['timeline'][number]['by']) => ({ at: iso(offset), label, by })

export const orders: Order[] = [
  {
    id: 'o_01', listingId: 'l_03', requirementId: 'r_01', buyerId: 'u_b1', sellerId: 'u_f3', productId: 'pr_tomato',
    quantityKg: 80, pricePerKg: 20, status: 'confirmed', createdAt: iso(-2), buyerConfirmed: true, sellerConfirmed: true,
    timeline: [ev(-2, 'Order placed by buyer', 'buyer'), ev(-2, 'Matched to listing', 'system'), ev(-2, 'Transport feasibility checked', 'system'), ev(-1, 'Accepted by farmer', 'farmer'), ev(-1, 'Confirmed by both sides', 'system')],
  },
  {
    id: 'o_02', listingId: 'l_07', requirementId: 'r_05', buyerId: 'u_b6', sellerId: 'u_f7', productId: 'pr_onion',
    quantityKg: 150, pricePerKg: 22, status: 'awaiting_confirmation', createdAt: iso(-1), buyerConfirmed: true, sellerConfirmed: false,
    timeline: [ev(-1, 'Order placed by buyer', 'buyer'), ev(-1, 'Matched to listing', 'system'), ev(-1, 'Transport feasibility checked', 'system'), ev(-1, 'Waiting for farmer confirmation', 'system')],
  },
  {
    id: 'o_03', listingId: 'l_10', buyerId: 'u_b2', sellerId: 'u_fpo1', productId: 'pr_tomato',
    quantityKg: 200, pricePerKg: 19.5, status: 'completed', createdAt: iso(-9), buyerConfirmed: true, sellerConfirmed: true,
    timeline: [ev(-9, 'Order placed by buyer', 'buyer'), ev(-9, 'Matched to FPO stock', 'system'), ev(-8, 'Accepted by FPO', 'fpo'), ev(-8, 'Confirmed by both sides', 'system'), ev(-7, 'Handover completed at Buxar Mandi', 'system')],
  },
  {
    id: 'o_04', listingId: 'l_16', buyerId: 'u_b1', sellerId: 'u_f4', productId: 'pr_tomato',
    quantityKg: 180, pricePerKg: 19, status: 'completed', createdAt: iso(-13), buyerConfirmed: true, sellerConfirmed: true,
    timeline: [ev(-13, 'Order placed by buyer', 'buyer'), ev(-12, 'Accepted by farmer', 'farmer'), ev(-12, 'Confirmed by both sides', 'system'), ev(-11, 'Handover completed', 'system')],
  },
  {
    id: 'o_05', listingId: 'l_04', buyerId: 'u_b3', sellerId: 'u_f4', productId: 'pr_potato',
    quantityKg: 120, pricePerKg: 14, status: 'pending', createdAt: iso(0), buyerConfirmed: false, sellerConfirmed: false,
    timeline: [ev(0, 'Order placed by buyer', 'buyer')],
  },
  {
    id: 'o_06', listingId: 'l_13', buyerId: 'u_b7', sellerId: 'u_fpo2', productId: 'pr_wheat',
    quantityKg: 600, pricePerKg: 23, status: 'cancelled', createdAt: iso(-5), buyerConfirmed: false, sellerConfirmed: false,
    timeline: [ev(-5, 'Order placed by buyer', 'buyer'), ev(-5, 'Transport feasibility checked', 'system'), ev(-4, 'Cancelled — additional transport removed the price advantage', 'buyer')],
  },
]

/** Past transaction volume per product, used by the forecast model. */
export const historicalOrdersKg: Record<string, number[]> = {
  pr_tomato: [980, 1040, 1120, 1180, 1210, 1260],
  pr_potato: [1400, 1350, 1290, 1310, 1280, 1300],
  pr_onion: [700, 760, 790, 820, 860, 880],
  pr_cauliflower: [340, 360, 410, 390, 420, 450],
  pr_wheat: [2100, 1950, 1800, 1760, 1700, 1680],
  pr_rice: [1500, 1560, 1520, 1580, 1610, 1640],
}
