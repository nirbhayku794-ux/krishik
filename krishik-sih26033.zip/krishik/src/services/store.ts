import { admins, buyers, farmers, fpos, listings, orders, requirements } from '@/data/seed'
import type { Admin, Buyer, FPO, Farmer, Listing, Order, Requirement } from '@/types'

/**
 * A tiny in-memory database. Every service reads and writes here, so the whole
 * prototype behaves like a real app (create a listing, see it in the
 * marketplace) without a backend. Replacing this file with Supabase queries is
 * the only change needed to go live — see README "Connecting Supabase".
 */
export interface Store {
  farmers: Farmer[]
  fpos: FPO[]
  buyers: Buyer[]
  admins: Admin[]
  listings: Listing[]
  requirements: Requirement[]
  orders: Order[]
}

export const store: Store = {
  farmers: [...farmers],
  fpos: [...fpos],
  buyers: [...buyers],
  admins: [...admins],
  listings: [...listings],
  requirements: [...requirements],
  orders: [...orders],
}

let version = 0
const listeners = new Set<() => void>()

export const getVersion = () => version
export const bump = () => {
  version += 1
  listeners.forEach((l) => l())
}
export const subscribe = (listener: () => void) => {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

/** Network-ish pause so loading states are visible in the demo. */
export const delay = <T>(value: T, ms = 220) => new Promise<T>((r) => setTimeout(() => r(value), ms))

let counter = 100
export const nextId = (prefix: string) => `${prefix}_${++counter}`
