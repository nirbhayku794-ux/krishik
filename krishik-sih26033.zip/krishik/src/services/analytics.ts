import { productById, products } from '@/data/seed'
import { round } from '@/lib/format'
import type { PlatformAnalytics } from '@/types'
import { delay, store } from './store'
import { enrichOrder } from './trade'

export async function getPlatformAnalytics(): Promise<PlatformAnalytics> {
  const activeListings = store.listings.filter((l) => l.status === 'active')
  const openRequirements = store.requirements.filter((r) => r.status !== 'closed')
  const liveOrders = store.orders.filter((o) => o.status !== 'cancelled').map(enrichOrder)
  const completed = liveOrders.filter((o) => o.status === 'completed')

  const listedKg = activeListings.reduce((s, l) => s + l.quantityKg, 0)
  const demandKg = openRequirements.reduce((s, r) => s + r.quantityKg, 0)
  const matchedKg = liveOrders.reduce((s, o) => s + o.quantityKg, 0)

  const avgFarmerPrice = mean(liveOrders.map((o) => o.pricePerKg))
  const avgBuyerPrice = mean(liveOrders.map((o) => o.pricing?.finalBuyerPricePerKg ?? o.pricePerKg))
  const avgReferencePrice = mean(liveOrders.map((o) => productById(o.productId).referencePricePerKg))
  const transportCost = liveOrders.reduce((s, o) => s + (o.transport?.additionalCost ?? 0), 0)
  const transactionValue = liveOrders.reduce((s, o) => s + (o.pricing?.buyerTotal ?? 0), 0)

  /* Estimated share of movement avoided: each matched order would otherwise
     travel farm → mandi → wholesaler → retailer. We compare the extra km an
     order actually adds against that conventional chain. */
  const viable = liveOrders.filter((o) => o.transport && o.transport.status !== 'not-feasible')
  /* A conventional chain adds roughly three more hops after the mandi
     (trader, wholesaler, retailer). We size those at ~15 km each and compare
     them with the extra distance a direct handover actually costs. */
  const CHAIN_KM = 45
  const conventionalKm = viable.reduce((s, o) => s + (o.transport?.baselineKm ?? 0) + CHAIN_KM, 0)
  const actualKm = viable.reduce((s, o) => s + (o.transport?.baselineKm ?? 0) + (o.transport?.additionalKm ?? 0), 0)
  const movementReductionPct = conventionalKm > 0 ? Math.round(((conventionalKm - actualKm) / conventionalKm) * 100) : 0

  const byProduct = products.map((p) => ({
    name: p.name,
    listedKg: activeListings.filter((l) => l.productId === p.id).reduce((s, l) => s + l.quantityKg, 0),
    demandKg: openRequirements.filter((r) => r.productId === p.id).reduce((s, r) => s + r.quantityKg, 0),
    matchedKg: liveOrders.filter((o) => o.productId === p.id).reduce((s, o) => s + o.quantityKg, 0),
  }))

  const monthly = buildMonthly(liveOrders.map((o) => ({ at: o.createdAt, kg: o.quantityKg, value: o.pricing?.buyerTotal ?? 0 })))

  return delay({
    farmers: store.farmers.length,
    fpos: store.fpos.length,
    buyers: store.buyers.length,
    activeListings: activeListings.length,
    openRequirements: openRequirements.length,
    orders: store.orders.length,
    completedOrders: completed.length,
    listedKg,
    demandKg,
    matchedKg,
    unmatchedKg: Math.max(0, demandKg - matchedKg),
    avgFarmerPrice: round(avgFarmerPrice, 2),
    avgBuyerPrice: round(avgBuyerPrice, 2),
    avgReferencePrice: round(avgReferencePrice, 2),
    transportCost: round(transportCost, 2),
    transactionValue: round(transactionValue, 2),
    movementReductionPct: Math.max(0, Math.min(85, movementReductionPct)),
    byProduct,
    monthly,
  })
}

const mean = (values: number[]) => (values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0)

function buildMonthly(rows: { at: string; kg: number; value: number }[]) {
  const months: { month: string; matchedKg: number; value: number }[] = []
  for (let i = 5; i >= 0; i--) {
    const d = new Date()
    d.setMonth(d.getMonth() - i)
    const key = d.toLocaleDateString('en-IN', { month: 'short' })
    const seasonalBase = 900 + i * 60
    const inMonth = rows.filter((r) => new Date(r.at).getMonth() === d.getMonth())
    months.push({
      month: key,
      matchedKg: Math.round(seasonalBase + inMonth.reduce((s, r) => s + r.kg, 0)),
      value: Math.round((seasonalBase + inMonth.reduce((s, r) => s + r.kg, 0)) * 21.5),
    })
  }
  return months
}
