import { productById } from '@/data/seed'
import { round } from '@/lib/format'
import { roadKm } from '@/lib/geo'
import type { AggregatedMatch, DemandPool, Listing, MatchResult, Requirement } from '@/types'
import { calculateTransportFeasibility } from './logistics'
import { delay, store } from './store'
import { sellerName, sellerVerified, sellerSellingPlace } from './users'

/**
 * Match score is a prototype ranking signal, not a guarantee. It blends four
 * things a buyer would weigh by hand: price headroom, distance, how much of
 * the requirement one seller can cover, and whether the produce is available
 * in time.
 */
function scoreMatch(listing: Listing, requirement: Requirement, distanceKm: number, coverKg: number) {
  const priceHeadroom = (requirement.maxPricePerKg - listing.pricePerKg) / requirement.maxPricePerKg
  const priceScore = clamp01(0.55 + priceHeadroom * 3) * 35
  const distanceScore = clamp01(1 - distanceKm / 60) * 30
  const coverScore = clamp01(coverKg / requirement.quantityKg + 0.35) * 20
  const inTime = new Date(listing.availableFrom) <= new Date(requirement.requiredBy) &&
    new Date(listing.availableUntil) >= new Date()
  const availabilityScore = inTime ? 15 : 4
  return Math.min(99, Math.round(priceScore + distanceScore + coverScore + availabilityScore))
}

const clamp01 = (v: number) => Math.max(0, Math.min(1, v))

export function buildMatch(listing: Listing, requirement: Requirement, quantityKg: number): MatchResult {
  const distanceKm = roadKm(listing.farmPlaceId, requirement.pickupPlaceId)
  const product = productById(listing.productId)
  const transport = calculateTransportFeasibility({
    farmPlaceId: listing.farmPlaceId,
    preferredSellingPlaceId: listing.preferredSellingPlaceId,
    buyerPlaceId: requirement.pickupPlaceId,
    quantityKg,
    maxAdditionalKm: listing.maxAdditionalKm,
    farmerPricePerKg: listing.pricePerKg,
    referencePricePerKg: product.referencePricePerKg,
  })

  return {
    listing,
    sellerName: sellerName(listing.sellerId),
    sellerVerified: sellerVerified(listing.sellerId),
    quantityKg,
    pricePerKg: listing.pricePerKg,
    distanceKm,
    score: scoreMatch(listing, requirement, distanceKm, quantityKg),
    transport,
    checks: [
      { label: 'Quantity compatible', ok: listing.remainingKg > 0 },
      { label: 'Price within buyer ceiling', ok: listing.pricePerKg <= requirement.maxPricePerKg },
      { label: 'Location compatible', ok: transport.status !== 'not-feasible' },
      { label: 'Available before required date', ok: new Date(listing.availableFrom) <= new Date(requirement.requiredBy) },
    ],
  }
}

/** Greedy fill: best-scoring sellers first, until the requirement is covered. */
export async function calculateMatch(requirementId: string): Promise<AggregatedMatch | null> {
  const requirement = store.requirements.find((r) => r.id === requirementId)
  if (!requirement) return delay(null)

  const considered = store.listings
    .filter((l) => l.productId === requirement.productId && l.status === 'active' && l.remainingKg > 0)
    .filter((l) => l.pricePerKg <= requirement.maxPricePerKg * 1.08)
    .map((l) => buildMatch(l, requirement, Math.min(l.remainingKg, requirement.quantityKg)))
    .sort((a, b) => b.score - a.score)

  const candidates = considered.filter((m) => m.transport.status !== 'not-feasible')
  const rejected = considered.filter((m) => m.transport.status === 'not-feasible')

  /* Greedy fill, best score first. When more than one seller can serve the
     requirement, no single seller is given more than 70% of it: spreading the
     order keeps smaller farms in the transaction instead of handing every
     pooled requirement to the largest aggregator. */
  const outstanding = requirement.quantityKg - requirement.matchedKg
  const cap = candidates.length > 1 ? Math.ceil(outstanding * 0.7) : outstanding
  let remaining = outstanding
  const matches: MatchResult[] = []
  for (const candidate of candidates) {
    if (remaining <= 0) break
    const take = Math.min(candidate.listing.remainingKg, remaining, cap)
    if (take <= 0) continue
    matches.push(buildMatch(candidate.listing, requirement, take))
    remaining -= take
  }

  const matchedKg = matches.reduce((sum, m) => sum + m.quantityKg, 0)
  const weighted = matchedKg
    ? round(matches.reduce((sum, m) => sum + m.pricePerKg * m.quantityKg, 0) / matchedKg, 2)
    : 0

  return delay({ requirement, matches, rejected, matchedKg, shortfallKg: Math.max(0, remaining), weightedPricePerKg: weighted })
}

export async function getAllMatches(buyerId?: string): Promise<AggregatedMatch[]> {
  const reqs = store.requirements.filter(
    (r) => (!buyerId || r.buyerId === buyerId) && r.status !== 'closed',
  )
  const results = await Promise.all(reqs.map((r) => calculateMatch(r.id)))
  return results.filter(Boolean) as AggregatedMatch[]
}

/** Demand opportunities a farmer should know about, for their crops and area. */
export async function getDemandOpportunities(sellerId: string) {
  const sellingPlace = sellerSellingPlace(sellerId)
  const pools = await getDemandPools()
  return delay(
    pools
      .map((pool) => {
        const nearby = pool.demands.filter((d) => roadKm(d.placeId, sellingPlace) <= 45)
        const demandKg = nearby.reduce((s, d) => s + d.quantityKg, 0)
        const supplyKg = pool.supplyKg
        const gap = demandKg - supplyKg
        return {
          productId: pool.productId,
          productName: pool.productName,
          emoji: pool.emoji,
          demandKg,
          supplyKg,
          gap,
          buyers: nearby.length,
          intensity: gap > 200 ? 'high' : gap > 0 ? 'moderate' : 'covered',
          recommendation:
            gap > 0
              ? `Demand is running ahead of listed supply by ${Math.round(gap)} kg. Listing ${pool.productName.toLowerCase()} this week is likely to find a buyer.`
              : `Listed supply already covers nearby demand. Expect slower matching for ${pool.productName.toLowerCase()}.`,
        }
      })
      .sort((a, b) => b.gap - a.gap),
  )
}

/** Fragmented buyer requirements pooled per crop — the aggregation view. */
export async function getDemandPools(): Promise<DemandPool[]> {
  const byProduct = new Map<string, DemandPool>()

  for (const r of store.requirements) {
    if (r.status === 'closed') continue
    const product = productById(r.productId)
    const pool = byProduct.get(r.productId) ?? emptyPool(r.productId, product.name, product.emoji)
    const buyer = store.buyers.find((b) => b.id === r.buyerId)
    pool.demands.push({
      requirementId: r.id,
      buyerName: buyer?.businessName ?? buyer?.name ?? 'Buyer',
      quantityKg: r.quantityKg - r.matchedKg,
      maxPricePerKg: r.maxPricePerKg,
      placeId: r.pickupPlaceId,
    })
    byProduct.set(r.productId, pool)
  }

  for (const l of store.listings) {
    if (l.status !== 'active' || l.remainingKg <= 0) continue
    const product = productById(l.productId)
    const pool = byProduct.get(l.productId) ?? emptyPool(l.productId, product.name, product.emoji)
    pool.supplies.push({
      listingId: l.id,
      sellerName: sellerName(l.sellerId),
      quantityKg: l.remainingKg,
      pricePerKg: l.pricePerKg,
      placeId: l.farmPlaceId,
    })
    byProduct.set(l.productId, pool)
  }

  const pools = [...byProduct.values()].map((pool) => {
    pool.demandKg = pool.demands.reduce((s, d) => s + d.quantityKg, 0)
    pool.supplyKg = pool.supplies.reduce((s, d) => s + d.quantityKg, 0)
    pool.matchedKg = Math.min(pool.demandKg, pool.supplyKg)
    return pool
  })

  return delay(pools.sort((a, b) => b.demandKg - a.demandKg))
}

const emptyPool = (productId: string, productName: string, emoji: string): DemandPool => ({
  productId, productName, emoji, demands: [], supplies: [], demandKg: 0, supplyKg: 0, matchedKg: 0,
})
