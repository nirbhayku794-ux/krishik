import { placeById } from '@/data/seed'
import type { AnyUser, Buyer, FPO, Farmer } from '@/types'
import { delay, store } from './store'

export const allUsers = (): AnyUser[] => [...store.farmers, ...store.fpos, ...store.buyers, ...store.admins]

export const findUser = (id: string): AnyUser | undefined => allUsers().find((u) => u.id === id)
export const findUserByEmail = (email: string) =>
  allUsers().find((u) => u.email.toLowerCase() === email.trim().toLowerCase())

export const sellerName = (id: string) => findUser(id)?.name ?? 'Unknown seller'
export const sellerVerified = (id: string) => findUser(id)?.verified ?? false
export const userPlaceName = (id: string) => {
  const u = findUser(id)
  return u ? placeById(u.placeId).name : '—'
}

export const sellerSellingPlace = (id: string) => {
  const u = findUser(id)
  if (u && 'preferredSellingPlaceId' in u) return (u as Farmer | FPO).preferredSellingPlaceId
  return u?.placeId ?? 'p_buxar'
}

export const getFarmers = async (): Promise<Farmer[]> => delay([...store.farmers])
export const getFPOs = async (): Promise<FPO[]> => delay([...store.fpos])
export const getBuyers = async (): Promise<Buyer[]> => delay([...store.buyers])
export const getUsers = async (): Promise<AnyUser[]> => delay(allUsers())

export async function setVerified(userId: string, verified: boolean) {
  const user = allUsers().find((u) => u.id === userId)
  if (user) user.verified = verified
  return delay(user, 120)
}
