import { roadKm } from '@/lib/geo'
import { round } from '@/lib/format'
import type { PriceBreakdown, TransportAnalysis } from '@/types'

/* ------------------------------------------------------------------
   Krishik owns no vehicles. This module answers one question only:
   given that the farmer is already travelling to a selling location,
   how much *extra* movement does serving this buyer create, and is
   the direct transaction still worth it?
------------------------------------------------------------------ */

export const VEHICLES = [
  { label: 'Two-wheeler / cycle cart', capacityKg: 120, costPerKm: 6 },
  { label: 'Auto / tempo (shared)', capacityKg: 400, costPerKm: 12 },
  { label: 'Pickup (Chhota Hathi)', capacityKg: 1200, costPerKm: 20 },
  { label: 'Small truck', capacityKg: 4000, costPerKm: 32 },
  { label: 'Truck', capacityKg: 12000, costPerKm: 48 },
]

export const pickVehicle = (quantityKg: number) =>
  VEHICLES.find((v) => quantityKg <= v.capacityKg) ?? VEHICLES[VEHICLES.length - 1]

export interface FeasibilityInput {
  farmPlaceId: string
  preferredSellingPlaceId: string
  buyerPlaceId: string
  quantityKg: number
  maxAdditionalKm: number
  farmerPricePerKg?: number
  referencePricePerKg?: number
}

/**
 * Detour-insertion model.
 *   baseline  farm → preferred selling location   (the trip already happening)
 *   route     farm → buyer → preferred selling location
 *   extra     route − baseline
 * A buyer sitting on the farmer's existing route costs close to nothing;
 * a buyer in the opposite direction shows up as real added cost.
 */
export function calculateTransportFeasibility(input: FeasibilityInput): TransportAnalysis {
  const { farmPlaceId, preferredSellingPlaceId, buyerPlaceId, quantityKg, maxAdditionalKm } = input

  const baselineKm = roadKm(farmPlaceId, preferredSellingPlaceId)
  const directKm = roadKm(farmPlaceId, buyerPlaceId)
  const returnKm = roadKm(buyerPlaceId, preferredSellingPlaceId)
  const routeKm = round(directKm + returnKm, 1)
  const additionalKm = round(Math.max(0, routeKm - baselineKm), 1)

  const vehicle = pickVehicle(quantityKg)
  const additionalCost = round(additionalKm * vehicle.costPerKm, 2)
  const costPerKg = quantityKg > 0 ? round(additionalCost / quantityKg, 2) : 0
  const withinFarmerLimit = additionalKm <= maxAdditionalKm

  const farmerPrice = input.farmerPricePerKg ?? 0
  const reference = input.referencePricePerKg ?? 0
  const fees = farmerPrice ? platformFee(farmerPrice) + HANDLING_PER_KG : 0
  const buyerAdvantage = reference ? round(reference - (farmerPrice + costPerKg + fees), 2) : null

  let status: TransportAnalysis['status'] = 'feasible'
  let message = 'The buyer is close to the route this farmer already travels. Direct handover is practical.'

  if (buyerAdvantage !== null && buyerAdvantage <= 0) {
    status = 'not-feasible'
    message = 'Additional transport cancels the price advantage. A nearer buyer will serve both sides better.'
  } else if (additionalKm > maxAdditionalKm * 1.6) {
    status = 'not-feasible'
    message = `Extra travel is far beyond the ${maxAdditionalKm} km this farmer accepts. Consider another nearby buyer.`
  } else if (!withinFarmerLimit || costPerKg > farmerPrice * 0.12 || (buyerAdvantage !== null && buyerAdvantage < 1)) {
    status = 'low-advantage'
    message = 'The direct route works, but added transport eats most of the gain. Consider another nearby buyer or a larger combined load.'
  }

  const reasons = [
    { label: `Extra travel ${additionalKm} km${withinFarmerLimit ? '' : ` (over the ${maxAdditionalKm} km limit)`}`, ok: withinFarmerLimit },
    { label: `${vehicle.label} suits ${Math.round(quantityKg)} kg`, ok: quantityKg <= vehicle.capacityKg },
    { label: `Transport adds ₹${costPerKg}/kg`, ok: farmerPrice === 0 ? true : costPerKg <= farmerPrice * 0.12 },
    { label: buyerAdvantage === null ? 'Reference price not available' : buyerAdvantage > 0 ? `Buyer still saves ₹${buyerAdvantage}/kg against the reference price` : 'No saving left against the reference price', ok: buyerAdvantage === null ? true : buyerAdvantage > 0 },
  ]

  return {
    baselineKm, routeKm, additionalKm, directKm, vehicle, additionalCost, costPerKg,
    withinFarmerLimit, status, message, reasons,
    legs: [
      { fromPlaceId: farmPlaceId, toPlaceId: buyerPlaceId, km: directKm, label: 'Farm to buyer' },
      { fromPlaceId: buyerPlaceId, toPlaceId: preferredSellingPlaceId, km: returnKm, label: 'Buyer to usual selling point' },
    ],
  }
}

/* ------------------------- Price transparency ------------------------- */

export const HANDLING_PER_KG = 0.1
/** 2% of the farmer's price, which is how Krishik would sustain itself. */
export const platformFee = (farmerPricePerKg: number) => round(farmerPricePerKg * 0.02, 2)

export function calculatePriceBreakdown(args: {
  farmerPricePerKg: number
  transportPerKg: number
  quantityKg: number
  referencePricePerKg: number
}): PriceBreakdown {
  const { farmerPricePerKg, transportPerKg, quantityKg, referencePricePerKg } = args
  const platformPerKg = platformFee(farmerPricePerKg)
  const handlingPerKg = HANDLING_PER_KG
  const finalBuyerPricePerKg = round(farmerPricePerKg + transportPerKg + platformPerKg + handlingPerKg, 2)
  const differencePerKg = round(referencePricePerKg - finalBuyerPricePerKg, 2)

  return {
    farmerPricePerKg, transportPerKg, platformPerKg, handlingPerKg,
    finalBuyerPricePerKg, referencePricePerKg, differencePerKg,
    farmerEarnings: round(farmerPricePerKg * quantityKg, 2),
    buyerTotal: round(finalBuyerPricePerKg * quantityKg, 2),
    advantage: differencePerKg >= 1 ? 'buyer-advantage' : differencePerKg > 0 ? 'neutral' : 'no-advantage',
  }
}

export const advantageCopy: Record<PriceBreakdown['advantage'], string> = {
  'buyer-advantage': 'Buying direct is cheaper than the reference market price today.',
  neutral: 'Prices are close to the reference market price. The gain is small.',
  'no-advantage': 'Direct transaction may not currently provide a price advantage.',
}
