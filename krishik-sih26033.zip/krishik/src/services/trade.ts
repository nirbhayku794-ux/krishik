import { productById } from '@/data/seed'
import { roadKm } from '@/lib/geo'
import type { Grade, Listing, Order, OrderStatus, Requirement, Transaction } from '@/types'
import { calculatePriceBreakdown, calculateTransportFeasibility } from './logistics'
import { bump, delay, nextId, store } from './store'
import { findUser, sellerSellingPlace } from './users'

/* ------------------------------- Listings ------------------------------- */

export interface ListingFilters {
  search?: string
  productId?: string
  category?: string
  placeId?: string
  minQuantityKg?: number
  maxPricePerKg?: number
  grade?: Grade | 'any'
  availableOnly?: boolean
  nearPlaceId?: string
}

export async function getListings(filters: ListingFilters = {}): Promise<Listing[]> {
  let rows = store.listings.filter((l) => (filters.availableOnly === false ? true : l.status === 'active'))

  if (filters.search) {
    const q = filters.search.toLowerCase()
    rows = rows.filter((l) => {
      const product = productById(l.productId)
      const seller = findUser(l.sellerId)
      return product.name.toLowerCase().includes(q) || (seller?.name ?? '').toLowerCase().includes(q)
    })
  }
  if (filters.productId) rows = rows.filter((l) => l.productId === filters.productId)
  if (filters.category && filters.category !== 'any')
    rows = rows.filter((l) => productById(l.productId).category === filters.category)
  if (filters.placeId && filters.placeId !== 'any') rows = rows.filter((l) => l.farmPlaceId === filters.placeId)
  if (filters.minQuantityKg) rows = rows.filter((l) => l.remainingKg >= filters.minQuantityKg!)
  if (filters.maxPricePerKg) rows = rows.filter((l) => l.pricePerKg <= filters.maxPricePerKg!)
  if (filters.grade && filters.grade !== 'any') rows = rows.filter((l) => l.grade === filters.grade)

  return delay(rows.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)))
}

export const getListing = async (id: string) => delay(store.listings.find((l) => l.id === id) ?? null)
export const getListingsBySeller = async (sellerId: string) =>
  delay(store.listings.filter((l) => l.sellerId === sellerId))

export type NewListingInput = Omit<Listing, 'id' | 'createdAt' | 'status' | 'remainingKg'>

export async function createListing(input: NewListingInput): Promise<Listing> {
  const listing: Listing = {
    ...input,
    id: nextId('l'),
    remainingKg: input.quantityKg,
    createdAt: new Date().toISOString(),
    status: 'active',
  }
  store.listings.unshift(listing)
  bump()
  return delay(listing)
}

export async function updateListingStatus(id: string, status: Listing['status']) {
  const listing = store.listings.find((l) => l.id === id)
  if (listing) listing.status = status
  bump()
  return delay(listing ?? null, 120)
}

export async function removeListing(id: string) {
  store.listings = store.listings.filter((l) => l.id !== id)
  bump()
  return delay(true, 120)
}

/* ----------------------------- Requirements ----------------------------- */

export const getRequirements = async (buyerId?: string) =>
  delay(
    store.requirements
      .filter((r) => !buyerId || r.buyerId === buyerId)
      .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)),
  )

export const getRequirement = async (id: string) => delay(store.requirements.find((r) => r.id === id) ?? null)

export type NewRequirementInput = Omit<Requirement, 'id' | 'createdAt' | 'status' | 'matchedKg'>

export async function createRequirement(input: NewRequirementInput): Promise<Requirement> {
  const requirement: Requirement = {
    ...input,
    id: nextId('r'),
    createdAt: new Date().toISOString(),
    status: 'open',
    matchedKg: 0,
  }
  store.requirements.unshift(requirement)
  bump()
  return delay(requirement)
}

export async function closeRequirement(id: string) {
  const r = store.requirements.find((x) => x.id === id)
  if (r) r.status = 'closed'
  bump()
  return delay(r ?? null, 120)
}

/* -------------------------------- Orders -------------------------------- */

export const getOrders = async (filter: { buyerId?: string; sellerId?: string } = {}) =>
  delay(
    store.orders
      .filter((o) => (!filter.buyerId || o.buyerId === filter.buyerId) && (!filter.sellerId || o.sellerId === filter.sellerId))
      .map(enrichOrder)
      .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)),
  )

export const getOrder = async (id: string) => {
  const order = store.orders.find((o) => o.id === id)
  return delay(order ? enrichOrder(order) : null)
}

/** Attaches a fresh feasibility + price analysis to an order. */
export function enrichOrder(order: Order): Order {
  const listing = store.listings.find((l) => l.id === order.listingId)
  const buyer = findUser(order.buyerId)
  if (!listing || !buyer) return order
  const product = productById(order.productId)

  const transport = calculateTransportFeasibility({
    farmPlaceId: listing.farmPlaceId,
    preferredSellingPlaceId: listing.preferredSellingPlaceId,
    buyerPlaceId: buyer.placeId,
    quantityKg: order.quantityKg,
    maxAdditionalKm: listing.maxAdditionalKm,
    farmerPricePerKg: order.pricePerKg,
    referencePricePerKg: product.referencePricePerKg,
  })
  const pricing = calculatePriceBreakdown({
    farmerPricePerKg: order.pricePerKg,
    transportPerKg: transport.costPerKg,
    quantityKg: order.quantityKg,
    referencePricePerKg: product.referencePricePerKg,
  })
  return { ...order, transport, pricing }
}

export async function createOrder(input: {
  listingId: string
  buyerId: string
  quantityKg: number
  requirementId?: string
}): Promise<Order | null> {
  const listing = store.listings.find((l) => l.id === input.listingId)
  if (!listing || listing.remainingKg < input.quantityKg) return delay(null)

  const order: Order = {
    id: nextId('o'),
    listingId: listing.id,
    requirementId: input.requirementId,
    buyerId: input.buyerId,
    sellerId: listing.sellerId,
    productId: listing.productId,
    quantityKg: input.quantityKg,
    pricePerKg: listing.pricePerKg,
    status: 'feasibility_check',
    createdAt: new Date().toISOString(),
    buyerConfirmed: false,
    sellerConfirmed: false,
    timeline: [
      { at: new Date().toISOString(), label: 'Order placed by buyer', by: 'buyer' },
      { at: new Date().toISOString(), label: 'Matched to listing', by: 'system' },
      { at: new Date().toISOString(), label: 'Transport feasibility checked', by: 'system' },
    ],
  }

  listing.remainingKg -= input.quantityKg
  if (listing.remainingKg === 0) listing.status = 'sold'

  if (input.requirementId) {
    const req = store.requirements.find((r) => r.id === input.requirementId)
    if (req) {
      req.matchedKg = Math.min(req.quantityKg, req.matchedKg + input.quantityKg)
      req.status = req.matchedKg >= req.quantityKg ? 'matched' : 'partially_matched'
    }
  }

  store.orders.unshift(order)
  bump()
  return delay(enrichOrder(order))
}

export async function advanceOrder(orderId: string, action: 'accept' | 'reject' | 'confirm' | 'complete', by: 'farmer' | 'fpo' | 'buyer' | 'admin') {
  const order = store.orders.find((o) => o.id === orderId)
  if (!order) return delay(null)
  const now = new Date().toISOString()

  const set = (status: OrderStatus, label: string) => {
    order.status = status
    order.timeline.push({ at: now, label, by })
  }

  if (action === 'reject') {
    set('cancelled', 'Order declined by seller')
    restoreListing(order)
  } else if (action === 'accept') {
    order.sellerConfirmed = true
    set('awaiting_confirmation', 'Accepted by seller — waiting for buyer confirmation')
  } else if (action === 'confirm') {
    if (by === 'buyer') order.buyerConfirmed = true
    else order.sellerConfirmed = true
    if (order.buyerConfirmed && order.sellerConfirmed) set('confirmed', 'Confirmed by both sides')
    else set('awaiting_confirmation', `Confirmed by ${by}`)
  } else if (action === 'complete') {
    set('completed', 'Handover completed')
  }

  bump()
  return delay(enrichOrder(order), 150)
}

export async function cancelOrder(orderId: string, by: 'buyer' | 'farmer' | 'fpo' | 'admin') {
  const order = store.orders.find((o) => o.id === orderId)
  if (!order) return delay(null)
  order.status = 'cancelled'
  order.timeline.push({ at: new Date().toISOString(), label: `Cancelled by ${by}`, by })
  restoreListing(order)
  bump()
  return delay(enrichOrder(order), 150)
}

function restoreListing(order: Order) {
  const listing = store.listings.find((l) => l.id === order.listingId)
  if (listing) {
    listing.remainingKg = Math.min(listing.quantityKg, listing.remainingKg + order.quantityKg)
    if (listing.status === 'sold' && listing.remainingKg > 0) listing.status = 'active'
  }
}

export async function getTransactions(): Promise<Transaction[]> {
  return delay(
    store.orders
      .filter((o) => o.status === 'completed')
      .map((o) => {
        const enriched = enrichOrder(o)
        const pricing = enriched.pricing!
        return {
          id: `t_${o.id}`,
          orderId: o.id,
          amount: pricing.buyerTotal,
          farmerShare: pricing.farmerEarnings,
          platformShare: pricing.platformPerKg * o.quantityKg,
          transportShare: pricing.transportPerKg * o.quantityKg,
          settledOn: o.timeline[o.timeline.length - 1].at,
        }
      }),
  )
}

/** Distance a buyer sees on a marketplace card. */
export const listingDistanceFrom = (listing: Listing, placeId: string) => roadKm(listing.farmPlaceId, placeId)
export const sellingPlaceOf = sellerSellingPlace
