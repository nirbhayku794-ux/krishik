import { historicalOrdersKg, products } from '@/data/seed'
import { round } from '@/lib/format'
import type { Forecast } from '@/types'
import { delay, store } from './store'

/* ------------------------------------------------------------------
   Prototype forecast. Deterministic and explainable on purpose: the
   same inputs always produce the same numbers, and every number can be
   traced back to a factor shown in the UI. No model is being trained
   here, and nothing on screen claims otherwise.
------------------------------------------------------------------ */

const WEEKDAY_SHAPE = [0.92, 1.04, 1.0, 1.06, 1.12, 1.18, 0.88] // Mon→Sun ordering of market activity

/** Least-squares slope over the recent weekly totals, expressed as a rate. */
function trendRate(series: number[]) {
  const n = series.length
  const meanX = (n - 1) / 2
  const meanY = series.reduce((a, b) => a + b, 0) / n
  let num = 0
  let den = 0
  series.forEach((y, x) => {
    num += (x - meanX) * (y - meanY)
    den += (x - meanX) ** 2
  })
  return den === 0 ? 0 : num / den / meanY
}

export async function getDemandForecast(horizonDays = 7): Promise<Forecast[]> {
  const month = new Date().getMonth()

  const rows = products.map<Forecast>((product) => {
    const history = historicalOrdersKg[product.id] ?? [500, 520, 540, 560, 580, 600]
    const recentAvg = history.slice(-3).reduce((a, b) => a + b, 0) / 3
    const rate = trendRate(history)
    const seasonal = product.seasonality[month]

    const currentDemandKg = store.requirements
      .filter((r) => r.productId === product.id && r.status !== 'closed')
      .reduce((sum, r) => sum + (r.quantityKg - r.matchedKg), 0)
    const currentSupplyKg = store.listings
      .filter((l) => l.productId === product.id && l.status === 'active')
      .reduce((sum, l) => sum + l.remainingKg, 0)

    const baseline = recentAvg * seasonal * (1 + rate)
    const liveSignal = currentDemandKg * 0.3
    const predictedDemandKg = Math.round((baseline + liveSignal) * (horizonDays / 7))

    const trend: Forecast['trend'] = rate > 0.02 ? 'up' : rate < -0.02 ? 'down' : 'stable'

    const dailyDemand = predictedDemandKg / horizonDays
    const dailySupply = (currentSupplyKg / Math.max(horizonDays, 1)) * 0.9
    const series = Array.from({ length: horizonDays }, (_, i) => {
      const d = new Date()
      d.setDate(d.getDate() + i + 1)
      const shape = WEEKDAY_SHAPE[(d.getDay() + 6) % 7]
      return {
        day: d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
        demandKg: Math.round(dailyDemand * shape),
        supplyKg: Math.round(dailySupply * (2 - shape * 0.6)),
      }
    })

    const gap = predictedDemandKg - currentSupplyKg
    return {
      productId: product.id,
      productName: product.name,
      emoji: product.emoji,
      horizonDays,
      predictedDemandKg,
      currentDemandKg,
      currentSupplyKg,
      trend,
      confidence: Math.round(62 + Math.min(28, history.length * 4 + (currentDemandKg > 0 ? 6 : 0))),
      series,
      factors: [
        { label: 'Recent order history', weight: 0.4, note: `${Math.round(recentAvg)} kg average over the last three weeks` },
        { label: 'Live buyer requirements', weight: 0.2, note: `${Math.round(currentDemandKg)} kg open on the platform right now` },
        { label: 'Listed supply', weight: 0.15, note: `${Math.round(currentSupplyKg)} kg currently listed by farmers and FPOs` },
        { label: 'Seasonal pattern', weight: 0.15, note: `${seasonal >= 1 ? 'Above' : 'Below'} average month for ${product.name.toLowerCase()} (×${round(seasonal, 2)})` },
        { label: 'Transaction trend', weight: 0.1, note: `${rate >= 0 ? 'Rising' : 'Easing'} ${Math.abs(Math.round(rate * 100))}% week on week` },
      ],
      recommendation:
        gap > 150
          ? `Forecast demand exceeds listed supply by about ${Math.round(gap)} kg. Listing ${product.name.toLowerCase()} in the next few days is likely to find buyers.`
          : gap > 0
            ? `Demand and supply are close. ${product.name} should still move, though prices may stay flat.`
            : `Listed supply already exceeds forecast demand by about ${Math.abs(Math.round(gap))} kg. Holding stock or targeting a different market may work better.`,
    }
  })

  return delay(rows.sort((a, b) => b.predictedDemandKg - a.predictedDemandKg), 300)
}

export const getForecastFor = async (productId: string, horizonDays = 7) =>
  (await getDemandForecast(horizonDays)).find((f) => f.productId === productId) ?? null
