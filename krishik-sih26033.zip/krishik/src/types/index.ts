/* ------------------------------------------------------------------
   Krishik domain types.
   Services in /src/services return exactly these shapes, so swapping
   the mock layer for Supabase never touches a component.
------------------------------------------------------------------ */

export type Role = 'farmer' | 'fpo' | 'buyer' | 'admin'
export type BuyerType = 'individual' | 'bulk'
export type BulkCategory = 'retailer' | 'restaurant' | 'hostel' | 'canteen' | 'business' | 'institution'
export type Grade = 'A' | 'B' | 'C'
export type Unit = 'kg' | 'quintal'
export type ProductCategory = 'vegetable' | 'fruit' | 'grain' | 'pulse'

export interface Place {
  id: string
  name: string
  district: string
  state: string
  lat: number
  lng: number
}

export interface User {
  id: string
  name: string
  email: string
  phone: string
  role: Role
  placeId: string
  verified: boolean
  joinedOn: string
}

export interface Farmer extends User {
  role: 'farmer'
  farmSizeAcres: number
  fpoId?: string
  preferredSellingPlaceId: string
  maxAdditionalKm: number
  vehicleAccess: 'own-two-wheeler' | 'own-pickup' | 'hired' | 'none'
  rating: number
}

export interface FPO extends User {
  role: 'fpo'
  registrationNo: string
  memberCount: number
  villagesCovered: number
  preferredSellingPlaceId: string
}

export interface Buyer extends User {
  role: 'buyer'
  buyerType: BuyerType
  bulkCategory?: BulkCategory
  businessName?: string
  monthlyVolumeKg?: number
}

export interface Admin extends User {
  role: 'admin'
}

export type AnyUser = Farmer | FPO | Buyer | Admin

export interface Product {
  id: string
  name: string
  category: ProductCategory
  emoji: string
  /** Reference (demo) mandi price used only for comparison, ₹/kg. */
  referencePricePerKg: number
  seasonality: number[]
}

export interface Listing {
  id: string
  sellerId: string
  sellerRole: 'farmer' | 'fpo'
  productId: string
  quantityKg: number
  remainingKg: number
  pricePerKg: number
  unit: Unit
  grade: Grade
  harvestDate: string
  availableFrom: string
  availableUntil: string
  farmPlaceId: string
  preferredSellingPlaceId: string
  maxAdditionalKm: number
  note?: string
  createdAt: string
  status: 'active' | 'reserved' | 'sold' | 'expired'
}

export interface Requirement {
  id: string
  buyerId: string
  productId: string
  quantityKg: number
  maxPricePerKg: number
  requiredBy: string
  buyerPlaceId: string
  pickupPlaceId: string
  buyerType: BuyerType
  bulkCategory?: BulkCategory
  createdAt: string
  status: 'open' | 'partially_matched' | 'matched' | 'closed'
  matchedKg: number
}

export type OrderStatus =
  | 'pending'
  | 'matched'
  | 'feasibility_check'
  | 'awaiting_confirmation'
  | 'confirmed'
  | 'completed'
  | 'cancelled'

export interface OrderEvent {
  at: string
  label: string
  by: Role | 'system'
}

export interface Order {
  id: string
  listingId: string
  requirementId?: string
  buyerId: string
  sellerId: string
  productId: string
  quantityKg: number
  pricePerKg: number
  status: OrderStatus
  createdAt: string
  timeline: OrderEvent[]
  transport?: TransportAnalysis
  pricing?: PriceBreakdown
  buyerConfirmed: boolean
  sellerConfirmed: boolean
}

export interface PriceBreakdown {
  farmerPricePerKg: number
  transportPerKg: number
  platformPerKg: number
  handlingPerKg: number
  finalBuyerPricePerKg: number
  referencePricePerKg: number
  differencePerKg: number
  farmerEarnings: number
  buyerTotal: number
  advantage: 'buyer-advantage' | 'neutral' | 'no-advantage'
}

export type FeasibilityStatus = 'feasible' | 'low-advantage' | 'not-feasible'

export interface RouteLeg {
  fromPlaceId: string
  toPlaceId: string
  km: number
  label: string
}

export interface TransportAnalysis {
  baselineKm: number
  routeKm: number
  additionalKm: number
  directKm: number
  vehicle: { label: string; capacityKg: number; costPerKm: number }
  additionalCost: number
  costPerKg: number
  withinFarmerLimit: boolean
  status: FeasibilityStatus
  message: string
  legs: RouteLeg[]
  reasons: { label: string; ok: boolean }[]
}

export interface MatchResult {
  listing: Listing
  sellerName: string
  sellerVerified: boolean
  quantityKg: number
  pricePerKg: number
  distanceKm: number
  score: number
  checks: { label: string; ok: boolean }[]
  transport: TransportAnalysis
}

export interface AggregatedMatch {
  requirement: Requirement
  matches: MatchResult[]
  /** Sellers considered but left out because the extra travel made them uneconomic. */
  rejected: MatchResult[]
  matchedKg: number
  shortfallKg: number
  weightedPricePerKg: number
}

export interface ForecastPoint {
  day: string
  demandKg: number
  supplyKg: number
}

export interface Forecast {
  productId: string
  productName: string
  emoji: string
  horizonDays: number
  predictedDemandKg: number
  currentDemandKg: number
  currentSupplyKg: number
  trend: 'up' | 'stable' | 'down'
  confidence: number
  series: ForecastPoint[]
  factors: { label: string; weight: number; note: string }[]
  recommendation: string
}

export interface Transaction {
  id: string
  orderId: string
  amount: number
  farmerShare: number
  platformShare: number
  transportShare: number
  settledOn: string
}

export interface DemandPool {
  productId: string
  productName: string
  emoji: string
  demands: { requirementId: string; buyerName: string; quantityKg: number; maxPricePerKg: number; placeId: string }[]
  supplies: { listingId: string; sellerName: string; quantityKg: number; pricePerKg: number; placeId: string }[]
  demandKg: number
  supplyKg: number
  matchedKg: number
}

export interface PlatformAnalytics {
  farmers: number
  fpos: number
  buyers: number
  activeListings: number
  openRequirements: number
  orders: number
  completedOrders: number
  listedKg: number
  demandKg: number
  matchedKg: number
  unmatchedKg: number
  avgFarmerPrice: number
  avgBuyerPrice: number
  avgReferencePrice: number
  transportCost: number
  transactionValue: number
  movementReductionPct: number
  byProduct: { name: string; listedKg: number; demandKg: number; matchedKg: number }[]
  monthly: { month: string; matchedKg: number; value: number }[]
}
