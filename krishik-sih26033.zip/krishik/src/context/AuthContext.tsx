import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type { AnyUser, Role } from '@/types'
import { findUser, findUserByEmail } from '@/services'

const DEMO_ACCOUNTS: Record<Role, string> = {
  farmer: 'farmer@krishik.demo',
  fpo: 'fpo@krishik.demo',
  buyer: 'buyer@krishik.demo',
  admin: 'admin@krishik.demo',
}

interface AuthValue {
  user: AnyUser | null
  role: Role | null
  signIn: (email: string) => AnyUser | null
  signInAs: (role: Role) => AnyUser | null
  signOut: () => void
  demoAccounts: Record<Role, string>
}

const AuthContext = createContext<AuthValue | null>(null)
const STORAGE_KEY = 'krishik.session'

const readStoredId = () => {
  try {
    return localStorage.getItem(STORAGE_KEY)
  } catch {
    return null
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AnyUser | null>(() => {
    const id = readStoredId()
    return id ? findUser(id) ?? null : null
  })

  useEffect(() => {
    try {
      if (user) localStorage.setItem(STORAGE_KEY, user.id)
      else localStorage.removeItem(STORAGE_KEY)
    } catch {
      /* storage can be unavailable; the session simply stays in memory */
    }
  }, [user])

  const signIn = useCallback((email: string) => {
    const found = findUserByEmail(email) ?? null
    setUser(found)
    return found
  }, [])

  const signInAs = useCallback((role: Role) => {
    const found = findUserByEmail(DEMO_ACCOUNTS[role]) ?? null
    setUser(found)
    return found
  }, [])

  const value = useMemo<AuthValue>(
    () => ({ user, role: user?.role ?? null, signIn, signInAs, signOut: () => setUser(null), demoAccounts: DEMO_ACCOUNTS }),
    [user, signIn, signInAs],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
