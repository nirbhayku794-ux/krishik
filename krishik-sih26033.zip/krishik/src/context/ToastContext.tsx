import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'
import { CheckCircle2, Info, TriangleAlert, X } from 'lucide-react'

type Tone = 'success' | 'info' | 'warning'
interface Toast { id: number; title: string; body?: string; tone: Tone }

interface ToastValue {
  notify: (title: string, options?: { body?: string; tone?: Tone }) => void
}

const ToastContext = createContext<ToastValue | null>(null)

const ICONS = { success: CheckCircle2, info: Info, warning: TriangleAlert }
const TONES: Record<Tone, string> = {
  success: 'border-forest-200 bg-forest-50 text-forest-700',
  info: 'border-forest-100 bg-white text-ink',
  warning: 'border-harvest-100 bg-harvest-50 text-harvest-600',
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])

  const notify = useCallback<ToastValue['notify']>((title, options) => {
    const id = Date.now() + Math.random()
    setToasts((prev) => [...prev, { id, title, body: options?.body, tone: options?.tone ?? 'success' }])
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4200)
  }, [])

  const value = useMemo(() => ({ notify }), [notify])

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-[80] flex flex-col items-center gap-2 p-4 sm:items-end sm:p-6">
        {toasts.map((toast) => {
          const Icon = ICONS[toast.tone]
          return (
            <div
              key={toast.id}
              role="status"
              className={`pointer-events-auto flex w-full max-w-sm animate-rise items-start gap-3 rounded-2xl border px-4 py-3 shadow-lift ${TONES[toast.tone]}`}
            >
              <Icon size={18} className="mt-0.5 shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">{toast.title}</p>
                {toast.body && <p className="mt-0.5 text-sm text-ink-soft">{toast.body}</p>}
              </div>
              <button
                onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
                className="rounded-md p-1 text-ink-mute transition hover:bg-black/5"
                aria-label="Dismiss notification"
              >
                <X size={14} />
              </button>
            </div>
          )
        })}
      </div>
    </ToastContext.Provider>
  )
}

export function useToast() {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast must be used inside ToastProvider')
  return ctx
}
