import { renderToString } from 'react-dom/server'
// minimal localStorage polyfill so the demo session can be set per role
const mem = new Map<string, string>()
;(globalThis as any).localStorage = {
  getItem: (k: string) => mem.get(k) ?? null,
  setItem: (k: string, v: string) => void mem.set(k, v),
  removeItem: (k: string) => void mem.delete(k),
}
import { MemoryRouter } from 'react-router-dom'
import App from '../src/App'
import { AuthProvider } from '../src/context/AuthContext'
import { ToastProvider } from '../src/context/ToastContext'

const SESSION: Record<string, string> = {
  farmer: 'u_f1', fpo: 'u_fpo1', buyer: 'u_b1', admin: 'u_a1',
}
const sessionFor = (route: string) =>
  route.startsWith('/farmer/') ? SESSION.farmer
  : route.startsWith('/fpo/') ? SESSION.fpo
  : route.startsWith('/buyer/') ? SESSION.buyer
  : route.startsWith('/admin/') ? SESSION.admin
  : route === '/dashboard' || route === '/logistics' || route === '/ai-insights' ? SESSION.buyer
  : null

const routes = [
  '/', '/login', '/register', '/about', '/marketplace', '/farmer', '/buyer',
  '/dashboard', '/farmer/dashboard', '/farmer/listings', '/farmer/listings/new',
  '/farmer/orders', '/farmer/demand', '/farmer/forecast',
  '/buyer/dashboard', '/buyer/marketplace', '/buyer/requirements', '/buyer/matches', '/buyer/orders',
  '/fpo/dashboard', '/fpo/produce', '/fpo/requirements', '/fpo/analytics',
  '/admin/dashboard', '/admin/users', '/admin/listings', '/admin/orders', '/admin/analytics',
  '/logistics', '/ai-insights', '/this-route-does-not-exist',
]

let failures = 0
for (const route of routes) {
  try {
    const session = sessionFor(route)
    if (session) localStorage.setItem('krishik.session', session)
    else localStorage.removeItem('krishik.session')
    const html = renderToString(
      <MemoryRouter initialEntries={[route]}>
        <AuthProvider>
          <ToastProvider>
            <App />
          </ToastProvider>
        </AuthProvider>
      </MemoryRouter>,
    )
    console.log(`OK   ${route}  (${html.length} chars)`)
  } catch (e) {
    failures++
    console.log(`FAIL ${route}: ${(e as Error).message}`)
  }
}
console.log(failures === 0 ? 'ALL ROUTES RENDERED' : `${failures} FAILURES`)
