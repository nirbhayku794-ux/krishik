import {
  calculateMatch, createListing, createRequirement, createOrder, advanceOrder,
  getDemandPools, getDemandForecast, getPlatformAnalytics, getOrders, enrichOrder,
  calculateTransportFeasibility, calculatePriceBreakdown, store,
} from '../src/services'
import { iso } from '../src/data/seed'

const line = (s: string) => console.log(s)

async function main() {
  // 1. Farmer Ravi Kumar lists 500 kg tomato at Rs 20/kg in Buxar
  const listing = await createListing({
    sellerId: 'u_f1', sellerRole: 'farmer', productId: 'pr_tomato',
    quantityKg: 500, pricePerKg: 20, unit: 'kg', grade: 'A',
    harvestDate: iso(0), availableFrom: iso(0), availableUntil: iso(6),
    farmPlaceId: 'p_buxar', preferredSellingPlaceId: 'p_buxar_mandi', maxAdditionalKm: 10,
  })
  line(`1. LISTING ${listing.id}: ${listing.quantityKg} kg tomato @ Rs ${listing.pricePerKg}/kg, Buxar`)

  // 2. Bulk buyer posts a 300 kg requirement with a Rs 22/kg ceiling
  const requirement = await createRequirement({
    buyerId: 'u_b1', productId: 'pr_tomato', quantityKg: 300, maxPricePerKg: 22,
    requiredBy: iso(4), buyerPlaceId: 'p_buxar', pickupPlaceId: 'p_buxar',
    buyerType: 'bulk', bulkCategory: 'restaurant',
  })
  line(`2. REQUIREMENT ${requirement.id}: ${requirement.quantityKg} kg, max Rs ${requirement.maxPricePerKg}/kg`)

  // 3. Matching
  const match = await calculateMatch(requirement.id)
  line(`3. MATCHED ${match!.matchedKg} kg across ${match!.matches.length} sellers, shortfall ${match!.shortfallKg} kg`)
  match!.matches.forEach((m) =>
    line(`   - ${m.sellerName}: ${m.quantityKg} kg @ Rs ${m.pricePerKg}/kg, ${m.distanceKm} km, score ${m.score}%, ${m.transport.status}`))

  // 4. Aggregation
  const pool = (await getDemandPools()).find((p) => p.productId === 'pr_tomato')!
  line(`4. AGGREGATION tomato: demand ${pool.demandKg} kg from ${pool.demands.length} buyers vs supply ${pool.supplyKg} kg`)

  // 5. Feasibility + price transparency, near vs far buyer
  for (const [label, place] of [['near (Buxar)', 'p_buxar'], ['far (Varanasi)', 'p_varanasi']] as const) {
    const t = calculateTransportFeasibility({
      farmPlaceId: 'p_buxar', preferredSellingPlaceId: 'p_buxar_mandi', buyerPlaceId: place,
      quantityKg: 300, maxAdditionalKm: 10, farmerPricePerKg: 20, referencePricePerKg: 24,
    })
    const p = calculatePriceBreakdown({ farmerPricePerKg: 20, transportPerKg: t.costPerKg, quantityKg: 300, referencePricePerKg: 24 })
    line(`5. ${label}: +${t.additionalKm} km, Rs ${t.costPerKg}/kg transport -> landed Rs ${p.finalBuyerPricePerKg}/kg vs ref Rs 24 => ${t.status} / ${p.advantage}`)
  }

  // 6. Order lifecycle
  const order = await createOrder({ listingId: listing.id, buyerId: 'u_b1', quantityKg: 300, requirementId: requirement.id })
  line(`6. ORDER ${order!.id} status=${order!.status} landed=Rs ${order!.pricing!.finalBuyerPricePerKg}/kg farmer gets Rs ${order!.pricing!.farmerEarnings}`)
  await advanceOrder(order!.id, 'accept', 'farmer')
  await advanceOrder(order!.id, 'confirm', 'buyer')
  const confirmed = (await getOrders({ buyerId: 'u_b1' })).find((o) => o.id === order!.id)!
  line(`   lifecycle -> ${confirmed.status}; listing remaining ${store.listings.find((l) => l.id === listing.id)!.remainingKg} kg`)
  await advanceOrder(order!.id, 'complete', 'farmer')
  line(`   lifecycle -> ${enrichOrder(store.orders.find((o) => o.id === order!.id)!).status}`)

  // 7. Forecast
  const forecast = (await getDemandForecast(7)).find((f) => f.productId === 'pr_tomato')!
  line(`7. FORECAST tomato: ${forecast.currentDemandKg} kg open -> ${forecast.predictedDemandKg} kg over 7 days, trend ${forecast.trend}, confidence ${forecast.confidence}%`)

  // 8. Admin analytics
  const a = await getPlatformAnalytics()
  line(`8. ADMIN: ${a.farmers} farmers, ${a.buyers} buyers, listed ${a.listedKg} kg, demand ${a.demandKg} kg, matched ${a.matchedKg} kg, value Rs ${a.transactionValue}, movement -${a.movementReductionPct}%`)

  const mixed = new Set((await Promise.all(store.requirements.map((r) => calculateMatch(r.id))))
    .flatMap((m) => m?.matches.map((x) => x.transport.status) ?? []))
  line(`9. FEASIBILITY STATES PRESENT: ${[...mixed].join(', ')}`)
}

main()
