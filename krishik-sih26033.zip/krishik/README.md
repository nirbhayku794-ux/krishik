# Krishik

A direct farm-to-buyer marketplace that makes direct transactions **economically practical** — by aggregating fragmented demand, showing the full landed price, and checking whether the extra travel a buyer creates is actually worth it.

Krishik is not a vegetable e-commerce site. It is a matching and decision-support layer between farmers/FPOs and the people who buy from them.

## SIH problem

**SIH26033** — *Multiple intermediaries reduce farmers' earnings and increase consumer prices.*

## Core idea

```
Farmer / FPO  →  Krishik  →  Consumer / Bulk buyer
```

instead of

```
Farmer → Local trader → Wholesaler → Retailer → Consumer
```

Krishik does **not** claim that removing intermediaries always makes food cheaper. It claims something narrower and testable: a direct transaction becomes practical when demand is aggregated, pricing is transparent, and the additional transport is measured. When those conditions fail, the platform says so instead of pushing the sale through.

### The flow the product is built around

```
Supply → Demand → Demand aggregation → Matching → Price transparency
      → Logistics feasibility → Confirmation → Order
```

## Features

| Area | What it does |
| --- | --- |
| Direct marketplace | Farmers and FPOs publish lots; buyers filter by crop, location, quantity, price and grade |
| Demand aggregation | Fragmented buyer requirements per crop are pooled into one number a farmer can plan around |
| Explainable matching | Greedy best-score fill across several sellers, with the four compatibility checks shown |
| Price transparency | Asking price + transport + platform + handling, compared with a reference mandi price |
| Logistics feasibility | Detour model over the farmer's existing route; three outcome states, inputs always visible |
| Demand forecasting | Deterministic 7/14/30-day model with a "why this forecast" factor breakdown |
| Order lifecycle | Pending → Matched → Feasibility check → Awaiting confirmation → Confirmed → Completed (plus Cancelled) |
| Admin analytics | Supply vs demand, match rate, price spread, location activity, forecast trends |

### How feasibility is decided

For a given farmer, buyer and quantity:

```
baseline = farm → usual selling point            (the trip already happening)
route    = farm → buyer → usual selling point
extra    = max(0, route − baseline)
cost     = extra × vehicle rate (₹6–48/km by load size)
landed   = farmer price + cost/kg + platform (2%) + handling (₹0.10/kg)
```

| Result | Condition |
| --- | --- |
| **Economically feasible** | Landed price is below the reference price with a real margin, and extra travel is inside the farmer's own limit |
| **Conditionally feasible** | The saving is thin, or transport eats more than 12% of the farmer's price, or the detour exceeds the farmer's limit |
| **Not economically feasible** | Additional transport cancels the saving, or the detour is far past the farmer's limit |

Krishik owns no vehicles and books no transport. This module is decision support only.

## User roles

- **Farmer** — list produce, see nearby demand and forecast, accept or decline orders
- **FPO** — aggregate member produce, respond to bulk requirements, view analytics
- **Buyer** — individual household or bulk (retailer, restaurant, hostel, canteen, business, institution)
- **Admin** — monitor users, listings, orders and platform analytics

## Demo accounts

No password is required in the prototype. The login page also has one-tap role buttons.

| Role | Email |
| --- | --- |
| Farmer | `farmer@krishik.demo` (Ravi Kumar, Buxar) |
| Buyer | `buyer@krishik.demo` (Annapurna Restaurant, bulk) |
| FPO | `fpo@krishik.demo` (Buxar Vegetable Producers FPO) |
| Admin | `admin@krishik.demo` |

You can switch roles at any time from the sidebar without signing out.

## Tech stack

React 18 · TypeScript · Vite · Tailwind CSS · React Router · Recharts · Lucide. No external API keys, no backend required to run.

## Project structure

```
src/
  types/          domain interfaces (User, Listing, Requirement, Order, TransportAnalysis, Forecast…)
  data/seed.ts    the entire demo dataset, dates anchored to "today"
  services/       the only place data is read or written
    store.ts        in-memory database + change notifications  ← swap this for Supabase
    trade.ts        listings, requirements, orders, transactions
    matching.ts     match scoring, greedy fill, demand pools
    logistics.ts    detour model, vehicle tiers, price breakdown
    forecast.ts     deterministic demand forecast
    analytics.ts    platform aggregates
  lib/            formatting (INR, kg, Indian dates), geo maths, useService hook
  context/        auth (demo session) and toasts
  components/
    ui/             Button, Card, Badge, Stat, Field, Modal, Table, Meter, Skeleton, EmptyState
    layout/         PublicLayout, AppShell, Guards, nav config
    domain/         ListingCard, PricePanel, FeasibilityPanel, MatchList, RouteMap, ForecastCard, OrdersView
  pages/          public · farmer · buyer · fpo · admin · shared
tools/            optional self-test scripts (route render + end-to-end scenario)
```

Components never import mock data for state — they call services. That boundary is what makes the Supabase swap cheap.

## Running locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build        # type check + production build into dist/
npm run build:single # one self-contained dist/index.html, handy for offline demos
npm run preview      # serve the production build
```

Two optional checks:

```bash
npm run routecheck   # server-renders every route and reports OK/FAIL
npm run selftest     # runs the full farmer → buyer → match → order → forecast → admin scenario
```

## SIH26033 Requirement → Krishik Feature Mapping

| Problem requirement | Krishik feature | Where | Status |
| --- | --- | --- | --- |
| Reduce intermediaries between farmer and buyer | Direct marketplace with farmer-set asking prices | `/marketplace`, `/buyer/marketplace` | Implemented (mock data) |
| Help buyers find farmers | Search, crop/location/price/quantity/grade filters, verification badges | `MarketplaceBrowser` | Implemented (mock data) |
| Small buyers are too small to matter | Bulk-demand aggregation pooled per crop | `/ai-insights`, `/farmer/demand`, `/buyer/requirements` | Implemented (mock data) |
| Consumers cannot see what they pay for | Transparent landed-price breakdown vs reference price | `PricePanel` on every listing, match and order | Implemented (mock data) |
| Produce travels further than it needs to | Transport feasibility on the farmer's existing route | `/logistics`, every order and match | Implemented (mock data) |
| Farmers list blind to demand | Demand forecast with factor breakdown | `/ai-insights`, `/farmer/forecast` | Implemented — prototype model |
| Route / movement decision support | Schematic route map, suggested movement, extra km and cost | `RouteMap`, `/logistics` | Implemented (schematic, no map API) |
| Transaction tracking | Seven-state order lifecycle with a timeline | `/farmer/orders`, `/buyer/orders`, `/admin/orders` | Implemented (mock data) |
| Ecosystem oversight | Admin users, listings, orders and analytics | `/admin/*` | Implemented (mock data) |
| Payments and settlement | Not built | — | Planned for real deployment |
| Real authentication and KYC | Demo session only | — | Planned for real deployment |
| Live mandi price feed (Agmarknet) | Reference prices are seeded demo values | — | Planned for real deployment |
| Real routing / distance API | Haversine × 1.25 road factor | `lib/geo.ts` | Planned for real deployment |

## Mock data

Everything lives in `src/data/seed.ts`: 8 farmers, 2 FPOs, 8 buyers, 17 listings, 10 requirements and 6 orders across **Buxar, Dumraon, Chausa, Itarhi, Ara, Bihiya, Patna, Danapur and Varanasi**, trading tomato, potato, onion, cauliflower, wheat and rice in ₹ and kg.

The dataset is deliberately imperfect, so the prototype can show all three outcomes:

- **Economically feasible** — Buxar farmer to a Buxar restaurant, no detour
- **Conditionally feasible** — Danapur rice priced close to the mandi rate, thin margin
- **Not economically feasible** — a Buxar seller against a Varanasi buyer; transport cancels the saving

Some requirements are fully matched, some partially, some have no viable seller at all.

## AI / forecasting disclaimer

The forecast is a **deterministic prototype model**, not a trained one. It combines recent order history, live open requirements, listed supply, a monthly seasonality curve and a least-squares trend. Every number it produces is reproducible from the seed data, and every screen that shows one labels it as a prototype estimate. The same applies to the match score and to the reference market prices, which are demo values, not live mandi data.

## Supabase migration plan

The project is **Supabase-ready but not Supabase-connected**. No credentials exist in the repo and none should be committed.

Replace `src/services/store.ts` with a Supabase client; the other service files keep their signatures (`getListings`, `createOrder`, `calculateMatch`, `calculateTransportFeasibility`, `getDemandForecast`, `getPlatformAnalytics`), so no component changes.

Suggested schema:

| Table | Key columns | Relationships |
| --- | --- | --- |
| `users` | id, email, phone, role, place_id, verified, joined_on | Supabase Auth user id as PK |
| `profiles` | user_id, display_name, avatar_url | 1:1 with `users` |
| `farmers` | user_id, farm_size_acres, fpo_id, preferred_selling_place_id, max_additional_km, vehicle_access | FK → `users`, FK → `fpos` |
| `fpos` | user_id, registration_no, member_count, villages_covered, preferred_selling_place_id | FK → `users` |
| `buyers` | user_id, buyer_type, bulk_category, business_name, monthly_volume_kg | FK → `users` |
| `places` | id, name, district, state, lat, lng | referenced by listings, requirements, users |
| `products` | id, name, category, reference_price_per_kg, seasonality | reference data |
| `listings` | id, seller_id, seller_role, product_id, quantity_kg, remaining_kg, price_per_kg, grade, harvest_date, available_from/until, farm_place_id, preferred_selling_place_id, max_additional_km, status | FK → `users`, `products`, `places` |
| `requirements` | id, buyer_id, product_id, quantity_kg, max_price_per_kg, required_by, buyer_place_id, pickup_place_id, matched_kg, status | FK → `users`, `products`, `places` |
| `matches` | id, requirement_id, listing_id, quantity_kg, score, feasibility_status, additional_km, cost_per_kg | FK → `requirements`, `listings` |
| `orders` | id, listing_id, requirement_id, buyer_id, seller_id, quantity_kg, price_per_kg, status, buyer_confirmed, seller_confirmed | FK as above |
| `order_events` | id, order_id, at, label, actor_role | FK → `orders` |
| `forecast_snapshots` | id, product_id, generated_at, horizon_days, predicted_demand_kg, current_supply_kg, trend, factors (jsonb) | FK → `products` |

Role handling: keep `role` on `users` and drive RLS from it — farmers and FPOs write only their own listings, buyers write only their own requirements, both parties read an order they belong to, admins read everything. Matching, pricing and feasibility are pure functions and can run either client-side (as today) or as Postgres functions / Edge Functions if you want them trusted server-side.

## Future scope

- Live Agmarknet price feeds replacing the reference demo prices
- Real routing distances and shared-vehicle pooling between nearby farmers
- Payments and escrow at handover
- Phone-number OTP authentication and FPO verification workflow
- Vernacular UI (Hindi and Bhojpuri) for farmer-facing screens
- Training the forecast on real transaction history once volume exists
