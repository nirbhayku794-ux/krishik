/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        canvas: '#F6F7F2',
        paper: '#FFFFFF',
        ink: { DEFAULT: '#12211B', soft: '#3D4F47', mute: '#6B7C74' },
        forest: {
          50: '#EDF5F0', 100: '#D6E8DD', 200: '#ADD1BC', 300: '#7DB499',
          400: '#4E9375', 500: '#2F7658', 600: '#215C44', 700: '#184634',
          800: '#123526', 900: '#0C2419',
        },
        harvest: { 50: '#FDF5E7', 100: '#F9E6C2', 300: '#EDBF69', 500: '#D99B22', 600: '#B77C13' },
        clay: { 100: '#F3E9E2', 500: '#9C6644' },
        flag: { ok: '#2F7658', warn: '#B77C13', bad: '#B4453A' },
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      borderRadius: { xl2: '1.25rem' },
      boxShadow: {
        card: '0 1px 2px rgba(18,33,27,.04), 0 8px 24px -16px rgba(18,33,27,.18)',
        lift: '0 2px 6px rgba(18,33,27,.06), 0 18px 40px -24px rgba(18,33,27,.28)',
      },
      keyframes: {
        rise: { '0%': { opacity: '0', transform: 'translateY(8px)' }, '100%': { opacity: '1', transform: 'none' } },
        shimmer: { '100%': { transform: 'translateX(100%)' } },
      },
      animation: { rise: 'rise .35s ease-out both', shimmer: 'shimmer 1.4s infinite' },
    },
  },
  plugins: [],
}
